 const controllers = {}
var sequelize = require('../model/database');
var tblunidad_unidad = require('../model/tblunidad_unidad');

//METODO GET//

controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tblunidad_unidad.findAll({
where: {idtblunidad_unidad: id }  })
.then(function(data){
    return data;})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}


//METODO LIST//

controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tblunidad_unidad.findAll();
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}



//METODO CREATE//
controllers.create = async (req, res)=>{
const  {CLAPRO,CLAEDO,CLAREG,CLADIR,CLAUNI,UNIDAD}=req.body;
const data = await tblunidad_unidad.create({
CLAPRO: CLAPRO,
CLAEDO: CLAEDO,
CLAREG: CLAREG,
CLADIR: CLADIR,
CLAUNI: CLAUNI,
UNIDAD: UNIDAD
}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data
})
}


//METODO UPDATE//
controllers.update = async (req, res)=>{
  const { id } = req.params;
const  {CLAPRO,CLAEDO,CLAREG,CLADIR,CLAUNI,UNIDAD}=req.body;

 const data = await tblunidad_unidad.update({
CLAPRO: CLAPRO,
CLAEDO: CLAEDO,
CLAREG: CLAREG,
CLADIR: CLADIR,
CLAUNI: CLAUNI,
UNIDAD: UNIDAD
   },{
          where: { idtblunidad_unidad: id}
     })
  .then( function(data){
    return data;
      })
       .catch(error => {
        return error;
   }) 
   res.json({success:true, data:data, message:"Updated successful"});
 }



 module.exports = controllers;
