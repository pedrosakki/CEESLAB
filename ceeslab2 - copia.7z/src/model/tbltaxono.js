const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tbltaxono')
var nametable = 'tbltaxono';
var tbltaxono = sequelize.define(nametable,{
idtbltaxono:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


MUESTRA:  Sequelize.INTEGER,
C_ENVASE:  Sequelize.STRING,
ENVASE:  Sequelize.STRING,
C_ESPECIME:  Sequelize.INTEGER,
GENERO:  Sequelize.STRING,
ESPECIE:  Sequelize.STRING,
TOXICIDAD:  Sequelize.STRING,
VECTOR:  Sequelize.STRING,
C_VISITADA:  Sequelize.INTEGER,
C_POSITIVA:  Sequelize.INTEGER,
ICP:  Sequelize.INTEGER,
IIC:  Sequelize.INTEGER,
FEC_REP:  Sequelize.DATE,
FEC_COL:  Sequelize.DATE,
SITIO:  Sequelize.STRING,
COLECTOR:  Sequelize.STRING,
SUPLEMENTO:  Sequelize.INTEGER,
CLAPRO:  Sequelize.INTEGER,
CLAMUN:  Sequelize.INTEGER,
CLAEDO:  Sequelize.INTEGER,
OBSERV:  Sequelize.STRING,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tbltaxono;
