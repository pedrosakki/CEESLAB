const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tblcalidad10')
var nametable = 'tblcalidad10';
var tblcalidad10 = sequelize.define(nametable,{
idtblcalidad10:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


CLAPRO:  Sequelize.DECIMAL,
CLAMUE:  Sequelize.DECIMAL,
FEC_REP:  Sequelize.DATE,
FEC_CAP:  Sequelize.DATE,
FEC_IMP:  Sequelize.DATE,
FEC_VAL:  Sequelize.DATE,
VALIDADO:  Sequelize.INTEGER,
CLACAU:  Sequelize.INTEGER,
SUPLEMENTO:  Sequelize.INTEGER,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tblcalidad10;
