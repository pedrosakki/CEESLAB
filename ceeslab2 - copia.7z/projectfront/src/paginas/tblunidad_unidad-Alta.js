import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios';
class EditComponent extends React.Component{
constructor(props){
super(props);
this.state = {
CLAPRO:"",
CLAEDO:"",
CLAREG:"",
CLADIR:"",
CLAUNI:"",
UNIDAD:""
}
}
render(){
  return (
<div>
 <div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAPRO </label>
<input type="text" class="form-control" placeholder="CLAPRO" value={this.state.CLAPRO} onChange={(value)=> this.setState({CLAPRO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAEDO </label>
<input type="text" class="form-control" placeholder="CLAEDO" value={this.state.CLAEDO} onChange={(value)=> this.setState({CLAEDO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAREG </label>
<input type="text" class="form-control" placeholder="CLAREG" value={this.state.CLAREG} onChange={(value)=> this.setState({CLAREG:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLADIR </label>
<input type="text" class="form-control" placeholder="CLADIR" value={this.state.CLADIR} onChange={(value)=> this.setState({CLADIR:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAUNI </label>
<input type="text" class="form-control" placeholder="CLAUNI" value={this.state.CLAUNI} onChange={(value)=> this.setState({CLAUNI:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">UNIDAD </label>
<input type="text" class="form-control" placeholder="UNIDAD" value={this.state.UNIDAD} onChange={(value)=> this.setState({UNIDAD:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendSave()}>Save</button>
</div>
</div>
);
}
  sendSave(){
const baseUrl = "http://localhost:3000/Rtblunidad_unidad/create"
const datapost = {
CLAPRO: this.state.CLAPRO,
CLAEDO: this.state.CLAEDO,
CLAREG: this.state.CLAREG,
CLADIR: this.state.CLADIR,
CLAUNI: this.state.CLAUNI,
UNIDAD: this.state.UNIDAD
}
axios.post(baseUrl,datapost)
      .then(response=>{
 if (response.data.success===true) {
  alert(response.data.message)
}
else {
alert(response.data.message)
}
}).catch(error=>{
   alert("Error 34 "+error)
 })
 }
}
export default EditComponent;
