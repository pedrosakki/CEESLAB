import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { Link } from "react-router-dom";
import axios from 'axios';
const url= 'http://localhost:3000/Rtblusuario_usuarios/list';
class listComponent extends React.Component  {
constructor(props){
super(props);
this.state ={
listtblusuario_usuarios:[]
}
}
componentDidMount(){
axios.get(url)
.then(res=>{
if(res.data.sucess){
const data = res.data.data
this.setState({listtblusuario_usuarios:data})
}
else{
alert("Error web service")
}
})
.catch(error=>{
alert("Error Server"+error)
})
}
render()
{
    return (
      <table class="table table-hover table-striped">

        <thead class="thead-dark">

<tr>
<th scope = "col" >#</th>
<th scope ="col" >USUARIO</th>
<th scope ="col" >PASSWORD</th>
<th scope ="col" >ACCESO</th>
<th scope ="col" >SECCION</th>
<th scope ="col" >TIPO</th>
<th scope ="col" >NIVEL</th>
<th scope ="col" >SESION</th>
<th scope ="col" >CODIGO</th>
<th scope ="col" >NOMBRE</th>
<th colspan="2" >Acciones</th>
</tr>
        </thead>
<tbody>
        {this.loadFilData()}
        </tbody>
      </table>
    );
  }
loadFilData(){
return this.state.listtblusuario_usuarios.map((data)=>{
return(
  <tr>
  <th>{data.idtblusuario_usuarios}</th>

<td>{data.USUARIO}</td>
<td>{data.PASSWORD}</td>
<td>{data.ACCESO}</td>
<td>{data.SECCION}</td>
<td>{data.TIPO}</td>
<td>{data.NIVEL}</td>
<td>{data.SESION}</td>
<td>{data.CODIGO}</td>
<td>{data.NOMBRE}</td>
<td>
<Link class="btn btn-outline-info "  to={"/tblusuario_usuariosEdit/"+data.idtblusuario_usuarios} >Edit</Link>
</td>
<td>
  <button class="btn btn-outline-danger "> Delete </button>
</td>
</tr>
)
}
)
}
}
export default listComponent;
