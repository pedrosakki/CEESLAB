import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios';
class EditComponent extends React.Component{
constructor(props){
super(props);
this.state = {
IDTBLCALIDAD2:"",
MUESTRA:"",
CLAPRO:"",
CLAMUE:"",
OFICIO:"",
FEC_REP:"",
TIPO:"",
MES:"",
LABORATORIO:"",
REV_DIAG:"",
DIAG_0:"",
REV_CONT:"",
CONT_0:"",
DIAG_1:"",
EXT_CONT:"",
CONT_1:"",
TINC_DIAG:"",
DIAG_2:"",
TINC_CONT:"",
CONT_2:"",
POS_DIAG:"",
DIAG_3:"",
NEG_DIAG:"",
DIAG_4:"",
NEG_CONT:"",
CONT_4:"",
EXT_ADE:"",
EXT_INA:"",
TIN_ADE:"",
TIN_INA:"",
TOT_BAC:"",
OBSERVA:"",
FEC_VAL:"",
FEC_CAP:"",
FEC_IMP:"",
VALIDADO:"",
CLACAU:"",
SUPLEMENTO:""
}
}
render(){
  return (
<div>
 <div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">IDTBLCALIDAD2 </label>
<input type="text" class="form-control" placeholder="IDTBLCALIDAD2" value={this.state.IDTBLCALIDAD2} onChange={(value)=> this.setState({IDTBLCALIDAD2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MUESTRA </label>
<input type="text" class="form-control" placeholder="MUESTRA" value={this.state.MUESTRA} onChange={(value)=> this.setState({MUESTRA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAPRO </label>
<input type="text" class="form-control" placeholder="CLAPRO" value={this.state.CLAPRO} onChange={(value)=> this.setState({CLAPRO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAMUE </label>
<input type="text" class="form-control" placeholder="CLAMUE" value={this.state.CLAMUE} onChange={(value)=> this.setState({CLAMUE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OFICIO </label>
<input type="text" class="form-control" placeholder="OFICIO" value={this.state.OFICIO} onChange={(value)=> this.setState({OFICIO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_REP </label>
<input type="text" class="form-control" placeholder="FEC_REP" value={this.state.FEC_REP} onChange={(value)=> this.setState({FEC_REP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TIPO </label>
<input type="text" class="form-control" placeholder="TIPO" value={this.state.TIPO} onChange={(value)=> this.setState({TIPO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MES </label>
<input type="text" class="form-control" placeholder="MES" value={this.state.MES} onChange={(value)=> this.setState({MES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">LABORATORIO </label>
<input type="text" class="form-control" placeholder="LABORATORIO" value={this.state.LABORATORIO} onChange={(value)=> this.setState({LABORATORIO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">REV_DIAG </label>
<input type="text" class="form-control" placeholder="REV_DIAG" value={this.state.REV_DIAG} onChange={(value)=> this.setState({REV_DIAG:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DIAG_0 </label>
<input type="text" class="form-control" placeholder="DIAG_0" value={this.state.DIAG_0} onChange={(value)=> this.setState({DIAG_0:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">REV_CONT </label>
<input type="text" class="form-control" placeholder="REV_CONT" value={this.state.REV_CONT} onChange={(value)=> this.setState({REV_CONT:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CONT_0 </label>
<input type="text" class="form-control" placeholder="CONT_0" value={this.state.CONT_0} onChange={(value)=> this.setState({CONT_0:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DIAG_1 </label>
<input type="text" class="form-control" placeholder="DIAG_1" value={this.state.DIAG_1} onChange={(value)=> this.setState({DIAG_1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXT_CONT </label>
<input type="text" class="form-control" placeholder="EXT_CONT" value={this.state.EXT_CONT} onChange={(value)=> this.setState({EXT_CONT:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CONT_1 </label>
<input type="text" class="form-control" placeholder="CONT_1" value={this.state.CONT_1} onChange={(value)=> this.setState({CONT_1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TINC_DIAG </label>
<input type="text" class="form-control" placeholder="TINC_DIAG" value={this.state.TINC_DIAG} onChange={(value)=> this.setState({TINC_DIAG:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DIAG_2 </label>
<input type="text" class="form-control" placeholder="DIAG_2" value={this.state.DIAG_2} onChange={(value)=> this.setState({DIAG_2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TINC_CONT </label>
<input type="text" class="form-control" placeholder="TINC_CONT" value={this.state.TINC_CONT} onChange={(value)=> this.setState({TINC_CONT:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CONT_2 </label>
<input type="text" class="form-control" placeholder="CONT_2" value={this.state.CONT_2} onChange={(value)=> this.setState({CONT_2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">POS_DIAG </label>
<input type="text" class="form-control" placeholder="POS_DIAG" value={this.state.POS_DIAG} onChange={(value)=> this.setState({POS_DIAG:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DIAG_3 </label>
<input type="text" class="form-control" placeholder="DIAG_3" value={this.state.DIAG_3} onChange={(value)=> this.setState({DIAG_3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">NEG_DIAG </label>
<input type="text" class="form-control" placeholder="NEG_DIAG" value={this.state.NEG_DIAG} onChange={(value)=> this.setState({NEG_DIAG:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DIAG_4 </label>
<input type="text" class="form-control" placeholder="DIAG_4" value={this.state.DIAG_4} onChange={(value)=> this.setState({DIAG_4:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">NEG_CONT </label>
<input type="text" class="form-control" placeholder="NEG_CONT" value={this.state.NEG_CONT} onChange={(value)=> this.setState({NEG_CONT:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CONT_4 </label>
<input type="text" class="form-control" placeholder="CONT_4" value={this.state.CONT_4} onChange={(value)=> this.setState({CONT_4:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXT_ADE </label>
<input type="text" class="form-control" placeholder="EXT_ADE" value={this.state.EXT_ADE} onChange={(value)=> this.setState({EXT_ADE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXT_INA </label>
<input type="text" class="form-control" placeholder="EXT_INA" value={this.state.EXT_INA} onChange={(value)=> this.setState({EXT_INA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TIN_ADE </label>
<input type="text" class="form-control" placeholder="TIN_ADE" value={this.state.TIN_ADE} onChange={(value)=> this.setState({TIN_ADE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TIN_INA </label>
<input type="text" class="form-control" placeholder="TIN_INA" value={this.state.TIN_INA} onChange={(value)=> this.setState({TIN_INA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TOT_BAC </label>
<input type="text" class="form-control" placeholder="TOT_BAC" value={this.state.TOT_BAC} onChange={(value)=> this.setState({TOT_BAC:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OBSERVA </label>
<input type="text" class="form-control" placeholder="OBSERVA" value={this.state.OBSERVA} onChange={(value)=> this.setState({OBSERVA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_VAL </label>
<input type="text" class="form-control" placeholder="FEC_VAL" value={this.state.FEC_VAL} onChange={(value)=> this.setState({FEC_VAL:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_CAP </label>
<input type="text" class="form-control" placeholder="FEC_CAP" value={this.state.FEC_CAP} onChange={(value)=> this.setState({FEC_CAP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_IMP </label>
<input type="text" class="form-control" placeholder="FEC_IMP" value={this.state.FEC_IMP} onChange={(value)=> this.setState({FEC_IMP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">VALIDADO </label>
<input type="text" class="form-control" placeholder="VALIDADO" value={this.state.VALIDADO} onChange={(value)=> this.setState({VALIDADO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLACAU </label>
<input type="text" class="form-control" placeholder="CLACAU" value={this.state.CLACAU} onChange={(value)=> this.setState({CLACAU:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SUPLEMENTO </label>
<input type="text" class="form-control" placeholder="SUPLEMENTO" value={this.state.SUPLEMENTO} onChange={(value)=> this.setState({SUPLEMENTO:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendSave()}>Save</button>
</div>
</div>
);
}
  sendSave(){
const baseUrl = "http://localhost:3000/Rtblcalidad2/create"
const datapost = {
IDTBLCALIDAD2: this.state.IDTBLCALIDAD2,
MUESTRA: this.state.MUESTRA,
CLAPRO: this.state.CLAPRO,
CLAMUE: this.state.CLAMUE,
OFICIO: this.state.OFICIO,
FEC_REP: this.state.FEC_REP,
TIPO: this.state.TIPO,
MES: this.state.MES,
LABORATORIO: this.state.LABORATORIO,
REV_DIAG: this.state.REV_DIAG,
DIAG_0: this.state.DIAG_0,
REV_CONT: this.state.REV_CONT,
CONT_0: this.state.CONT_0,
DIAG_1: this.state.DIAG_1,
EXT_CONT: this.state.EXT_CONT,
CONT_1: this.state.CONT_1,
TINC_DIAG: this.state.TINC_DIAG,
DIAG_2: this.state.DIAG_2,
TINC_CONT: this.state.TINC_CONT,
CONT_2: this.state.CONT_2,
POS_DIAG: this.state.POS_DIAG,
DIAG_3: this.state.DIAG_3,
NEG_DIAG: this.state.NEG_DIAG,
DIAG_4: this.state.DIAG_4,
NEG_CONT: this.state.NEG_CONT,
CONT_4: this.state.CONT_4,
EXT_ADE: this.state.EXT_ADE,
EXT_INA: this.state.EXT_INA,
TIN_ADE: this.state.TIN_ADE,
TIN_INA: this.state.TIN_INA,
TOT_BAC: this.state.TOT_BAC,
OBSERVA: this.state.OBSERVA,
FEC_VAL: this.state.FEC_VAL,
FEC_CAP: this.state.FEC_CAP,
FEC_IMP: this.state.FEC_IMP,
VALIDADO: this.state.VALIDADO,
CLACAU: this.state.CLACAU,
SUPLEMENTO: this.state.SUPLEMENTO
}
axios.post(baseUrl,datapost)
      .then(response=>{
 if (response.data.success===true) {
  alert(response.data.message)
}
else {
alert(response.data.message)
}
}).catch(error=>{
   alert("Error 34 "+error)
 })
 }
}
export default EditComponent;
