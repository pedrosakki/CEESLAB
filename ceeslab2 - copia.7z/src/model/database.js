var Sequelize = require('sequelize');

const sequelize = new Sequelize(
    /*
    'nibtrocc_ceeslab', // DATABASE
    'nibtrocc_lab', // USUARIO
    'A1234567890*', //CONTRASEÑA
    */
   'laboratorio2', // DATABASE
    'root', // USUARIO
    'usbw', //CONTRASEÑA
    {
        host: 'localhost',
        dialect: 'mysql',

        }
);
module.exports = sequelize;