const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tblcalidad9')
var nametable = 'tblcalidad9';
var tblcalidad9 = sequelize.define(nametable,{
idtblcalidad9:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


MUESTRA:  Sequelize.INTEGER,
FOLIO:  Sequelize.STRING,
AFILIACION:  Sequelize.STRING,
CLAPRO:  Sequelize.DECIMAL,
CLAEDO:  Sequelize.DECIMAL,
CLAREG:  Sequelize.STRING,
CLADIR:  Sequelize.STRING,
CLAUNI:  Sequelize.STRING,
NOMBRES:  Sequelize.STRING,
APELLIDO_P:  Sequelize.STRING,
APELLIDO_M:  Sequelize.STRING,
FEC_NAC:  Sequelize.DATE,
EDAD:  Sequelize.INTEGER,
FEC_REP:  Sequelize.DATE,
RESULTADO:  Sequelize.STRING,
OBSERVA:  Sequelize.STRING,
SUPLEMENTO:  Sequelize.INTEGER,
FEC_TOM:  Sequelize.DATE,
ESTUDIO:  Sequelize.STRING,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tblcalidad9;
