 const controllers = {}
var sequelize = require('../model/database');
var tblpermisos = require('../model/tblpermisos');

//METODO GET//

controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tblpermisos.findAll({
where: {idtblpermisos: id }  })
.then(function(data){
    return data;})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}


//METODO LIST//

controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tblpermisos.findAll();
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}



//METODO CREATE//
controllers.create = async (req, res)=>{
const  {IDTBLPERMISOS,accion}=req.body;
const data = await tblpermisos.create({
IDTBLPERMISOS: IDTBLPERMISOS,
accion: accion
}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data
})
}


//METODO UPDATE//
controllers.update = async (req, res)=>{
  const { id } = req.params;
const  {IDTBLPERMISOS,accion}=req.body;

 const data = await tblpermisos.update({
IDTBLPERMISOS: IDTBLPERMISOS,
accion: accion
   },{
          where: { idtblpermisos: id}
     })
  .then( function(data){
    return data;
      })
       .catch(error => {
        return error;
   }) 
   res.json({success:true, data:data, message:"Updated successful"});
 }



 module.exports = controllers;
