const express = require('express');
const router = express.Router();
const tblcalidad7Controller = require('../Controllers/tblcalidad7Controller')


router.post('/update/:id',tblcalidad7Controller.update)
router.get('/get/:id', tblcalidad7Controller.get)
router.get('/list', tblcalidad7Controller.list);
router.post('/create', tblcalidad7Controller.create);


module.exports = router;
