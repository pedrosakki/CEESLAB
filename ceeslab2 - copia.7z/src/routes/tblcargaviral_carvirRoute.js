const express = require('express');
const router = express.Router();
const tblcargaviral_carvirController = require('../Controllers/tblcargaviral_carvirController')


router.post('/update/:id',tblcargaviral_carvirController.update)
router.get('/get/:id', tblcargaviral_carvirController.get)
router.get('/list', tblcargaviral_carvirController.list);
router.post('/create', tblcargaviral_carvirController.create);


module.exports = router;
