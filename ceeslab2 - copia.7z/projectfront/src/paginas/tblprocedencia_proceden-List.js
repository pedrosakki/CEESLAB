import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { Link } from "react-router-dom";
import axios from 'axios';
const url= 'http://localhost:3000/Rtblprocedencia_proceden/list';
class listComponent extends React.Component  {
constructor(props){
super(props);
this.state ={
listtblprocedencia_proceden:[]
}
}
componentDidMount(){
axios.get(url)
.then(res=>{
if(res.data.sucess){
const data = res.data.data
this.setState({listtblprocedencia_proceden:data})
}
else{
alert("Error web service")
}
})
.catch(error=>{
alert("Error Server"+error)
})
}
render()
{
    return (
      <table class="table table-hover table-striped">

        <thead class="thead-dark">

<tr>
<th scope = "col" >#</th>
<th scope ="col" >CLAPRO</th>
<th scope ="col" >PROCEDEN</th>
<th scope ="col" >ABREVIA</th>
<th scope ="col" >GRUPO</th>
<th scope ="col" >DOMICILIO</th>
<th scope ="col" >MUNICIPIO</th>
<th scope ="col" >ESTADO</th>
<th scope ="col" >ATENCION</th>
<th scope ="col" >CARGO</th>
<th scope ="col" >ENVIO</th>
<th scope ="col" >ENV_ELEC</th>
<th colspan="2" >Acciones</th>
</tr>
        </thead>
<tbody>
        {this.loadFilData()}
        </tbody>
      </table>
    );
  }
loadFilData(){
return this.state.listtblprocedencia_proceden.map((data)=>{
return(
  <tr>
  <th>{data.idtblprocedencia_proceden}</th>

<td>{data.CLAPRO}</td>
<td>{data.PROCEDEN}</td>
<td>{data.ABREVIA}</td>
<td>{data.GRUPO}</td>
<td>{data.DOMICILIO}</td>
<td>{data.MUNICIPIO}</td>
<td>{data.ESTADO}</td>
<td>{data.ATENCION}</td>
<td>{data.CARGO}</td>
<td>{data.ENVIO}</td>
<td>{data.ENV_ELEC}</td>
<td>
<Link class="btn btn-outline-info "  to={"/tblprocedencia_procedenEdit/"+data.idtblprocedencia_proceden} >Edit</Link>
</td>
<td>
  <button class="btn btn-outline-danger "> Delete </button>
</td>
</tr>
)
}
)
}
}
export default listComponent;
