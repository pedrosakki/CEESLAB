const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tbldireccion_direcc')
var nametable = 'tbldireccion_direcc';
var tbldireccion_direcc = sequelize.define(nametable,{
idtbldireccion_direcc:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


CLAPRO:  Sequelize.DECIMAL,
CLAEDO:  Sequelize.DECIMAL,
CLAREG:  Sequelize.STRING,
CLADIR:  Sequelize.STRING,
DIRECCION:  Sequelize.STRING,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tbldireccion_direcc;
