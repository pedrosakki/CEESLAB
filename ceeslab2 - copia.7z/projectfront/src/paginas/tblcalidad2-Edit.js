import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios'
const baseUrl= "http: //localhost:3000"
class EditComponent extends React.Component{

constructor(props){

super(props);
this.state={
edittblcalidad2s:[],
datatblcalidad2:{},
IDTBLCALIDAD2: "",
MUESTRA: "",
CLAPRO: "",
CLAMUE: "",
OFICIO: "",
FEC_REP: "",
TIPO: "",
MES: "",
LABORATORIO: "",
REV_DIAG: "",
DIAG_0: "",
REV_CONT: "",
CONT_0: "",
DIAG_1: "",
EXT_CONT: "",
CONT_1: "",
TINC_DIAG: "",
DIAG_2: "",
TINC_CONT: "",
CONT_2: "",
POS_DIAG: "",
DIAG_3: "",
NEG_DIAG: "",
DIAG_4: "",
NEG_CONT: "",
CONT_4: "",
EXT_ADE: "",
EXT_INA: "",
TIN_ADE: "",
TIN_INA: "",
TOT_BAC: "",
OBSERVA: "",
FEC_VAL: "",
FEC_CAP: "",
FEC_IMP: "",
VALIDADO: "",
CLACAU: "",
SUPLEMENTO: ""
}
}


componentDidMount(){
let userId = this.props.match.params.tblcalidad2id;
  const url = baseUrl+"/Rtblcalidad2/get/"+userId

  axios.get(url)
 .then(res=>{
  if(res.data.sucess){
  const data = res.data.data[0] 
this.setState({
edittblcalidad2s:data,
IDTBLCALIDAD2: data.IDTBLCALIDAD2,
MUESTRA: data.MUESTRA,
CLAPRO: data.CLAPRO,
CLAMUE: data.CLAMUE,
OFICIO: data.OFICIO,
FEC_REP: data.FEC_REP,
TIPO: data.TIPO,
MES: data.MES,
LABORATORIO: data.LABORATORIO,
REV_DIAG: data.REV_DIAG,
DIAG_0: data.DIAG_0,
REV_CONT: data.REV_CONT,
CONT_0: data.CONT_0,
DIAG_1: data.DIAG_1,
EXT_CONT: data.EXT_CONT,
CONT_1: data.CONT_1,
TINC_DIAG: data.TINC_DIAG,
DIAG_2: data.DIAG_2,
TINC_CONT: data.TINC_CONT,
CONT_2: data.CONT_2,
POS_DIAG: data.POS_DIAG,
DIAG_3: data.DIAG_3,
NEG_DIAG: data.NEG_DIAG,
DIAG_4: data.DIAG_4,
NEG_CONT: data.NEG_CONT,
CONT_4: data.CONT_4,
EXT_ADE: data.EXT_ADE,
EXT_INA: data.EXT_INA,
TIN_ADE: data.TIN_ADE,
TIN_INA: data.TIN_INA,
TOT_BAC: data.TOT_BAC,
OBSERVA: data.OBSERVA,
FEC_VAL: data.FEC_VAL,
FEC_CAP: data.FEC_CAP,
FEC_IMP: data.FEC_IMP,
VALIDADO: data.VALIDADO,
CLACAU: data.CLACAU,
SUPLEMENTO: data.SUPLEMENTO
} ) }
else{
alert("Error web service")
} } )
  .catch(error=>{
  })
}


  render(){
   let userId = 0;
 return (
<div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">IDTBLCALIDAD2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.IDTBLCALIDAD2} onChange={(value)=> this.setState({IDTBLCALIDAD2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MUESTRA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.MUESTRA} onChange={(value)=> this.setState({MUESTRA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAPRO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAPRO} onChange={(value)=> this.setState({CLAPRO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAMUE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAMUE} onChange={(value)=> this.setState({CLAMUE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OFICIO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.OFICIO} onChange={(value)=> this.setState({OFICIO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_REP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_REP} onChange={(value)=> this.setState({FEC_REP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TIPO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.TIPO} onChange={(value)=> this.setState({TIPO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MES </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.MES} onChange={(value)=> this.setState({MES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">LABORATORIO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.LABORATORIO} onChange={(value)=> this.setState({LABORATORIO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">REV_DIAG </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.REV_DIAG} onChange={(value)=> this.setState({REV_DIAG:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DIAG_0 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DIAG_0} onChange={(value)=> this.setState({DIAG_0:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">REV_CONT </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.REV_CONT} onChange={(value)=> this.setState({REV_CONT:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CONT_0 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CONT_0} onChange={(value)=> this.setState({CONT_0:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DIAG_1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DIAG_1} onChange={(value)=> this.setState({DIAG_1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXT_CONT </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXT_CONT} onChange={(value)=> this.setState({EXT_CONT:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CONT_1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CONT_1} onChange={(value)=> this.setState({CONT_1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TINC_DIAG </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.TINC_DIAG} onChange={(value)=> this.setState({TINC_DIAG:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DIAG_2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DIAG_2} onChange={(value)=> this.setState({DIAG_2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TINC_CONT </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.TINC_CONT} onChange={(value)=> this.setState({TINC_CONT:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CONT_2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CONT_2} onChange={(value)=> this.setState({CONT_2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">POS_DIAG </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.POS_DIAG} onChange={(value)=> this.setState({POS_DIAG:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DIAG_3 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DIAG_3} onChange={(value)=> this.setState({DIAG_3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">NEG_DIAG </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.NEG_DIAG} onChange={(value)=> this.setState({NEG_DIAG:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DIAG_4 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DIAG_4} onChange={(value)=> this.setState({DIAG_4:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">NEG_CONT </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.NEG_CONT} onChange={(value)=> this.setState({NEG_CONT:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CONT_4 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CONT_4} onChange={(value)=> this.setState({CONT_4:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXT_ADE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXT_ADE} onChange={(value)=> this.setState({EXT_ADE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXT_INA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXT_INA} onChange={(value)=> this.setState({EXT_INA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TIN_ADE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.TIN_ADE} onChange={(value)=> this.setState({TIN_ADE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TIN_INA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.TIN_INA} onChange={(value)=> this.setState({TIN_INA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TOT_BAC </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.TOT_BAC} onChange={(value)=> this.setState({TOT_BAC:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OBSERVA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.OBSERVA} onChange={(value)=> this.setState({OBSERVA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_VAL </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_VAL} onChange={(value)=> this.setState({FEC_VAL:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_CAP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_CAP} onChange={(value)=> this.setState({FEC_CAP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_IMP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_IMP} onChange={(value)=> this.setState({FEC_IMP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">VALIDADO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.VALIDADO} onChange={(value)=> this.setState({VALIDADO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLACAU </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLACAU} onChange={(value)=> this.setState({CLACAU:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SUPLEMENTO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.SUPLEMENTO} onChange={(value)=> this.setState({SUPLEMENTO:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendUpdate()}>Update</button>  
</div>
); }
sendUpdate(){
let userId = this.props.match.params.tblcalidad2id;
const baseUrl = "http://localhost:3000/Rtblcalidad2/Update/"+ userId
const datapost = {
IDTBLCALIDAD2: this.state.IDTBLCALIDAD2,
MUESTRA: this.state.MUESTRA,
CLAPRO: this.state.CLAPRO,
CLAMUE: this.state.CLAMUE,
OFICIO: this.state.OFICIO,
FEC_REP: this.state.FEC_REP,
TIPO: this.state.TIPO,
MES: this.state.MES,
LABORATORIO: this.state.LABORATORIO,
REV_DIAG: this.state.REV_DIAG,
DIAG_0: this.state.DIAG_0,
REV_CONT: this.state.REV_CONT,
CONT_0: this.state.CONT_0,
DIAG_1: this.state.DIAG_1,
EXT_CONT: this.state.EXT_CONT,
CONT_1: this.state.CONT_1,
TINC_DIAG: this.state.TINC_DIAG,
DIAG_2: this.state.DIAG_2,
TINC_CONT: this.state.TINC_CONT,
CONT_2: this.state.CONT_2,
POS_DIAG: this.state.POS_DIAG,
DIAG_3: this.state.DIAG_3,
NEG_DIAG: this.state.NEG_DIAG,
DIAG_4: this.state.DIAG_4,
NEG_CONT: this.state.NEG_CONT,
CONT_4: this.state.CONT_4,
EXT_ADE: this.state.EXT_ADE,
EXT_INA: this.state.EXT_INA,
TIN_ADE: this.state.TIN_ADE,
TIN_INA: this.state.TIN_INA,
TOT_BAC: this.state.TOT_BAC,
OBSERVA: this.state.OBSERVA,
FEC_VAL: this.state.FEC_VAL,
FEC_CAP: this.state.FEC_CAP,
FEC_IMP: this.state.FEC_IMP,
VALIDADO: this.state.VALIDADO,
CLACAU: this.state.CLACAU,
SUPLEMENTO: this.state.SUPLEMENTO
}
axios.post(baseUrl,datapost)
.then(response=>{
if (response.data.success===true) {
alert(response.data.message)
}
else {
alert(response.data.message)
alert(JSON.stringify(response))
}
}).catch(error=>{
alert("Error 34 "+error)
})
}
}
export default EditComponent;
