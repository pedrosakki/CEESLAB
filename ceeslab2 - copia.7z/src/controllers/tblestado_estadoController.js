 const controllers = {}
var sequelize = require('../model/database');
var tblestado_estado = require('../model/tblestado_estado');

//METODO GET//

controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tblestado_estado.findAll({
where: {idtblestado_estado: id }  })
.then(function(data){
    return data;})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}


//METODO LIST//

controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tblestado_estado.findAll();
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}



//METODO CREATE//
controllers.create = async (req, res)=>{
const  {CLAEDO,ESTADO,NOM_ABR}=req.body;
const data = await tblestado_estado.create({
CLAEDO: CLAEDO,
ESTADO: ESTADO,
NOM_ABR: NOM_ABR
}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data
})
}


//METODO UPDATE//
controllers.update = async (req, res)=>{
  const { id } = req.params;
const  {CLAEDO,ESTADO,NOM_ABR}=req.body;

 const data = await tblestado_estado.update({
CLAEDO: CLAEDO,
ESTADO: ESTADO,
NOM_ABR: NOM_ABR
   },{
          where: { idtblestado_estado: id}
     })
  .then( function(data){
    return data;
      })
       .catch(error => {
        return error;
   }) 
   res.json({success:true, data:data, message:"Updated successful"});
 }



 module.exports = controllers;
