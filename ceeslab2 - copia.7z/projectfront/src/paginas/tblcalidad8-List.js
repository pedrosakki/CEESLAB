import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { Link } from "react-router-dom";
import axios from 'axios';
const url= 'http://localhost:3000/Rtblcalidad8/list';
class listComponent extends React.Component  {
constructor(props){
super(props);
this.state ={
listtblcalidad8:[]
}
}
componentDidMount(){
axios.get(url)
.then(res=>{
if(res.data.sucess){
const data = res.data.data
this.setState({listtblcalidad8:data})
}
else{
alert("Error web service")
}
})
.catch(error=>{
alert("Error Server"+error)
})
}
render()
{
    return (
      <table class="table table-hover table-striped">

        <thead class="thead-dark">

<tr>
<th scope = "col" >#</th>
<th scope ="col" >MUESTRA</th>
<th scope ="col" >CLAPRO</th>
<th scope ="col" >CLAMUE</th>
<th scope ="col" >RECOBODAS</th>
<th scope ="col" >RECHAZADAS</th>
<th scope ="col" >TMI</th>
<th scope ="col" >CRN</th>
<th scope ="col" >CRP</th>
<th scope ="col" >IPP</th>
<th scope ="col" >ENPROCESO</th>
<th scope ="col" >OBSERVA</th>
<th scope ="col" >FEC_REP</th>
<th scope ="col" >FEC_CAP</th>
<th scope ="col" >FEC_IMP</th>
<th scope ="col" >FEC_VAL</th>
<th scope ="col" >VALIDADO</th>
<th scope ="col" >CLACAU</th>
<th scope ="col" >SUPLEMENTO</th>
<th colspan="2" >Acciones</th>
</tr>
        </thead>
<tbody>
        {this.loadFilData()}
        </tbody>
      </table>
    );
  }
loadFilData(){
return this.state.listtblcalidad8.map((data)=>{
return(
  <tr>
  <th>{data.idtblcalidad8}</th>

<td>{data.MUESTRA}</td>
<td>{data.CLAPRO}</td>
<td>{data.CLAMUE}</td>
<td>{data.RECOBODAS}</td>
<td>{data.RECHAZADAS}</td>
<td>{data.TMI}</td>
<td>{data.CRN}</td>
<td>{data.CRP}</td>
<td>{data.IPP}</td>
<td>{data.ENPROCESO}</td>
<td>{data.OBSERVA}</td>
<td>{data.FEC_REP}</td>
<td>{data.FEC_CAP}</td>
<td>{data.FEC_IMP}</td>
<td>{data.FEC_VAL}</td>
<td>{data.VALIDADO}</td>
<td>{data.CLACAU}</td>
<td>{data.SUPLEMENTO}</td>
<td>
<Link class="btn btn-outline-info "  to={"/tblcalidad8Edit/"+data.idtblcalidad8} >Edit</Link>
</td>
<td>
  <button class="btn btn-outline-danger "> Delete </button>
</td>
</tr>
)
}
)
}
}
export default listComponent;
