import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { Link } from "react-router-dom";
import axios from 'axios';
const url= 'http://localhost:3000/Rtbldireccion_direcc/list';
class listComponent extends React.Component  {
constructor(props){
super(props);
this.state ={
listtbldireccion_direcc:[]
}
}
componentDidMount(){
axios.get(url)
.then(res=>{
if(res.data.sucess){
const data = res.data.data
this.setState({listtbldireccion_direcc:data})
}
else{
alert("Error web service")
}
})
.catch(error=>{
alert("Error Server"+error)
})
}
render()
{
    return (
      <table class="table table-hover table-striped">

        <thead class="thead-dark">

<tr>
<th scope = "col" >#</th>
<th scope ="col" >CLAPRO</th>
<th scope ="col" >CLAEDO</th>
<th scope ="col" >CLAREG</th>
<th scope ="col" >CLADIR</th>
<th scope ="col" >DIRECCION</th>
<th colspan="2" >Acciones</th>
</tr>
        </thead>
<tbody>
        {this.loadFilData()}
        </tbody>
      </table>
    );
  }
loadFilData(){
return this.state.listtbldireccion_direcc.map((data)=>{
return(
  <tr>
  <th>{data.idtbldireccion_direcc}</th>

<td>{data.CLAPRO}</td>
<td>{data.CLAEDO}</td>
<td>{data.CLAREG}</td>
<td>{data.CLADIR}</td>
<td>{data.DIRECCION}</td>
<td>
<Link class="btn btn-outline-info "  to={"/tbldireccion_direccEdit/"+data.idtbldireccion_direcc} >Edit</Link>
</td>
<td>
  <button class="btn btn-outline-danger "> Delete </button>
</td>
</tr>
)
}
)
}
}
export default listComponent;
