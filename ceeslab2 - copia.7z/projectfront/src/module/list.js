import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { Link } from "react-router-dom";
import axios from 'axios';
const url= 'http://localhost:3000/Empleados/list';
class listComponent extends React.Component  {
constructor(props){
super(props);
this.state ={
listtblempleados:[]
}
}
componentDidMount(){
axios.get(url)
.then(res=>{
if(res.data.sucess){
const data = res.data.data 
this.setState({listtblempleados:data})
}
else{
alert("Error web service")
}
})
.catch(error=>{
alert("Error Server"+error)
})
}
render()
  {
    return (
      <table class="table table-hover table-striped">
        <thead class="thead-dark">
          <tr>
            <th scope="col">#</th>
            <th scope="col">Role</th>
            <th scope="col">Name</th>
            <th scope="col">Address</th>
            <th scope="col">Phone</th>
            <th colspan="2">Action</th>
          </tr>
        </thead>
        <tbody>
        {this.loadFilData()}
        </tbody>
      </table>
    );
  }
loadFilData(){
return this.state.listtblempleados.map((data)=>{

return(
  <tr>
  <th>{data.idtblempleado}</th>
  <td>{data.apellidopaterno}</td>
  <td>{data.apellidomaterno}</td>
  <td>{data.tblpuesto.descripcion}</td>
  <td>
  <Link class="btn btn-outline-info "  to={"/edit/"+data.idtblempleado} >Edit</Link>
  </td>
  <td>
  <button class="btn btn-outline-danger "> Delete </button>
  </td>
  </tr>
)
}
)
}
}
export default listComponent;