import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { Link } from "react-router-dom";
import axios from 'axios';
const url= 'http://localhost:3000/Rtblcalidad2/list';
class listComponent extends React.Component  {
constructor(props){
super(props);
this.state ={
listtblcalidad2:[]
}
}
componentDidMount(){
axios.get(url)
.then(res=>{
if(res.data.sucess){
const data = res.data.data
this.setState({listtblcalidad2:data})
}
else{
alert("Error web service")
}
})
.catch(error=>{
alert("Error Server"+error)
})
}
render()
{
    return (
      <table class="table table-hover table-striped">

        <thead class="thead-dark">

<tr>
<th scope = "col" >#</th>
<th scope ="col" >IDTBLCALIDAD2</th>
<th scope ="col" >MUESTRA</th>
<th scope ="col" >CLAPRO</th>
<th scope ="col" >CLAMUE</th>
<th scope ="col" >OFICIO</th>
<th scope ="col" >FEC_REP</th>
<th scope ="col" >TIPO</th>
<th scope ="col" >MES</th>
<th scope ="col" >LABORATORIO</th>
<th scope ="col" >REV_DIAG</th>
<th scope ="col" >DIAG_0</th>
<th scope ="col" >REV_CONT</th>
<th scope ="col" >CONT_0</th>
<th scope ="col" >DIAG_1</th>
<th scope ="col" >EXT_CONT</th>
<th scope ="col" >CONT_1</th>
<th scope ="col" >TINC_DIAG</th>
<th scope ="col" >DIAG_2</th>
<th scope ="col" >TINC_CONT</th>
<th scope ="col" >CONT_2</th>
<th scope ="col" >POS_DIAG</th>
<th scope ="col" >DIAG_3</th>
<th scope ="col" >NEG_DIAG</th>
<th scope ="col" >DIAG_4</th>
<th scope ="col" >NEG_CONT</th>
<th scope ="col" >CONT_4</th>
<th scope ="col" >EXT_ADE</th>
<th scope ="col" >EXT_INA</th>
<th scope ="col" >TIN_ADE</th>
<th scope ="col" >TIN_INA</th>
<th scope ="col" >TOT_BAC</th>
<th scope ="col" >OBSERVA</th>
<th scope ="col" >FEC_VAL</th>
<th scope ="col" >FEC_CAP</th>
<th scope ="col" >FEC_IMP</th>
<th scope ="col" >VALIDADO</th>
<th scope ="col" >CLACAU</th>
<th scope ="col" >SUPLEMENTO</th>
<th colspan="2" >Acciones</th>
</tr>
        </thead>
<tbody>
        {this.loadFilData()}
        </tbody>
      </table>
    );
  }
loadFilData(){
return this.state.listtblcalidad2.map((data)=>{
return(
  <tr>
  <th>{data.idtblcalidad2}</th>

<td>{data.IDTBLCALIDAD2}</td>
<td>{data.MUESTRA}</td>
<td>{data.CLAPRO}</td>
<td>{data.CLAMUE}</td>
<td>{data.OFICIO}</td>
<td>{data.FEC_REP}</td>
<td>{data.TIPO}</td>
<td>{data.MES}</td>
<td>{data.LABORATORIO}</td>
<td>{data.REV_DIAG}</td>
<td>{data.DIAG_0}</td>
<td>{data.REV_CONT}</td>
<td>{data.CONT_0}</td>
<td>{data.DIAG_1}</td>
<td>{data.EXT_CONT}</td>
<td>{data.CONT_1}</td>
<td>{data.TINC_DIAG}</td>
<td>{data.DIAG_2}</td>
<td>{data.TINC_CONT}</td>
<td>{data.CONT_2}</td>
<td>{data.POS_DIAG}</td>
<td>{data.DIAG_3}</td>
<td>{data.NEG_DIAG}</td>
<td>{data.DIAG_4}</td>
<td>{data.NEG_CONT}</td>
<td>{data.CONT_4}</td>
<td>{data.EXT_ADE}</td>
<td>{data.EXT_INA}</td>
<td>{data.TIN_ADE}</td>
<td>{data.TIN_INA}</td>
<td>{data.TOT_BAC}</td>
<td>{data.OBSERVA}</td>
<td>{data.FEC_VAL}</td>
<td>{data.FEC_CAP}</td>
<td>{data.FEC_IMP}</td>
<td>{data.VALIDADO}</td>
<td>{data.CLACAU}</td>
<td>{data.SUPLEMENTO}</td>
<td>
<Link class="btn btn-outline-info "  to={"/tblcalidad2Edit/"+data.idtblcalidad2} >Edit</Link>
</td>
<td>
  <button class="btn btn-outline-danger "> Delete </button>
</td>
</tr>
)
}
)
}
}
export default listComponent;
