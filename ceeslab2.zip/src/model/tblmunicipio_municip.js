const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tblmunicipio_municip')
var nametable = 'tblmunicipio_municip';
var tblmunicipio_municip = sequelize.define(nametable,{
idtblmunicipio_municip:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


CLAMUN:  Sequelize.STRING,
MUNICIPIO:  Sequelize.STRING,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tblmunicipio_municip;
