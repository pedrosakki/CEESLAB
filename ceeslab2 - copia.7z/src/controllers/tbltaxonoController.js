 const controllers = {}
var sequelize = require('../model/database');
var tbltaxono = require('../model/tbltaxono');

//METODO GET//

controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tbltaxono.findAll({
where: {idtbltaxono: id }  })
.then(function(data){
    return data;})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}


//METODO LIST//

controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tbltaxono.findAll();
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}



//METODO CREATE//
controllers.create = async (req, res)=>{
const  {MUESTRA,C_ENVASE,ENVASE,C_ESPECIME,GENERO,ESPECIE,TOXICIDAD,VECTOR,C_VISITADA,C_POSITIVA,ICP,IIC,FEC_REP,FEC_COL,SITIO,COLECTOR,SUPLEMENTO,CLAPRO,CLAMUN,CLAEDO,OBSERV}=req.body;
const data = await tbltaxono.create({
MUESTRA: MUESTRA,
C_ENVASE: C_ENVASE,
ENVASE: ENVASE,
C_ESPECIME: C_ESPECIME,
GENERO: GENERO,
ESPECIE: ESPECIE,
TOXICIDAD: TOXICIDAD,
VECTOR: VECTOR,
C_VISITADA: C_VISITADA,
C_POSITIVA: C_POSITIVA,
ICP: ICP,
IIC: IIC,
FEC_REP: FEC_REP,
FEC_COL: FEC_COL,
SITIO: SITIO,
COLECTOR: COLECTOR,
SUPLEMENTO: SUPLEMENTO,
CLAPRO: CLAPRO,
CLAMUN: CLAMUN,
CLAEDO: CLAEDO,
OBSERV: OBSERV
}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data
})
}


//METODO UPDATE//
controllers.update = async (req, res)=>{
  const { id } = req.params;
const  {MUESTRA,C_ENVASE,ENVASE,C_ESPECIME,GENERO,ESPECIE,TOXICIDAD,VECTOR,C_VISITADA,C_POSITIVA,ICP,IIC,FEC_REP,FEC_COL,SITIO,COLECTOR,SUPLEMENTO,CLAPRO,CLAMUN,CLAEDO,OBSERV}=req.body;

 const data = await tbltaxono.update({
MUESTRA: MUESTRA,
C_ENVASE: C_ENVASE,
ENVASE: ENVASE,
C_ESPECIME: C_ESPECIME,
GENERO: GENERO,
ESPECIE: ESPECIE,
TOXICIDAD: TOXICIDAD,
VECTOR: VECTOR,
C_VISITADA: C_VISITADA,
C_POSITIVA: C_POSITIVA,
ICP: ICP,
IIC: IIC,
FEC_REP: FEC_REP,
FEC_COL: FEC_COL,
SITIO: SITIO,
COLECTOR: COLECTOR,
SUPLEMENTO: SUPLEMENTO,
CLAPRO: CLAPRO,
CLAMUN: CLAMUN,
CLAEDO: CLAEDO,
OBSERV: OBSERV
   },{
          where: { idtbltaxono: id}
     })
  .then( function(data){
    return data;
      })
       .catch(error => {
        return error;
   }) 
   res.json({success:true, data:data, message:"Updated successful"});
 }



 module.exports = controllers;
