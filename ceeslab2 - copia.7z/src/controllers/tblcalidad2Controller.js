 const controllers = {}
var sequelize = require('../model/database');
var tblcalidad2 = require('../model/tblcalidad2');

//METODO GET//

controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tblcalidad2.findAll({
where: {idtblcalidad2: id }  })
.then(function(data){
    return data;})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}


//METODO LIST//

controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tblcalidad2.findAll();
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}



//METODO CREATE//
controllers.create = async (req, res)=>{
const  {IDTBLCALIDAD2,MUESTRA,CLAPRO,CLAMUE,OFICIO,FEC_REP,TIPO,MES,LABORATORIO,REV_DIAG,DIAG_0,REV_CONT,CONT_0,DIAG_1,EXT_CONT,CONT_1,TINC_DIAG,DIAG_2,TINC_CONT,CONT_2,POS_DIAG,DIAG_3,NEG_DIAG,DIAG_4,NEG_CONT,CONT_4,EXT_ADE,EXT_INA,TIN_ADE,TIN_INA,TOT_BAC,OBSERVA,FEC_VAL,FEC_CAP,FEC_IMP,VALIDADO,CLACAU,SUPLEMENTO}=req.body;
const data = await tblcalidad2.create({
IDTBLCALIDAD2: IDTBLCALIDAD2,
MUESTRA: MUESTRA,
CLAPRO: CLAPRO,
CLAMUE: CLAMUE,
OFICIO: OFICIO,
FEC_REP: FEC_REP,
TIPO: TIPO,
MES: MES,
LABORATORIO: LABORATORIO,
REV_DIAG: REV_DIAG,
DIAG_0: DIAG_0,
REV_CONT: REV_CONT,
CONT_0: CONT_0,
DIAG_1: DIAG_1,
EXT_CONT: EXT_CONT,
CONT_1: CONT_1,
TINC_DIAG: TINC_DIAG,
DIAG_2: DIAG_2,
TINC_CONT: TINC_CONT,
CONT_2: CONT_2,
POS_DIAG: POS_DIAG,
DIAG_3: DIAG_3,
NEG_DIAG: NEG_DIAG,
DIAG_4: DIAG_4,
NEG_CONT: NEG_CONT,
CONT_4: CONT_4,
EXT_ADE: EXT_ADE,
EXT_INA: EXT_INA,
TIN_ADE: TIN_ADE,
TIN_INA: TIN_INA,
TOT_BAC: TOT_BAC,
OBSERVA: OBSERVA,
FEC_VAL: FEC_VAL,
FEC_CAP: FEC_CAP,
FEC_IMP: FEC_IMP,
VALIDADO: VALIDADO,
CLACAU: CLACAU,
SUPLEMENTO: SUPLEMENTO
}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data
})
}


//METODO UPDATE//
controllers.update = async (req, res)=>{
  const { id } = req.params;
const  {IDTBLCALIDAD2,MUESTRA,CLAPRO,CLAMUE,OFICIO,FEC_REP,TIPO,MES,LABORATORIO,REV_DIAG,DIAG_0,REV_CONT,CONT_0,DIAG_1,EXT_CONT,CONT_1,TINC_DIAG,DIAG_2,TINC_CONT,CONT_2,POS_DIAG,DIAG_3,NEG_DIAG,DIAG_4,NEG_CONT,CONT_4,EXT_ADE,EXT_INA,TIN_ADE,TIN_INA,TOT_BAC,OBSERVA,FEC_VAL,FEC_CAP,FEC_IMP,VALIDADO,CLACAU,SUPLEMENTO}=req.body;

 const data = await tblcalidad2.update({
IDTBLCALIDAD2: IDTBLCALIDAD2,
MUESTRA: MUESTRA,
CLAPRO: CLAPRO,
CLAMUE: CLAMUE,
OFICIO: OFICIO,
FEC_REP: FEC_REP,
TIPO: TIPO,
MES: MES,
LABORATORIO: LABORATORIO,
REV_DIAG: REV_DIAG,
DIAG_0: DIAG_0,
REV_CONT: REV_CONT,
CONT_0: CONT_0,
DIAG_1: DIAG_1,
EXT_CONT: EXT_CONT,
CONT_1: CONT_1,
TINC_DIAG: TINC_DIAG,
DIAG_2: DIAG_2,
TINC_CONT: TINC_CONT,
CONT_2: CONT_2,
POS_DIAG: POS_DIAG,
DIAG_3: DIAG_3,
NEG_DIAG: NEG_DIAG,
DIAG_4: DIAG_4,
NEG_CONT: NEG_CONT,
CONT_4: CONT_4,
EXT_ADE: EXT_ADE,
EXT_INA: EXT_INA,
TIN_ADE: TIN_ADE,
TIN_INA: TIN_INA,
TOT_BAC: TOT_BAC,
OBSERVA: OBSERVA,
FEC_VAL: FEC_VAL,
FEC_CAP: FEC_CAP,
FEC_IMP: FEC_IMP,
VALIDADO: VALIDADO,
CLACAU: CLACAU,
SUPLEMENTO: SUPLEMENTO
   },{
          where: { idtblcalidad2: id}
     })
  .then( function(data){
    return data;
      })
       .catch(error => {
        return error;
   }) 
   res.json({success:true, data:data, message:"Updated successful"});
 }



 module.exports = controllers;
