import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { Link } from "react-router-dom";
import axios from 'axios';
const url= 'http://localhost:3000/Rtblcalidad7/list';
class listComponent extends React.Component  {
constructor(props){
super(props);
this.state ={
listtblcalidad7:[]
}
}
componentDidMount(){
axios.get(url)
.then(res=>{
if(res.data.sucess){
const data = res.data.data
this.setState({listtblcalidad7:data})
}
else{
alert("Error web service")
}
})
.catch(error=>{
alert("Error Server"+error)
})
}
render()
{
    return (
      <table class="table table-hover table-striped">

        <thead class="thead-dark">

<tr>
<th scope = "col" >#</th>
<th scope ="col" >MUESTRA</th>
<th scope ="col" >CLAPRO</th>
<th scope ="col" >CLAMUE</th>
<th scope ="col" >OFICIO</th>
<th scope ="col" >FEC_REP</th>
<th scope ="col" >OBSERVA</th>
<th scope ="col" >CITOTECNO</th>
<th scope ="col" >LR</th>
<th scope ="col" >TLI</th>
<th scope ="col" >CRN</th>
<th scope ="col" >CRP</th>
<th scope ="col" >IPD</th>
<th scope ="col" >EL_LPRNE</th>
<th scope ="col" >EL_LPRMS</th>
<th scope ="col" >EL_LPRT</th>
<th scope ="col" >EL_LPRP</th>
<th scope ="col" >EL_LNRNE</th>
<th scope ="col" >EL_LNRNS</th>
<th scope ="col" >EL_LNRT</th>
<th scope ="col" >EL_LNRP</th>
<th scope ="col" >CD_PDN</th>
<th scope ="col" >CD_PDP</th>
<th scope ="col" >CD_PD_FPN</th>
<th scope ="col" >CD_NDN</th>
<th scope ="col" >CD_NDP</th>
<th scope ="col" >CD_ND_FNN</th>
<th scope ="col" >CD_ND_IN</th>
<th scope ="col" >TOT_IN</th>
<th scope ="col" >TOT_IP</th>
<th scope ="col" >FEC_CAP</th>
<th scope ="col" >FEC_IMP</th>
<th scope ="col" >FEC_VAL</th>
<th scope ="col" >VALIDADO</th>
<th scope ="col" >CLACAU</th>
<th scope ="col" >SUPLEMENTO</th>
<th colspan="2" >Acciones</th>
</tr>
        </thead>
<tbody>
        {this.loadFilData()}
        </tbody>
      </table>
    );
  }
loadFilData(){
return this.state.listtblcalidad7.map((data)=>{
return(
  <tr>
  <th>{data.idtblcalidad7}</th>

<td>{data.MUESTRA}</td>
<td>{data.CLAPRO}</td>
<td>{data.CLAMUE}</td>
<td>{data.OFICIO}</td>
<td>{data.FEC_REP}</td>
<td>{data.OBSERVA}</td>
<td>{data.CITOTECNO}</td>
<td>{data.LR}</td>
<td>{data.TLI}</td>
<td>{data.CRN}</td>
<td>{data.CRP}</td>
<td>{data.IPD}</td>
<td>{data.EL_LPRNE}</td>
<td>{data.EL_LPRMS}</td>
<td>{data.EL_LPRT}</td>
<td>{data.EL_LPRP}</td>
<td>{data.EL_LNRNE}</td>
<td>{data.EL_LNRNS}</td>
<td>{data.EL_LNRT}</td>
<td>{data.EL_LNRP}</td>
<td>{data.CD_PDN}</td>
<td>{data.CD_PDP}</td>
<td>{data.CD_PD_FPN}</td>
<td>{data.CD_NDN}</td>
<td>{data.CD_NDP}</td>
<td>{data.CD_ND_FNN}</td>
<td>{data.CD_ND_IN}</td>
<td>{data.TOT_IN}</td>
<td>{data.TOT_IP}</td>
<td>{data.FEC_CAP}</td>
<td>{data.FEC_IMP}</td>
<td>{data.FEC_VAL}</td>
<td>{data.VALIDADO}</td>
<td>{data.CLACAU}</td>
<td>{data.SUPLEMENTO}</td>
<td>
<Link class="btn btn-outline-info "  to={"/tblcalidad7Edit/"+data.idtblcalidad7} >Edit</Link>
</td>
<td>
  <button class="btn btn-outline-danger "> Delete </button>
</td>
</tr>
)
}
)
}
}
export default listComponent;
