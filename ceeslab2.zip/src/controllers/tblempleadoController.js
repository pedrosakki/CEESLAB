 const controllers = {}

//import model and sequelize


var tblpuesto = require('../model/tblpuesto');
var sequelize = require('../model/database');
//var tblempleado = require('../model/tblempleado');
var tblempleado = require('../model/User');



controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tblempleado.findAll({
 where: {idtblempleado: id },
include: [tblpuesto]})
.then(function(data){
    return data;
})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}

controllers.postLogin = async(req,res)=>{
  const {id}= req.params.id;
  const {password}= req.params.password;
  console.log("en controller");
  console.log(req.params.id  + req.params.password);
  const data = await tblempleado.findOne({
   where: {id: id,
           password:password},
 // include: [tblpuesto]
})
  .then(function(data){
      return data;
  })
  .catch(error =>{
  return error;})
  res.json({sucess:true,data})
  }
//METODO LIST//
controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tblempleado.findAll({include: [tblpuesto]});
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}



controllers.create = async (req, res)=>{
const {apellidopaterno,apellidomaterno,idpuesto}=req.body;
const data = await tblempleado.create({

  apellidopaterno: apellidopaterno,
apellidomaterno: apellidomaterno,
idpuesto: idpuesto

}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data

})
}



controllers.update = async (req, res)=>{
        // parameter get id
        const { id } = req.params;
        // parameter POST
        const {apellidopaterno,apellidomaterno,idpuesto}=req.body;// Update data
        
        const data = await tblempleado.update({
            apellidopaterno: apellidopaterno,
            apellidomaterno: apellidomaterno,
            idpuesto: idpuesto
        },
        {
          where: { idtblempleado: id}
        })
        .then( function(data){
          return data;
        })
        .catch(error => {
          return error;
        }) 
        res.json({success:true, data:data, message:"Updated successful"});
      }





    









 controllers.test =(req,res)=>{

const data = {
nombre: "ANGEL",
apellidopaterno: "",
apeliidomaterno: "",
idpuesto: 1
}

console.log("Execute from controllers Empleados")
res.json(data);


 }

 module.exports = controllers;