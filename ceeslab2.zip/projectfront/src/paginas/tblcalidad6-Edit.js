import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios'
const baseUrl= "http: //localhost:3000"
class EditComponent extends React.Component{

constructor(props){

super(props);
this.state={
edittblcalidad6s:[],
datatblcalidad6:{},
MUESTRA: "",
N_QUIRUR: "",
CLINICA: "",
CLAMUN: "",
CUP: "",
CURP: "",
NOMBRES: "",
APELLIDO_P: "",
APELLIDO_M: "",
FEC_NAC: "",
EDAD: "",
CLAEDO: "",
AFILIACION: "",
EXPEDIENTE: "",
FEC_TOM: "",
RECHAZADA: "",
RECHAZADA1: "",
T_ESTUDIO: "",
T_ESTUDIO_1: "",
HIBRIDOS: "",
HIB_RES: "",
PCR: "",
PCR_RES: "",
DP_CIT1: "",
DP_CIT2: "",
DP_CIT3: "",
DP_CIT4: "",
DP_CIT5: "",
DP_COL1: "",
DP_COL2: "",
DP_HIS1: "",
DP_HIS2: "",
DP_HIS3: "",
MEDICO: "",
N_QUIRURP: "",
FEC_DIAG: "",
DM_FFRAGMEN: "",
DM_MIDE: "",
DM_FORMA: "",
DM_ASPECTO: "",
DM_COLOR: "",
DM_CASETES: "",
DM_RCASETE: "",
DIAG_HIS1: "",
DIAG_HIS01: "",
DIAG_HIS2: "",
DIAG_HIS02: "",
LIMITES_Q: "",
OBSERVA: "",
FEC_REP: "",
FEC_CAP: "",
FEC_IMP: "",
FEC_VAL: "",
PATOLOGO: "",
VALIDADO: "",
RFC: "",
CLACAU: "",
SUPLEMENTO: ""
}
}


componentDidMount(){
let userId = this.props.match.params.tblcalidad6id;
  const url = baseUrl+"/Rtblcalidad6/get/"+userId

  axios.get(url)
 .then(res=>{
  if(res.data.sucess){
  const data = res.data.data[0] 
this.setState({
edittblcalidad6s:data,
MUESTRA: data.MUESTRA,
N_QUIRUR: data.N_QUIRUR,
CLINICA: data.CLINICA,
CLAMUN: data.CLAMUN,
CUP: data.CUP,
CURP: data.CURP,
NOMBRES: data.NOMBRES,
APELLIDO_P: data.APELLIDO_P,
APELLIDO_M: data.APELLIDO_M,
FEC_NAC: data.FEC_NAC,
EDAD: data.EDAD,
CLAEDO: data.CLAEDO,
AFILIACION: data.AFILIACION,
EXPEDIENTE: data.EXPEDIENTE,
FEC_TOM: data.FEC_TOM,
RECHAZADA: data.RECHAZADA,
RECHAZADA1: data.RECHAZADA1,
T_ESTUDIO: data.T_ESTUDIO,
T_ESTUDIO_1: data.T_ESTUDIO_1,
HIBRIDOS: data.HIBRIDOS,
HIB_RES: data.HIB_RES,
PCR: data.PCR,
PCR_RES: data.PCR_RES,
DP_CIT1: data.DP_CIT1,
DP_CIT2: data.DP_CIT2,
DP_CIT3: data.DP_CIT3,
DP_CIT4: data.DP_CIT4,
DP_CIT5: data.DP_CIT5,
DP_COL1: data.DP_COL1,
DP_COL2: data.DP_COL2,
DP_HIS1: data.DP_HIS1,
DP_HIS2: data.DP_HIS2,
DP_HIS3: data.DP_HIS3,
MEDICO: data.MEDICO,
N_QUIRURP: data.N_QUIRURP,
FEC_DIAG: data.FEC_DIAG,
DM_FFRAGMEN: data.DM_FFRAGMEN,
DM_MIDE: data.DM_MIDE,
DM_FORMA: data.DM_FORMA,
DM_ASPECTO: data.DM_ASPECTO,
DM_COLOR: data.DM_COLOR,
DM_CASETES: data.DM_CASETES,
DM_RCASETE: data.DM_RCASETE,
DIAG_HIS1: data.DIAG_HIS1,
DIAG_HIS01: data.DIAG_HIS01,
DIAG_HIS2: data.DIAG_HIS2,
DIAG_HIS02: data.DIAG_HIS02,
LIMITES_Q: data.LIMITES_Q,
OBSERVA: data.OBSERVA,
FEC_REP: data.FEC_REP,
FEC_CAP: data.FEC_CAP,
FEC_IMP: data.FEC_IMP,
FEC_VAL: data.FEC_VAL,
PATOLOGO: data.PATOLOGO,
VALIDADO: data.VALIDADO,
RFC: data.RFC,
CLACAU: data.CLACAU,
SUPLEMENTO: data.SUPLEMENTO
} ) }
else{
alert("Error web service")
} } )
  .catch(error=>{
  })
}


  render(){
   let userId = 0;
 return (
<div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MUESTRA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.MUESTRA} onChange={(value)=> this.setState({MUESTRA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">N_QUIRUR </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.N_QUIRUR} onChange={(value)=> this.setState({N_QUIRUR:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLINICA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLINICA} onChange={(value)=> this.setState({CLINICA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAMUN </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAMUN} onChange={(value)=> this.setState({CLAMUN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CUP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CUP} onChange={(value)=> this.setState({CUP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CURP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CURP} onChange={(value)=> this.setState({CURP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">NOMBRES </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.NOMBRES} onChange={(value)=> this.setState({NOMBRES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">APELLIDO_P </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.APELLIDO_P} onChange={(value)=> this.setState({APELLIDO_P:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">APELLIDO_M </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.APELLIDO_M} onChange={(value)=> this.setState({APELLIDO_M:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_NAC </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_NAC} onChange={(value)=> this.setState({FEC_NAC:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EDAD </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EDAD} onChange={(value)=> this.setState({EDAD:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAEDO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAEDO} onChange={(value)=> this.setState({CLAEDO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">AFILIACION </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.AFILIACION} onChange={(value)=> this.setState({AFILIACION:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXPEDIENTE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXPEDIENTE} onChange={(value)=> this.setState({EXPEDIENTE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_TOM </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_TOM} onChange={(value)=> this.setState({FEC_TOM:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RECHAZADA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RECHAZADA} onChange={(value)=> this.setState({RECHAZADA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RECHAZADA1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RECHAZADA1} onChange={(value)=> this.setState({RECHAZADA1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">T_ESTUDIO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.T_ESTUDIO} onChange={(value)=> this.setState({T_ESTUDIO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">T_ESTUDIO_1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.T_ESTUDIO_1} onChange={(value)=> this.setState({T_ESTUDIO_1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">HIBRIDOS </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.HIBRIDOS} onChange={(value)=> this.setState({HIBRIDOS:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">HIB_RES </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.HIB_RES} onChange={(value)=> this.setState({HIB_RES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">PCR </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.PCR} onChange={(value)=> this.setState({PCR:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">PCR_RES </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.PCR_RES} onChange={(value)=> this.setState({PCR_RES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DP_CIT1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DP_CIT1} onChange={(value)=> this.setState({DP_CIT1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DP_CIT2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DP_CIT2} onChange={(value)=> this.setState({DP_CIT2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DP_CIT3 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DP_CIT3} onChange={(value)=> this.setState({DP_CIT3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DP_CIT4 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DP_CIT4} onChange={(value)=> this.setState({DP_CIT4:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DP_CIT5 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DP_CIT5} onChange={(value)=> this.setState({DP_CIT5:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DP_COL1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DP_COL1} onChange={(value)=> this.setState({DP_COL1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DP_COL2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DP_COL2} onChange={(value)=> this.setState({DP_COL2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DP_HIS1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DP_HIS1} onChange={(value)=> this.setState({DP_HIS1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DP_HIS2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DP_HIS2} onChange={(value)=> this.setState({DP_HIS2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DP_HIS3 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DP_HIS3} onChange={(value)=> this.setState({DP_HIS3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MEDICO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.MEDICO} onChange={(value)=> this.setState({MEDICO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">N_QUIRURP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.N_QUIRURP} onChange={(value)=> this.setState({N_QUIRURP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_DIAG </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_DIAG} onChange={(value)=> this.setState({FEC_DIAG:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DM_FFRAGMEN </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DM_FFRAGMEN} onChange={(value)=> this.setState({DM_FFRAGMEN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DM_MIDE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DM_MIDE} onChange={(value)=> this.setState({DM_MIDE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DM_FORMA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DM_FORMA} onChange={(value)=> this.setState({DM_FORMA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DM_ASPECTO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DM_ASPECTO} onChange={(value)=> this.setState({DM_ASPECTO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DM_COLOR </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DM_COLOR} onChange={(value)=> this.setState({DM_COLOR:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DM_CASETES </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DM_CASETES} onChange={(value)=> this.setState({DM_CASETES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DM_RCASETE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DM_RCASETE} onChange={(value)=> this.setState({DM_RCASETE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DIAG_HIS1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DIAG_HIS1} onChange={(value)=> this.setState({DIAG_HIS1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DIAG_HIS01 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DIAG_HIS01} onChange={(value)=> this.setState({DIAG_HIS01:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DIAG_HIS2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DIAG_HIS2} onChange={(value)=> this.setState({DIAG_HIS2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DIAG_HIS02 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DIAG_HIS02} onChange={(value)=> this.setState({DIAG_HIS02:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">LIMITES_Q </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.LIMITES_Q} onChange={(value)=> this.setState({LIMITES_Q:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OBSERVA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.OBSERVA} onChange={(value)=> this.setState({OBSERVA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_REP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_REP} onChange={(value)=> this.setState({FEC_REP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_CAP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_CAP} onChange={(value)=> this.setState({FEC_CAP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_IMP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_IMP} onChange={(value)=> this.setState({FEC_IMP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_VAL </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_VAL} onChange={(value)=> this.setState({FEC_VAL:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">PATOLOGO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.PATOLOGO} onChange={(value)=> this.setState({PATOLOGO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">VALIDADO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.VALIDADO} onChange={(value)=> this.setState({VALIDADO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RFC </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RFC} onChange={(value)=> this.setState({RFC:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLACAU </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLACAU} onChange={(value)=> this.setState({CLACAU:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SUPLEMENTO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.SUPLEMENTO} onChange={(value)=> this.setState({SUPLEMENTO:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendUpdate()}>Update</button>  
</div>
); }
sendUpdate(){
let userId = this.props.match.params.tblcalidad6id;
const baseUrl = "http://localhost:3000/Rtblcalidad6/Update/"+ userId
const datapost = {
MUESTRA: this.state.MUESTRA,
N_QUIRUR: this.state.N_QUIRUR,
CLINICA: this.state.CLINICA,
CLAMUN: this.state.CLAMUN,
CUP: this.state.CUP,
CURP: this.state.CURP,
NOMBRES: this.state.NOMBRES,
APELLIDO_P: this.state.APELLIDO_P,
APELLIDO_M: this.state.APELLIDO_M,
FEC_NAC: this.state.FEC_NAC,
EDAD: this.state.EDAD,
CLAEDO: this.state.CLAEDO,
AFILIACION: this.state.AFILIACION,
EXPEDIENTE: this.state.EXPEDIENTE,
FEC_TOM: this.state.FEC_TOM,
RECHAZADA: this.state.RECHAZADA,
RECHAZADA1: this.state.RECHAZADA1,
T_ESTUDIO: this.state.T_ESTUDIO,
T_ESTUDIO_1: this.state.T_ESTUDIO_1,
HIBRIDOS: this.state.HIBRIDOS,
HIB_RES: this.state.HIB_RES,
PCR: this.state.PCR,
PCR_RES: this.state.PCR_RES,
DP_CIT1: this.state.DP_CIT1,
DP_CIT2: this.state.DP_CIT2,
DP_CIT3: this.state.DP_CIT3,
DP_CIT4: this.state.DP_CIT4,
DP_CIT5: this.state.DP_CIT5,
DP_COL1: this.state.DP_COL1,
DP_COL2: this.state.DP_COL2,
DP_HIS1: this.state.DP_HIS1,
DP_HIS2: this.state.DP_HIS2,
DP_HIS3: this.state.DP_HIS3,
MEDICO: this.state.MEDICO,
N_QUIRURP: this.state.N_QUIRURP,
FEC_DIAG: this.state.FEC_DIAG,
DM_FFRAGMEN: this.state.DM_FFRAGMEN,
DM_MIDE: this.state.DM_MIDE,
DM_FORMA: this.state.DM_FORMA,
DM_ASPECTO: this.state.DM_ASPECTO,
DM_COLOR: this.state.DM_COLOR,
DM_CASETES: this.state.DM_CASETES,
DM_RCASETE: this.state.DM_RCASETE,
DIAG_HIS1: this.state.DIAG_HIS1,
DIAG_HIS01: this.state.DIAG_HIS01,
DIAG_HIS2: this.state.DIAG_HIS2,
DIAG_HIS02: this.state.DIAG_HIS02,
LIMITES_Q: this.state.LIMITES_Q,
OBSERVA: this.state.OBSERVA,
FEC_REP: this.state.FEC_REP,
FEC_CAP: this.state.FEC_CAP,
FEC_IMP: this.state.FEC_IMP,
FEC_VAL: this.state.FEC_VAL,
PATOLOGO: this.state.PATOLOGO,
VALIDADO: this.state.VALIDADO,
RFC: this.state.RFC,
CLACAU: this.state.CLACAU,
SUPLEMENTO: this.state.SUPLEMENTO
}
axios.post(baseUrl,datapost)
.then(response=>{
if (response.data.success===true) {
alert(response.data.message)
}
else {
alert(response.data.message)
alert(JSON.stringify(response))
}
}).catch(error=>{
alert("Error 34 "+error)
})
}
}
export default EditComponent;
