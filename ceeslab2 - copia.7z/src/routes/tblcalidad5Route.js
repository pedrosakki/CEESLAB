const express = require('express');
const router = express.Router();
const tblcalidad5Controller = require('../Controllers/tblcalidad5Controller')


router.post('/update/:id',tblcalidad5Controller.update)
router.get('/get/:id', tblcalidad5Controller.get)
router.get('/list', tblcalidad5Controller.list);
router.post('/create', tblcalidad5Controller.create);


module.exports = router;
