const express = require('express');
const router = express.Router();
const tblmunicipio_municipController = require('../Controllers/tblmunicipio_municipController')


router.post('/update/:id',tblmunicipio_municipController.update)
router.get('/get/:id', tblmunicipio_municipController.get)
router.get('/list', tblmunicipio_municipController.list);
router.post('/create', tblmunicipio_municipController.create);


module.exports = router;
