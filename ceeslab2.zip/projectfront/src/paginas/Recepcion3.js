import React, { Component } from 'react'
import { ultimaMuestra } from './UserFunctions'  
//import { altaMuestra } from './UserFunctions'
import { altaRecepcion } from './UserFunctions'
import clsx from 'clsx';
import { makeStyles } from '@material-ui/core/styles';
import MenuItem from '@material-ui/core/MenuItem';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import Icon from '@material-ui/core/Icon';
import DoubleArrowOutlinedIcon from '@material-ui/icons/DoubleArrowOutlined';

import Imagen from '../nuevo.png'
//import './date-fns';
import Grid from '@material-ui/core/Grid';
//import DateFnsUtils from '@date-io/date-fns';
import MaterialInput from '@material-ui/core/Input';
//import MaterialTable from 'material-table';
//import Tabla from './TablaTipoM';
import Tbl from './Tbl';
import TbltipoM from './TbltipoM';
import Checkbox from '@material-ui/core/Checkbox';
//import Mensaje from './Mensaje'
import { Loader,Container, Header, List } from "semantic-ui-react";
//import Tabla0 from './TablaTipo';
//import Tabla0 from './TodasReg';
//import Tabla from './TablaBase'
//import MaskedInput from 'react-text-mask'
/*import {
  MuiPickersUtilsProvider,
  KeyboardTimePicker,
  KeyboardDatePicker,
} from '@material-ui/pickers';*/
import 'moment/locale/it.js';
//import InputMask from 'react-input-mask';
import { saveAs } from 'file-saver';
import axios from 'axios';

//import { DatePicker, DatePickerInput } from 'rc-datepicker';
//const RadioGroup = ReactRadioButtonsGroup.ReactRadioButtonsGroup;
//const RadioButton = ReactRadioButtonsGroup.ReactRadioButton;

class Recepcion extends Component {
  constructor() {
    super()
    this.state = {
      data:'',
     // val:'',
      idTipo: '',
      fecha:'',
      hora:'',
      min:'',
      procedencia:'',
      procedenciaH:'',
      tipo:'',
      tipoH:'',
      ctrlCalidad:'NO',
      ampliarAmbiental: '',
      confirmarCepa: '',
      temp: '',
      observaciones: '',
      analisisSolicitado: '',
      motivo:'',
      prioridad:false,
      claveExa1:'',
      microbiolog:false,
      fisicoQ:false,
      toxicolog:false,
      metalesPe:false,
    //  options:{ weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' },
    //  today : new Date(),
      ultima:''
    //  selectedOption: "option1",

        }
    this.getResponse = this.getResponse.bind(this)    
    this.getResponseH = this.getResponseH.bind(this) 
    this.getResponseTipo = this.getResponseTipo.bind(this)   
    this.getResponseTipoH = this.getResponseTipoH.bind(this)
    this.onChange = this.onChange.bind(this)
    this.onChangeProced = this.onChangeProced.bind(this)
    this.onSubmit = this.onSubmit.bind(this)
    this.handleInputChange = this.handleInputChange.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.handlePlatformChange = this.handlePlatformChange.bind(this);
    this.handlePrioridadChange = this.handlePrioridadChange.bind(this);
    this.handleControlChange = this.handleControlChange.bind(this);
    this.handleMicroChange = this.handleMicroChange.bind(this);
    this.handlefisicoQChange = this.handlefisicoQChange.bind(this);
    this.handletoxicologChange = this.handletoxicologChange.bind(this);
    this.handlemetalesPeChange = this.handlemetalesPeChange.bind(this);
    this.handleProcedenciaChange = this.handleProcedenciaChange.bind(this);
    this.handleProcedenciaChange2 = this.handleProcedenciaChange2.bind(this);
    this.createAndDownloadPdf = this.createAndDownloadPdf.bind(this);

  }

  getResponse(procedencia){this.setState({procedencia}); }
  getResponseH(procedenciaH){this.setState({procedenciaH}); }
  getResponseTipo(tipo){this.setState({tipo}); }
  getResponseTipoH(tipoH){this.setState({tipoH}); }

  createAndDownloadPdf = () => {
    axios.post('/create-pdf', this.state)
      .then(() => axios.get('fetch-pdf', { responseType: 'blob' }))
      .then((res) => {
        const pdfBlob = new Blob([res.data], { type: 'application/pdf' });
        saveAs(pdfBlob, this.state.idTipo+'.pdf');
      })
  }

  onChange(e) {
    console.log("Name:"+e.target.name);
    console.log("VALUE:"+e.target.value);
    this.setState({ [e.target.name]: e.target.value })
  }

  onSubmit(e) {
    e.preventDefault() 
   var inputsTipo =document.querySelector("input[name='inTipoMuestraH']").value;  
   var inputsPro =document.querySelector("input[name='inProcedH']").value;  
    const newRecep = {
      idTipo: this.state.idTipo,
      fecha: this.state.fecha,
      procedencia:inputsPro,
      tipo:inputsTipo,
      ctrlCalidad: this.state.ctrlCalidad,
      ampliarAmbiental: this.state.ampliarAmbiental,
      confirmarCepa: this.state.confirmarCepa,
      temp: this.state.temp,
      observaciones: this.state.observaciones,
      analisisSolicitado: this.state.analisisSolicitado,
      motivo: this.state.motivo,
      prioridad: this.state.prioridad,
      claveExa1:this.state.claveExa1,
      microbiolog:this.state.microbiolog,
      fisicoQ:this.state.fisicoQ,
      toxicolog:this.state.toxicolog,
      metalesPe:this.state.metalesPe,
     
    }
    //var idprocedencia=$("#formRecep #inProced").val(function(n, c){return c + c; });
    altaRecepcion(newRecep).then(res => {
      console.log(newRecep);
      this.props.history.push(`/login`)
      this.props.history.push(`/recepcion`)

    })
  }
  handleSubmit(event) {
     alert('A registro fue enviado: ' + this.state.value);
     event.preventDefault();
   }

   handlePlatformChange(event) {
    var val = event.currentTarget.querySelector("input").value;
    this.setState({ motivo: val });
  }

  onChangeProced(e) {
    //console.log(data)
    console.log("clic desde el hijo");
    console.log("Name:"+e.target.name);
    console.log("VALUE:"+e.target.value);
    this.setState({ [e.target.name]: e.target.value })
  }

  handleProcedenciaChange=(val)=> {
    console.log("clic desde el hijo");
    console.log("en handleProcedenciaChange");
    //var val = event.currentTarget.querySelector("input").value;
    this.setState({ procedencia: val });
  }

  handleProcedenciaChange2(event) {
  //  console.log(this.refs.aquiData.data);
    console.log("en handleProcedenciaChange");
  //  var val= this.refs.aquiData.data
    var val = event.currentTarget.querySelector("input").value;
    this.setState({ procedencia: val });
  }
  

  handlePrioridadChange(event) {
    var val = event.currentTarget.querySelector("input").value;
    this.setState({ prioridad: val});
  }
  handleControlChange(event) {
    var val = event.currentTarget.querySelector("input").value;
    this.setState({ ctrlCalidad: val });
  }
   
   handleChange(event) {
    this.setState({
      motivo: event.target.value
    });
  }

  handleMicroChange(event) {
    var val = event.currentTarget.querySelector("input").checked
    if( val ) {    this.setState({microbiolog:true})       }
  }
  handlefisicoQChange(event) {
    var val = event.currentTarget.querySelector("input").checked
    if( val ) {    this.setState({fisicoQ:true})       }
  }
  handletoxicologChange(event) {
    var val = event.currentTarget.querySelector("input").checked
    if( val ) {    this.setState({toxicolog:true})       }
  }
  handlemetalesPeChange(event) {
    var val = event.currentTarget.querySelector("input").checked
    if( val ) {    this.setState({metalesPe:true})       }
  }

  handleInputChange(event) {
    const target = event.target;
    const value = target.type === 'checkbox' ? target.checked : target.value;
    const name = target.name;
    this.setState({
      [name]: value
    });
  }

  onRadiochange = value => {
    console.log(value);
  };

   componentDidMount() {
    //this.timerID = setInterval(() => this.tick(),1000 );
    ultimaMuestra()
    .then(res => {
      console.log(res+1);
      if (res) {       //si hubo datos de la ultima muestra
             this.setState({idTipo:res+1})             
             console.log('this.state de id....'+ this.state.idTipo)
    }else { console.log("no hay datos de la ULTIMA muestra");} //lanzar alerta de que le user no existe
    })
    this.fecha.focus(); 
  }
 // componentWillUnmount() {  clearInterval(this.timerID);  }
  //tick() {  this.setState({   fecha: new Date()   });  }

render() {
  //var options={ weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  //const procModal = this.props.procModal;
  
return (
<div className="container">

  <form noValidate id="formRecep" onSubmit={this.onSubmit}>
 
    <div className="row">
       <div className="col-md-1 mt-6 mx-auto"><h6 className="display-6">Muestra:</h6></div>
       <div className="col-md-7 mt-6 mx-auto">                        
                       <h6 className="display-4 text-danger">{this.state.idTipo}</h6> 
       </div>  
       <div className="col-md-4 mt-6 mx-auto">
       <div className="input-group input-group-sm mb-3">
        <div className="input-group-prepend">
              <span className="input-group-text font-weight-bold" id="basic-addon1">Fecha</span>
                  <input
                  required
                  ref={(input) => { this.fecha = input; }} 
              type="datetime-local"
              maxLength="2"
            className="form-control"
            name="fecha"
            placeholder=""
          value={this.state.fecha}
         // value={this.state.fecha}
            onChange={this.onChange}
          />
          </div>
          </div>
          </div>
  </div>

    <div className="row">
      <div className="col-md-12 mt-6 mx-auto">
        <div className="input-group input-group-sm mb-3">
          <div className="input-group-prepend">
              <button className="btn btn-outline-secondary font-weight-bold" href="#mProcedencia"
              data-toggle="modal" type="button" >Procedencia</button>
          </div>
              <input 
              required
              disabled
              id="inProced"
              type="text"
              className="form-control"
              name="procedencia"
              placeholder=""
              //value={this.refs.data}
              value={this.props.procedencia}
             //value={this.state.procedencia}
              onChange={this.getResponse}      
              aria-label="Example text with button addon"
              aria-describedby="button-addon1"/>

            <input 
              hidden
              id="inProcedH"
              type="text"
              className="form-control"
              name="inProcedH"
              placeholder=""              
              aria-label="Example text with button addon"
              aria-describedby="button-addon1"/>  
        </div>
      </div>
      <div className="modal fade" id="mProcedencia">
       <div className="modal-dialog modal-lg" role="document">
                      <div className="modal-content">
                        <div  className="modal-header">
                            <button tyle="button" className="close"
                            data-dismiss="modal"
                            aria-hidden="true">&times;</button>
                                <h5 className="modal-title">PROCEDENCIA</h5>
                            </div>
                            <div className="modal-body">
                                <h4 className="modal-title"></h4>
                                <h6>{this.state.procedencia}</h6>
                            <Tbl  callback={this.getResponseH}
                             //<Tbl 
                            // onSelectLanguage={this.handleProcedenciaChange} 
                            // data={this.data}
                             //procedencia={this.state.procedencia}
                              //procedencia={this.refs.data}                              
                            // onClick={this.onChangeProced}
                            //ref="aquiData"
                            //procedencia={this.state.idprocedencia}
                              ></Tbl>
                               <h6>{this.state.procedenciaH}</h6>
                           
                            </div>

                            <div className="modal-footer">
                            <button className="btn btn-secondary"
                            data-dismiss="modal">Cerrar</button>
                            </div>

                      </div>

              </div>
      </div>
    </div>

    <div className="row">

      <div className="col-md-5 mt-6 mx-auto">
        <div className="input-group input-group-sm mb-3">
          <div className="input-group-prepend">
              <button className="btn btn-outline-secondary font-weight-bold"
              type="button" id="button-addon1" href="#mTipo"
              data-toggle="modal">Tipo de Muestra</button>
          </div>
              <input 
              required
              type="text"
              disabled
              id="inTipoMuestra"
              className="form-control"
              name="tipo"
              placeholder=""             
              value={this.props.tipo}
              onChange={this.getResponseTipo}
              aria-label="Example text with button addon"
              aria-describedby="button-addon1"/>
              
              <input  type="text"
              hidden
              id="inTipoMuestraH"             
              className="form-control"
              name="inTipoMuestraH"
              placeholder=""              
              aria-label="Example text with button addon"
              aria-describedby="button-addon1"/>  

        </div>
      </div>
  
      <div className="modal fade" id="mTipo">
       <div className="modal-dialog modal-lg" role="document">
                      <div className="modal-content">
                        <div  className="modal-header">
                            <button tyle="button" className="close"
                            data-dismiss="modal"
                            aria-hidden="true">&times;</button>
                                <h5 className="modal-title">TIPO DE MUESTRA</h5>
                            </div>
                            <div className="modal-body">
                                <h4 className="modal-title"></h4>
                              <TbltipoM
                               //data={this.data}>
                               callback={this.getResponseTipoH}>
                              </TbltipoM>
                            </div>

                            <div className="modal-footer">
                            <button className="btn btn-secondary"
                            data-dismiss="modal">Cerrar</button>
                            </div>

                      </div>

              </div>
      </div>
      
      <div className="col-md-7 mt-6 mx-auto">
    <div className="btn-group btn-group-toggle" data-toggle="buttons">
    <div className="col-md-1 mt-6 mx-auto"></div>
      <div className="col-md-6 mt-6 mx-auto"> 
              <h6 className="font-weight-bold">Control de Calidad</h6> </div>     
      <div className="col-md-6 mt-6 mx-auto">                         
        <label className="btn btn-outline-secondary  btn-group-sm " role="group" onClick={this.handleControlChange}>
            <input
              type="radio"
              name="ctrlCalidad"
              value="NO"
              autoComplete="off"
            />{" "}
            NO
          </label>
        <label className="btn btn-outline-success btn-group-sm " role="group"  onClick={this.handleControlChange}>
            <input
              type="radio"
              name="ctrlCalidad"
              value="SI"
              autoComplete="off"
            />{" "}
            SI
          </label>

      </div>
    </div> 
 
  </div>
    
  </div> 

    <div className="row">
      <div className="col-md-6 mt-6 mx-auto">
        <div className="input-group input-group-sm mb-3">
            <div className="input-group-prepend">
            <span className="input-group-text font-weight-bold" id="basic-addon1">
            Ampliar tipo de muestra (ambiental)</span>
            </div>
            <input
             required
              type="text"
              className="form-control"
              name="ampliarAmbiental"
              placeholder=""
              value={this.state.ampliarAmbiental}
              onChange={this.onChange}
            />
        </div>
        </div>
        <div className="col-md-6 mt-6 mx-auto">
        <div className="input-group input-group-sm mb-3">
            <div className="input-group-prepend">
            <span className="input-group-text font-weight-bold" id="basic-addon1">
            Confirmar(Cepa Microbiologia Médica)</span>
            </div>
            <input
            required
              type="text"
              className="form-control"
              name="confirmarCepa"
              placeholder=""
              value={this.state.confirmarCepa}
              onChange={this.onChange}
            />
        </div>
        </div>
     </div>

    <div className="row">
          <div className="col-md-3 mt-6 mx-auto">
 <div className="input-group input-group-sm mb-3">
  <div className="input-group-prepend">
    <span className="input-group-text font-weight-bold">Temperatura</span>
  </div>
  <input
    type="number"
    className="form-control"
    name="temp"
    placeholder=""
    value={this.state.temp}
    onChange={this.onChange} />
  <div className="input-group-append">
    <span className="input-group-text">°C</span>
  </div>
 </div>
          </div>
          <div className="col-md-9 mt-6 mx-auto">
        <div className="input-group input-group-sm mb-3">
            <div className="input-group-prepend">
            <span className="input-group-text font-weight-bold" id="basic-addon1">
            observaciones</span>
            </div>
            <input
            required
              type="text"
              className="form-control"
              name="observaciones"
              placeholder=""
              value={this.state.observaciones}
              onChange={this.onChange}
            />
        </div>
          </div>
      </div>

    <div className="row">
  <div className="col-md-12 mt-6 mx-auto">
      <div className="card text-center border-danger input-group-sm">       
        <h6 className="card-header font-weight-bold">CONTROL AMBIENTAL Y ANALISIS SOLICITADO</h6>
        <div className="card-body border-danger">
                
        <div className="col-md-10 mt-6 mx-auto btn-group " data-toggle="buttons">                         
          <div className="form-group">        
        <label className="btn btn-outline-dark       btn-group-sm " role="group" onClick={this.handleMicroChange}>
            <input
              type="checkbox"
              name="microbiolog"   
              id="microbiologico"        
              autoComplete="off"
            />{" "}
            MICROBIOLOGICO
          </label>          
          </div>

          <div className="form-group">        
        <label className="btn btn-outline-dark       btn-group-sm " role="group" onClick={this.handlefisicoQChange}>
            <input
              type="checkbox"
              name="fisicoQ"   
              id="fisicoQ"        
              autoComplete="off"
            />{" "}
            FISICOQUIMICO
          </label>          
          </div> 
             
          <div className="form-group">        
        <label className="btn btn-outline-dark       btn-group-sm " role="group" onClick={this.handletoxicologChange}>
            <input
              type="checkbox"
              name="toxicolog"   
              id="toxicolog"        
              autoComplete="off"
            />{" "}
            TOXICOLOGICO
          </label>          
          </div> 
          
          <div className="form-group">        
        <label className="btn btn-outline-dark       btn-group-sm " role="group" onClick={this.handlemetalesPeChange}>
            <input
              type="checkbox"
              name="metalesPe"   
              id="metalesPe"        
              autoComplete="off"
            />{" "}
            METALES PESADOS
          </label>          
          </div> 
     
        </div>
        
        </div>

      <div className="card-footer bg-transparent border-danger">          
      <div className="btn-group btn-group-toggle" data-toggle="buttons">
      <div className="col-md-2 mt-6 mx-auto"> <h6 className="font-weight-bold centrado">MOTIVO</h6> </div>
      <div className="col-md-1 mt-6 mx-auto"></div>
      <div className="col-md-10 mt-6 mx-auto">                         
        <label className="btn btn-outline-info" onClick={this.handlePlatformChange}>
            <input
              type="radio"
              name="motivo"
              value="PROGRAMA"
              autoComplete="off"
            />{" "}
            PROGRAMA
          </label>
        <label className="btn btn-outline-info" onClick={this.handlePlatformChange}>
            <input
              type="radio"
              name="motivo"
              value="FASSC"
              autoComplete="off"
            />{" "}
            FASSC
          </label>
        <label className="btn btn-outline-info" onClick={this.handlePlatformChange}>
            <input
              type="radio"
              name="motivo"
              value="QUEJA"
              autoComplete="off"
            />{" "}
            QUEJA
          </label>
        <label className="btn btn-outline-info" onClick={this.handlePlatformChange}>
            <input
              type="radio"
              name="motivo"
              value="BROTE"
              autoComplete="off"
            />{" "}
            BROTE
          </label>
      </div>
      </div>  
      </div>
      </div>
  </div>
    </div>

    <div className="row">
   
        <div className="col-md-12 mt-5 mx-auto">
           <div className="card border-danger text-center">
              <div className="card-header font-weight-bold">
                  <h6 className="font-weight-bold">  BIOLOGIA MOLECULAR - CONTROL MICROBIOLOGICO - ANALISIS SOLICITADO</h6>
            
              </div>
               <div className="card-body ">
       
           <div className="row">
               <div className="btn-group btn-group-toggle" data-toggle="buttons">
      <div className="col-md-4 mt-6 mx-auto"> <h6 className="font-weight-bold">PRIORIDAD</h6> </div>
      <div className="col-md-1 mt-6 mx-auto"></div>
     
      <div className="col-md-8 mt-6 mx-auto">                         
        <label className="btn btn-outline-warning" onClick={this.handlePrioridadChange}>
            <input
              type="radio"
              name="prioridad"
              value="NORMAL"
              autoComplete="off"
            />{" "}
            NORMAL
          </label>
        <label className="btn btn-outline-danger" onClick={this.handlePrioridadChange}>
            <input
              type="radio"
              name="prioridad"
              value="URGENTE"
              autoComplete="off"
            />{" "}
            URGENTE
          </label>
      </div></div> 
 
           </div>
      
      </div>
           </div>
        
        </div>

     </div>

    <div className="row">
          <div className="col-md-6 mt-5 mx-auto">
            <div className="input-group input-group-sm mb-3">
                <div className="input-group-prepend">
                <span className="input-group-text" id="basic-addon1">
                claveExa1</span>
                </div>
                <input
                  type="text"
                  className="form-control"
                  name="claveExa1"
                  placeholder="claveExa1"
                  value={this.state.claveExa1}
                  onChange={this.onChange}
                />
            </div>
          </div>
          <div className="col-md-6 mt-5 mx-auto">
            <div className="input-group input-group-sm mb-3">
                <div className="input-group-prepend">
                <span className="input-group-text" id="basic-addon1">
                claveExa1</span>
                </div>
                <input
                  type="text"
                  className="form-control"
                  name="claveExa1"
                  placeholder="claveExa1"
                  value={this.state.claveExa1}
                  onChange={this.onChange}
                />
            </div>
          </div>
      </div>

    <button type="submit" className="btn btn-lg btn-success 
     centrado" onClick={this.createAndDownloadPdf}>
      Guardar
    </button>
  </form>
</div>

  )
  }
}

export default Recepcion
