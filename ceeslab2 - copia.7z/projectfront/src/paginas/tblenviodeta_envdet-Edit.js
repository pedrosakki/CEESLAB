import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios'
const baseUrl= "http: //localhost:3000"
class EditComponent extends React.Component{

constructor(props){

super(props);
this.state={
edittblenviodeta_envdets:[],
datatblenviodeta_envdet:{},
FOL_ENV: "",
MUESTRA: "",
CLAPRO: "",
USUARIO: ""
}
}


componentDidMount(){
let userId = this.props.match.params.tblenviodeta_envdetid;
  const url = baseUrl+"/Rtblenviodeta_envdet/get/"+userId

  axios.get(url)
 .then(res=>{
  if(res.data.sucess){
  const data = res.data.data[0] 
this.setState({
edittblenviodeta_envdets:data,
FOL_ENV: data.FOL_ENV,
MUESTRA: data.MUESTRA,
CLAPRO: data.CLAPRO,
USUARIO: data.USUARIO
} ) }
else{
alert("Error web service")
} } )
  .catch(error=>{
  })
}


  render(){
   let userId = 0;
 return (
<div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FOL_ENV </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FOL_ENV} onChange={(value)=> this.setState({FOL_ENV:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MUESTRA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.MUESTRA} onChange={(value)=> this.setState({MUESTRA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAPRO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAPRO} onChange={(value)=> this.setState({CLAPRO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">USUARIO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.USUARIO} onChange={(value)=> this.setState({USUARIO:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendUpdate()}>Update</button>  
</div>
); }
sendUpdate(){
let userId = this.props.match.params.tblenviodeta_envdetid;
const baseUrl = "http://localhost:3000/Rtblenviodeta_envdet/Update/"+ userId
const datapost = {
FOL_ENV: this.state.FOL_ENV,
MUESTRA: this.state.MUESTRA,
CLAPRO: this.state.CLAPRO,
USUARIO: this.state.USUARIO
}
axios.post(baseUrl,datapost)
.then(response=>{
if (response.data.success===true) {
alert(response.data.message)
}
else {
alert(response.data.message)
alert(JSON.stringify(response))
}
}).catch(error=>{
alert("Error 34 "+error)
})
}
}
export default EditComponent;
