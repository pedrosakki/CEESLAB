//import '../css/dataTables.bootstrap4.min.css'
//import './css/font-awesome.min.css'
import React, { Component } from 'react'
import { BrowserRouter as Router, Route, withRouter } from 'react-router-dom'
//import { useHistory } from "react-router-dom";
//import Recepcion3 from './Recepcion3'
//import 'bootstrap/dist/css/bootstrap.min.css';
//import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios';
import { updateMuestra } from './UserFunctions'
import { Link } from "react-router-dom";
//library sweetalert
//import Swal from 'sweetalert2/dist/sweetalert2.js'
//import 'sweetalert2/src/sweetalert2.scss'

const baseUrl = "http://localhost:3000"

const $=require('jquery')
$.Datatable=require('datatables.net')

var loadMuestra=()=>{
  const url = baseUrl+"/employee/list"
  axios.get(url)
  .then(res=>{
    if (res.data.success) {
      const data = res.data.data
      this.setState({listEmployee:data})
    }
    else {
      alert("Error en web service")
    }
  })
  .catch(error=>{
    alert("Error en server "+error)
  })
}

  var datosEditar=function(tbody,table){
        $(tbody).on("click","button.editar",function() {   
        //  var data=table.row($(this).parent().parent().children.first().text()) 
        //let history = useHistory();        
        var data=table.row($(this).parents("tr")).data();
        console.log(data);      
        //this.props.history.push("EditarMuestra2");
        this.props.history.push("/EditarMuestra2");       
      //  <Link class="btn btn-outline-info" to={"/EditarMuestra2/"+data.id}>Edit</Link>
        //{this.redirectTo}              
         //this.props.history.push(`/login`)
      //  href='{'/edit/'+data.id}
       // var idprocedencia=$("#inProced").val(data.id+" "+data.nombre);
       // var idprocedenciaH=$("#inProcedH").val(data.id);
       
        })
        }

  const logOut = () => {
          //  e.preventDefault()
          //  localStorage.removeItem('usertoken')
            this.props.history.push(`/login`)
          };

    
  var editarM=function(data){  
            // url de backend
            console.log("en editarM "+data)
            const baseUrl = "http://localhost:3000/tipoMuestras/updateMuestra/:idTipo"    // parameter data post
            // network
            axios.post(baseUrl,{
              idTipo:data.idTipo
            })
            .then(response =>{
              if (response.data.success) {               
                this.loadEmployee()
              }
            })
            .catch ( error => {
              alert("Error 325 ")
            })
          }

  var espanol={
    "sProcessing":     "Procesando...",
    "sLengthMenu":     "Mostrar _MENU_ registros",
    "sZeroRecords":    "No se encontraron resultados",
    "sEmptyTable":     "Ningún dato disponible en esta tabla =(",
    "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
    "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
    "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
    "sInfoPostFix":    "",
    "sSearch":         "Buscar:",
    "sUrl":            "",
    "sInfoThousands":  ",",
    "sLoadingRecords": "Cargando...",
    "oPaginate": {
        "sFirst":    "Primero",
        "sLast":     "Último",
        "sNext":     "Siguiente",
        "sPrevious": "Anterior"
    },
    "oAria": {
        "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
        "sSortDescending": ": Activar para ordenar la columna de manera descendente"
    },
    "buttons": {
        "copy": "Copiar",
        "colvis": "Visibilidad"
    }
  
  }

  var listar2=()=>{
    var table=$("#dtEditar").DataTable({
        destroy: true,
        empty: true,
      language:espanol,
     //data:this.props.callback(this.props.num * 2),
      ajax:{
            method:'GET',
            url:'http://localhost:5000/regiones/TodasReg3'
            },
            columns:[
              {data:'id'},
              {data:'nombre'},
              {data:'subregion'},
              {data:'estado'},
              {"defaultContent":              
              "<button class='btn btn-outline-info editar'> Modificar </button> <List><ListItem button component={Link} to='/login'><ListItemIcon><span><i className='fas fa-plus-circle'></i></span></ListItemIcon></ListItem></List>"}
              ],
      select: true,
      colReorder: true
    });
    datosEditar("#dtEditar tbody",table); 
  //  editarM(data);
  }   


  
  class TblMuestras extends Component{ 
    constructor() {
      super()
      this.state = {
      //  data:[0],
     //   procedenciaT:''   
        }
    //  this.handleLangChange = this.handleLangChange.bind(this);    
    }
   
   
   
/*
    handleLangChange = () => {
      var lang = this.data;
      this.props.onSelectLanguage(lang);            
  }  */
  //this.onChangeProced = this.onChangeProced.bind(this)
componentDidMount(){
  listar2();
}
//componentWillUnmount(){  //this.$el.DataTable.destroy(true)}

render(){
  const { match, location, history } = this.props;
 
  return(
    <div>
 
  <div>
    <table id="dtEditar" className="display table table-bordered table-hover"
    width="100%" ref={el=>this.el=el}>
      <thead className="bg-secondary text-center text-white">      
<tr className="sortable">
<th>ID</th>
<th>NOMBRE</th>
<th>SUBREGION</th>
<th>ESTADO</th>
<th>ACCIÓN</th>
</tr>
</thead>
    </table>
    </div>
    </div>   
  )

}
}
export default  withRouter(TblMuestras)