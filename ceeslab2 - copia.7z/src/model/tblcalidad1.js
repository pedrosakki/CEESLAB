const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tblcalidad1')
var nametable = 'tblcalidad1';
var tblcalidad1 = sequelize.define(nametable,{
idtblcalidad1:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


MUESTRA:  Sequelize.INTEGER,
CLAPRO:  Sequelize.DECIMAL,
CLAMUE:  Sequelize.DECIMAL,
E1:  Sequelize.INTEGER,
EXAM1:  Sequelize.STRING,
FEC_RESP:  Sequelize.DATE,
MES:  Sequelize.STRING,
LABORATORIO:  Sequelize.STRING,
OBSERVA:  Sequelize.STRING,
FN_1:  Sequelize.STRING,
FN_2:  Sequelize.STRING,
NEW:  Sequelize.STRING,
HEMOLI:  Sequelize.STRING,
LIPEMI:  Sequelize.STRING,
CONTAM:  Sequelize.STRING,
INSUFI:  Sequelize.STRING,
ADECUA:  Sequelize.STRING,
TOT_SUE:  Sequelize.STRING,
FEC_CAP:  Sequelize.DATE,
FEC_IMP:  Sequelize.DATE,
FEC_VAL:  Sequelize.DATE,
VALIDADO:  Sequelize.INTEGER,
CLACAU:  Sequelize.INTEGER,
SUPLEMENTO:  Sequelize.INTEGER,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tblcalidad1;
