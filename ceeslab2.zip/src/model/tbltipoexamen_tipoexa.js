const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tbltipoexamen_tipoexa')
var nametable = 'tbltipoexamen_tipoexa';
var tbltipoexamen_tipoexa = sequelize.define(nametable,{
idtbltipoexamen_tipoexa:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


CLAEXA:  Sequelize.DECIMAL,
EXAMEN:  Sequelize.STRING,
UNIDAD:  Sequelize.STRING,
METODO:  Sequelize.STRING,
TECNICA:  Sequelize.STRING,
REFERENCIA:  Sequelize.STRING,
GRUPO:  Sequelize.DECIMAL,
COMPLEMENTO:  Sequelize.STRING,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tbltipoexamen_tipoexa;
