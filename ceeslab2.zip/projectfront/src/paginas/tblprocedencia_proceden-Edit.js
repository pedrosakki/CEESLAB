import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios'
const baseUrl= "http: //localhost:3000"
class EditComponent extends React.Component{

constructor(props){

super(props);
this.state={
edittblprocedencia_procedens:[],
datatblprocedencia_proceden:{},
CLAPRO: "",
PROCEDEN: "",
ABREVIA: "",
GRUPO: "",
DOMICILIO: "",
MUNICIPIO: "",
ESTADO: "",
ATENCION: "",
CARGO: "",
ENVIO: "",
ENV_ELEC: ""
}
}


componentDidMount(){
let userId = this.props.match.params.tblprocedencia_procedenid;
  const url = baseUrl+"/Rtblprocedencia_proceden/get/"+userId

  axios.get(url)
 .then(res=>{
  if(res.data.sucess){
  const data = res.data.data[0] 
this.setState({
edittblprocedencia_procedens:data,
CLAPRO: data.CLAPRO,
PROCEDEN: data.PROCEDEN,
ABREVIA: data.ABREVIA,
GRUPO: data.GRUPO,
DOMICILIO: data.DOMICILIO,
MUNICIPIO: data.MUNICIPIO,
ESTADO: data.ESTADO,
ATENCION: data.ATENCION,
CARGO: data.CARGO,
ENVIO: data.ENVIO,
ENV_ELEC: data.ENV_ELEC
} ) }
else{
alert("Error web service")
} } )
  .catch(error=>{
  })
}


  render(){
   let userId = 0;
 return (
<div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAPRO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAPRO} onChange={(value)=> this.setState({CLAPRO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">PROCEDEN </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.PROCEDEN} onChange={(value)=> this.setState({PROCEDEN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ABREVIA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ABREVIA} onChange={(value)=> this.setState({ABREVIA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">GRUPO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.GRUPO} onChange={(value)=> this.setState({GRUPO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DOMICILIO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DOMICILIO} onChange={(value)=> this.setState({DOMICILIO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MUNICIPIO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.MUNICIPIO} onChange={(value)=> this.setState({MUNICIPIO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ESTADO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ESTADO} onChange={(value)=> this.setState({ESTADO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ATENCION </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ATENCION} onChange={(value)=> this.setState({ATENCION:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CARGO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CARGO} onChange={(value)=> this.setState({CARGO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ENVIO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ENVIO} onChange={(value)=> this.setState({ENVIO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ENV_ELEC </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ENV_ELEC} onChange={(value)=> this.setState({ENV_ELEC:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendUpdate()}>Update</button>  
</div>
); }
sendUpdate(){
let userId = this.props.match.params.tblprocedencia_procedenid;
const baseUrl = "http://localhost:3000/Rtblprocedencia_proceden/Update/"+ userId
const datapost = {
CLAPRO: this.state.CLAPRO,
PROCEDEN: this.state.PROCEDEN,
ABREVIA: this.state.ABREVIA,
GRUPO: this.state.GRUPO,
DOMICILIO: this.state.DOMICILIO,
MUNICIPIO: this.state.MUNICIPIO,
ESTADO: this.state.ESTADO,
ATENCION: this.state.ATENCION,
CARGO: this.state.CARGO,
ENVIO: this.state.ENVIO,
ENV_ELEC: this.state.ENV_ELEC
}
axios.post(baseUrl,datapost)
.then(response=>{
if (response.data.success===true) {
alert(response.data.message)
}
else {
alert(response.data.message)
alert(JSON.stringify(response))
}
}).catch(error=>{
alert("Error 34 "+error)
})
}
}
export default EditComponent;
