const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tblenvioenca_envios')
var nametable = 'tblenvioenca_envios';
var tblenvioenca_envios = sequelize.define(nametable,{
idtblenvioenca_envios:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


FOL_ENV:  Sequelize.INTEGER,
FEC_ENV:  Sequelize.DATE,
FEC_ARC:  Sequelize.DATE,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tblenvioenca_envios;
