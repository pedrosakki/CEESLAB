import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios'
const baseUrl= "http: //localhost:3000"
class EditComponent extends React.Component{

constructor(props){

super(props);
this.state={
edittblmotivomuestra_motmuess:[],
datatblmotivomuestra_motmues:{},
CLAMOT: "",
MOTIVO: ""
}
}


componentDidMount(){
let userId = this.props.match.params.tblmotivomuestra_motmuesid;
  const url = baseUrl+"/Rtblmotivomuestra_motmues/get/"+userId

  axios.get(url)
 .then(res=>{
  if(res.data.sucess){
  const data = res.data.data[0] 
this.setState({
edittblmotivomuestra_motmuess:data,
CLAMOT: data.CLAMOT,
MOTIVO: data.MOTIVO
} ) }
else{
alert("Error web service")
} } )
  .catch(error=>{
  })
}


  render(){
   let userId = 0;
 return (
<div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAMOT </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAMOT} onChange={(value)=> this.setState({CLAMOT:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MOTIVO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.MOTIVO} onChange={(value)=> this.setState({MOTIVO:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendUpdate()}>Update</button>  
</div>
); }
sendUpdate(){
let userId = this.props.match.params.tblmotivomuestra_motmuesid;
const baseUrl = "http://localhost:3000/Rtblmotivomuestra_motmues/Update/"+ userId
const datapost = {
CLAMOT: this.state.CLAMOT,
MOTIVO: this.state.MOTIVO
}
axios.post(baseUrl,datapost)
.then(response=>{
if (response.data.success===true) {
alert(response.data.message)
}
else {
alert(response.data.message)
alert(JSON.stringify(response))
}
}).catch(error=>{
alert("Error 34 "+error)
})
}
}
export default EditComponent;
