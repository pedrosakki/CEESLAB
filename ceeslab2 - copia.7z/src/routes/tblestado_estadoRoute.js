const express = require('express');
const router = express.Router();
const tblestado_estadoController = require('../Controllers/tblestado_estadoController')


router.post('/update/:id',tblestado_estadoController.update)
router.get('/get/:id', tblestado_estadoController.get)
router.get('/list', tblestado_estadoController.list);
router.post('/create', tblestado_estadoController.create);


module.exports = router;
