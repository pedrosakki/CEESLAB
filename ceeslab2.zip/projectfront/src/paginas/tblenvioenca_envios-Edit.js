import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios'
const baseUrl= "http: //localhost:3000"
class EditComponent extends React.Component{

constructor(props){

super(props);
this.state={
edittblenvioenca_envioss:[],
datatblenvioenca_envios:{},
FOL_ENV: "",
FEC_ENV: "",
FEC_ARC: ""
}
}


componentDidMount(){
let userId = this.props.match.params.tblenvioenca_enviosid;
  const url = baseUrl+"/Rtblenvioenca_envios/get/"+userId

  axios.get(url)
 .then(res=>{
  if(res.data.sucess){
  const data = res.data.data[0] 
this.setState({
edittblenvioenca_envioss:data,
FOL_ENV: data.FOL_ENV,
FEC_ENV: data.FEC_ENV,
FEC_ARC: data.FEC_ARC
} ) }
else{
alert("Error web service")
} } )
  .catch(error=>{
  })
}


  render(){
   let userId = 0;
 return (
<div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FOL_ENV </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FOL_ENV} onChange={(value)=> this.setState({FOL_ENV:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_ENV </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_ENV} onChange={(value)=> this.setState({FEC_ENV:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_ARC </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_ARC} onChange={(value)=> this.setState({FEC_ARC:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendUpdate()}>Update</button>  
</div>
); }
sendUpdate(){
let userId = this.props.match.params.tblenvioenca_enviosid;
const baseUrl = "http://localhost:3000/Rtblenvioenca_envios/Update/"+ userId
const datapost = {
FOL_ENV: this.state.FOL_ENV,
FEC_ENV: this.state.FEC_ENV,
FEC_ARC: this.state.FEC_ARC
}
axios.post(baseUrl,datapost)
.then(response=>{
if (response.data.success===true) {
alert(response.data.message)
}
else {
alert(response.data.message)
alert(JSON.stringify(response))
}
}).catch(error=>{
alert("Error 34 "+error)
})
}
}
export default EditComponent;
