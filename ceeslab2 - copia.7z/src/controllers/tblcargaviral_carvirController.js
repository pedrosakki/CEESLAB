 const controllers = {}
var sequelize = require('../model/database');
var tblcargaviral_carvir = require('../model/tblcargaviral_carvir');

//METODO GET//

controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tblcargaviral_carvir.findAll({
where: {idtblcargaviral_carvir: id }  })
.then(function(data){
    return data;})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}


//METODO LIST//

controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tblcargaviral_carvir.findAll();
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}



//METODO CREATE//
controllers.create = async (req, res)=>{
const  {MUESTRA,ID_SALVAR,FEC_PRO,CLARES,COPIAS_ML,LOG,CD3,P_CD3,CD3_CD4,P_CD3_CD4,CD3_CD8,P_CD3_CD8,CD4_CD8,FEC_REP}=req.body;
const data = await tblcargaviral_carvir.create({
MUESTRA: MUESTRA,
ID_SALVAR: ID_SALVAR,
FEC_PRO: FEC_PRO,
CLARES: CLARES,
COPIAS_ML: COPIAS_ML,
LOG: LOG,
CD3: CD3,
P_CD3: P_CD3,
CD3_CD4: CD3_CD4,
P_CD3_CD4: P_CD3_CD4,
CD3_CD8: CD3_CD8,
P_CD3_CD8: P_CD3_CD8,
CD4_CD8: CD4_CD8,
FEC_REP: FEC_REP
}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data
})
}


//METODO UPDATE//
controllers.update = async (req, res)=>{
  const { id } = req.params;
const  {MUESTRA,ID_SALVAR,FEC_PRO,CLARES,COPIAS_ML,LOG,CD3,P_CD3,CD3_CD4,P_CD3_CD4,CD3_CD8,P_CD3_CD8,CD4_CD8,FEC_REP}=req.body;

 const data = await tblcargaviral_carvir.update({
MUESTRA: MUESTRA,
ID_SALVAR: ID_SALVAR,
FEC_PRO: FEC_PRO,
CLARES: CLARES,
COPIAS_ML: COPIAS_ML,
LOG: LOG,
CD3: CD3,
P_CD3: P_CD3,
CD3_CD4: CD3_CD4,
P_CD3_CD4: P_CD3_CD4,
CD3_CD8: CD3_CD8,
P_CD3_CD8: P_CD3_CD8,
CD4_CD8: CD4_CD8,
FEC_REP: FEC_REP
   },{
          where: { idtblcargaviral_carvir: id}
     })
  .then( function(data){
    return data;
      })
       .catch(error => {
        return error;
   }) 
   res.json({success:true, data:data, message:"Updated successful"});
 }



 module.exports = controllers;
