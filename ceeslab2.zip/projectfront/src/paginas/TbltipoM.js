//import '../css/dataTables.bootstrap4.min.css'
import React, { Component } from 'react'
import { BrowserRouter as Router, Route } from 'react-router-dom'

const $=require('jquery')
$.Datatable=require('datatables.net')

var obtenerDatos=function(tbody,table){
  $(tbody).on("click","button.selecc",function(){
  var data=table.row($(this).parents("tr")).data();
  console.log(data);
  })
  }
  
  var obtenerDatos2=function(tbody,table){
  $(tbody).on('click','tr',function(){
  var data=table.row($(this).parents("tr")).data();
  console.log(data);
  })
  }
  
  var obtenerDatos3=function(tbody,table){
    $(tbody).on("click","tr",function() {          
      var data=table.row($(this).parents("tr")).data();
      console.log(data);
      var idprocedencia=$("#inProced").val(data.id+" "+data.nombre);
      var idprocedenciaH=$("#inProcedH").val(data.id);
     // clicke();
      $("#mProcedencia .close").click();
      })
        }
  var obtenerDatos4=function(tbody,table){
    // $(tbody).on('click','btn-edit',function(e){
   $(tbody).on('click','tr',function(e){
     e.preventDefault();
 var data=table.row($(this)).data();
    // var data=table.row($(this).parent().parent().children.first().text())  // da solo el indice
 console.log(data);
 var idprocedencia=$("#formRecep #inProced").val(data.id+" "+data.nombre)
 //this.state.procedencia
//  this.props.procedencia
 //$('#mProcedencia').modal('hide');
 $("#mProcedencia .close").click();
 
 })
 }

 var obtenerDatos6=function(tbody,table){
  $(tbody).on("click","button.seleccT",function() {               
  var data=table.row($(this).parents("tr")).data();
  console.log(data);
  var inTipoMuestra=$("#inTipoMuestra").val(data.id+" "+data.nombre);
  var inTipoMuestraH=$("#inTipoMuestraH").val(data.id);
  $("#mTipo .close").click();
  })
  }

  var espanol={
    "sProcessing":     "Procesando...",
    "sLengthMenu":     "Mostrar _MENU_ registros",
    "sZeroRecords":    "No se encontraron resultados",
    "sEmptyTable":     "Ningún dato disponible en esta tabla =(",
    "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
    "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
    "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
    "sInfoPostFix":    "",
    "sSearch":         "Buscar:",
    "sUrl":            "",
    "sInfoThousands":  ",",
    "sLoadingRecords": "Cargando...",
    "oPaginate": {
        "sFirst":    "Primero",
        "sLast":     "Último",
        "sNext":     "Siguiente",
        "sPrevious": "Anterior"
    },
    "oAria": {
        "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
        "sSortDescending": ": Activar para ordenar la columna de manera descendente"
    },
    "buttons": {
        "copy": "Copiar",
        "colvis": "Visibilidad"
    }
  
  }

  var listar=function(){
    var table=$("#dt2").DataTable({
        destroy: true,
        empty: true,
      language:espanol,
    //data:this.props.data,
      ajax:{
            method:'GET',
            url:'http://localhost:5000/regiones/TodasReg3'
            },
            columns:[
              {data:'id'},
              {data:'nombre'},
              {data:'subregion'},
              {data:'estado'},
              {"defaultContent":"<button  type='button' class='btn btn-primary seleccT'><i class='far fa-check-circle'></i></button>"}
              ],
      select: true,
      colReorder: true
    });
    obtenerDatos6("#dt2 tbody",table);
  
  }  



class TbltipoM extends Component{
componentDidMount(){
  listar();
}
//componentWillUnmount(){  //this.$el.DataTable.destroy(true)}

render(){
  return(
    <div>
    <table id="dt2" className="display table table-bordered table-hover"
    width="100%" ref={el=>this.el=el}>
      <thead className="bg-success text-center text-white">
<tr className="sortable">
<th>ID</th>
<th>NOMBRE</th>
<th>SUBREGION</th>
<th>ESTADO</th>
<th>ACCION</th>
</tr>
</thead>
    </table>
    </div>
  )

}
}

export default TbltipoM