 const controllers = {}
var sequelize = require('../model/database');
var tblcalidad8 = require('../model/tblcalidad8');

//METODO GET//

controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tblcalidad8.findAll({
where: {idtblcalidad8: id }  })
.then(function(data){
    return data;})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}


//METODO LIST//

controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tblcalidad8.findAll();
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}



//METODO CREATE//
controllers.create = async (req, res)=>{
const  {MUESTRA,CLAPRO,CLAMUE,RECOBODAS,RECHAZADAS,TMI,CRN,CRP,IPP,ENPROCESO,OBSERVA,FEC_REP,FEC_CAP,FEC_IMP,FEC_VAL,VALIDADO,CLACAU,SUPLEMENTO}=req.body;
const data = await tblcalidad8.create({
MUESTRA: MUESTRA,
CLAPRO: CLAPRO,
CLAMUE: CLAMUE,
RECOBODAS: RECOBODAS,
RECHAZADAS: RECHAZADAS,
TMI: TMI,
CRN: CRN,
CRP: CRP,
IPP: IPP,
ENPROCESO: ENPROCESO,
OBSERVA: OBSERVA,
FEC_REP: FEC_REP,
FEC_CAP: FEC_CAP,
FEC_IMP: FEC_IMP,
FEC_VAL: FEC_VAL,
VALIDADO: VALIDADO,
CLACAU: CLACAU,
SUPLEMENTO: SUPLEMENTO
}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data
})
}


//METODO UPDATE//
controllers.update = async (req, res)=>{
  const { id } = req.params;
const  {MUESTRA,CLAPRO,CLAMUE,RECOBODAS,RECHAZADAS,TMI,CRN,CRP,IPP,ENPROCESO,OBSERVA,FEC_REP,FEC_CAP,FEC_IMP,FEC_VAL,VALIDADO,CLACAU,SUPLEMENTO}=req.body;

 const data = await tblcalidad8.update({
MUESTRA: MUESTRA,
CLAPRO: CLAPRO,
CLAMUE: CLAMUE,
RECOBODAS: RECOBODAS,
RECHAZADAS: RECHAZADAS,
TMI: TMI,
CRN: CRN,
CRP: CRP,
IPP: IPP,
ENPROCESO: ENPROCESO,
OBSERVA: OBSERVA,
FEC_REP: FEC_REP,
FEC_CAP: FEC_CAP,
FEC_IMP: FEC_IMP,
FEC_VAL: FEC_VAL,
VALIDADO: VALIDADO,
CLACAU: CLACAU,
SUPLEMENTO: SUPLEMENTO
   },{
          where: { idtblcalidad8: id}
     })
  .then( function(data){
    return data;
      })
       .catch(error => {
        return error;
   }) 
   res.json({success:true, data:data, message:"Updated successful"});
 }



 module.exports = controllers;
