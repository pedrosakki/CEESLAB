const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tblmotivomuestra_motmues')
var nametable = 'tblmotivomuestra_motmues';
var tblmotivomuestra_motmues = sequelize.define(nametable,{
idtblmotivomuestra_motmues:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


CLAMOT:  Sequelize.INTEGER,
MOTIVO:  Sequelize.STRING,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tblmotivomuestra_motmues;
