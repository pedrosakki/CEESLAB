import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios';
class EditComponent extends React.Component{
constructor(props){
super(props);
this.state = {
MUESTRA:"",
ID_SALVAR:"",
FEC_PRO:"",
CLARES:"",
COPIAS_ML:"",
LOG:"",
CD3:"",
P_CD3:"",
CD3_CD4:"",
P_CD3_CD4:"",
CD3_CD8:"",
P_CD3_CD8:"",
CD4_CD8:"",
FEC_REP:""
}
}
render(){
  return (
<div>
 <div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MUESTRA </label>
<input type="text" class="form-control" placeholder="MUESTRA" value={this.state.MUESTRA} onChange={(value)=> this.setState({MUESTRA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ID_SALVAR </label>
<input type="text" class="form-control" placeholder="ID_SALVAR" value={this.state.ID_SALVAR} onChange={(value)=> this.setState({ID_SALVAR:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_PRO </label>
<input type="text" class="form-control" placeholder="FEC_PRO" value={this.state.FEC_PRO} onChange={(value)=> this.setState({FEC_PRO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLARES </label>
<input type="text" class="form-control" placeholder="CLARES" value={this.state.CLARES} onChange={(value)=> this.setState({CLARES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">COPIAS_ML </label>
<input type="text" class="form-control" placeholder="COPIAS_ML" value={this.state.COPIAS_ML} onChange={(value)=> this.setState({COPIAS_ML:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">LOG </label>
<input type="text" class="form-control" placeholder="LOG" value={this.state.LOG} onChange={(value)=> this.setState({LOG:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD3 </label>
<input type="text" class="form-control" placeholder="CD3" value={this.state.CD3} onChange={(value)=> this.setState({CD3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">P_CD3 </label>
<input type="text" class="form-control" placeholder="P_CD3" value={this.state.P_CD3} onChange={(value)=> this.setState({P_CD3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD3_CD4 </label>
<input type="text" class="form-control" placeholder="CD3_CD4" value={this.state.CD3_CD4} onChange={(value)=> this.setState({CD3_CD4:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">P_CD3_CD4 </label>
<input type="text" class="form-control" placeholder="P_CD3_CD4" value={this.state.P_CD3_CD4} onChange={(value)=> this.setState({P_CD3_CD4:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD3_CD8 </label>
<input type="text" class="form-control" placeholder="CD3_CD8" value={this.state.CD3_CD8} onChange={(value)=> this.setState({CD3_CD8:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">P_CD3_CD8 </label>
<input type="text" class="form-control" placeholder="P_CD3_CD8" value={this.state.P_CD3_CD8} onChange={(value)=> this.setState({P_CD3_CD8:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD4_CD8 </label>
<input type="text" class="form-control" placeholder="CD4_CD8" value={this.state.CD4_CD8} onChange={(value)=> this.setState({CD4_CD8:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_REP </label>
<input type="text" class="form-control" placeholder="FEC_REP" value={this.state.FEC_REP} onChange={(value)=> this.setState({FEC_REP:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendSave()}>Save</button>
</div>
</div>
);
}
  sendSave(){
const baseUrl = "http://localhost:3000/Rtblcargaviral_carvir/create"
const datapost = {
MUESTRA: this.state.MUESTRA,
ID_SALVAR: this.state.ID_SALVAR,
FEC_PRO: this.state.FEC_PRO,
CLARES: this.state.CLARES,
COPIAS_ML: this.state.COPIAS_ML,
LOG: this.state.LOG,
CD3: this.state.CD3,
P_CD3: this.state.P_CD3,
CD3_CD4: this.state.CD3_CD4,
P_CD3_CD4: this.state.P_CD3_CD4,
CD3_CD8: this.state.CD3_CD8,
P_CD3_CD8: this.state.P_CD3_CD8,
CD4_CD8: this.state.CD4_CD8,
FEC_REP: this.state.FEC_REP
}
axios.post(baseUrl,datapost)
      .then(response=>{
 if (response.data.success===true) {
  alert(response.data.message)
}
else {
alert(response.data.message)
}
}).catch(error=>{
   alert("Error 34 "+error)
 })
 }
}
export default EditComponent;
