const express = require('express');
const router = express.Router();
const tblcalidad11Controller = require('../Controllers/tblcalidad11Controller')


router.post('/update/:id',tblcalidad11Controller.update)
router.get('/get/:id', tblcalidad11Controller.get)
router.get('/list', tblcalidad11Controller.list);
router.post('/create', tblcalidad11Controller.create);


module.exports = router;
