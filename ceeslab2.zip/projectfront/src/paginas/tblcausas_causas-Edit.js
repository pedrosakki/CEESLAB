import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios'
const baseUrl= "http: //localhost:3000"
class EditComponent extends React.Component{

constructor(props){

super(props);
this.state={
edittblcausas_causass:[],
datatblcausas_causas:{},
CLACAU: "",
CAUSA: ""
}
}


componentDidMount(){
let userId = this.props.match.params.tblcausas_causasid;
  const url = baseUrl+"/Rtblcausas_causas/get/"+userId

  axios.get(url)
 .then(res=>{
  if(res.data.sucess){
  const data = res.data.data[0] 
this.setState({
edittblcausas_causass:data,
CLACAU: data.CLACAU,
CAUSA: data.CAUSA
} ) }
else{
alert("Error web service")
} } )
  .catch(error=>{
  })
}


  render(){
   let userId = 0;
 return (
<div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLACAU </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLACAU} onChange={(value)=> this.setState({CLACAU:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CAUSA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CAUSA} onChange={(value)=> this.setState({CAUSA:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendUpdate()}>Update</button>  
</div>
); }
sendUpdate(){
let userId = this.props.match.params.tblcausas_causasid;
const baseUrl = "http://localhost:3000/Rtblcausas_causas/Update/"+ userId
const datapost = {
CLACAU: this.state.CLACAU,
CAUSA: this.state.CAUSA
}
axios.post(baseUrl,datapost)
.then(response=>{
if (response.data.success===true) {
alert(response.data.message)
}
else {
alert(response.data.message)
alert(JSON.stringify(response))
}
}).catch(error=>{
alert("Error 34 "+error)
})
}
}
export default EditComponent;
