import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios';
class EditComponent extends React.Component{
constructor(props){
super(props);
this.state = {
accion:""
}
}


render(){
  return (
<div>
 <div className="form-row justify-content-center">
<div className="form-group col-md-6">
<label htmlFor="inputApellidoPaterno">accion </label>
<input type="text" class="form-control" placeholder="accion" value={this.state.accion} onChange={(value)=> this.setState({accion:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendSave()}>Save</button>
</div>
</div>
  );}
  sendSave(){
    const baseUrl = "http://localhost:3000/Rpermisos/create"
    const datapost = {
      accion: this.state.accion
    }
    alert(datapost.accion)
axios.post(baseUrl,datapost)
      .then(response=>{
 if (response.data.success===true) {
  alert(response.data.message)
}
else {
alert(response.data.message)
}
}).catch(error=>{
   alert("Error 34 "+error)
 })
 }
}
export default EditComponent;
