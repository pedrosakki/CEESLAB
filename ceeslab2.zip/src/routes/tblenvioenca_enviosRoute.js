const express = require('express');
const router = express.Router();
const tblenvioenca_enviosController = require('../Controllers/tblenvioenca_enviosController')


router.post('/update/:id',tblenvioenca_enviosController.update)
router.get('/get/:id', tblenvioenca_enviosController.get)
router.get('/list', tblenvioenca_enviosController.list);
router.post('/create', tblenvioenca_enviosController.create);


module.exports = router;
