const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tblenviodeta_envdet')
var nametable = 'tblenviodeta_envdet';
var tblenviodeta_envdet = sequelize.define(nametable,{
idtblenviodeta_envdet:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


FOL_ENV:  Sequelize.INTEGER,
MUESTRA:  Sequelize.INTEGER,
CLAPRO:  Sequelize.DECIMAL,
USUARIO:  Sequelize.STRING,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tblenviodeta_envdet;
