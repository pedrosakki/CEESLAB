import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { Link } from "react-router-dom";
import axios from 'axios';
const url= 'http://localhost:3000/Rtblcalidad9/list';
class listComponent extends React.Component  {
constructor(props){
super(props);
this.state ={
listtblcalidad9:[]
}
}
componentDidMount(){
axios.get(url)
.then(res=>{
if(res.data.sucess){
const data = res.data.data
this.setState({listtblcalidad9:data})
}
else{
alert("Error web service")
}
})
.catch(error=>{
alert("Error Server"+error)
})
}
render()
{
    return (
      <table class="table table-hover table-striped">

        <thead class="thead-dark">

<tr>
<th scope = "col" >#</th>
<th scope ="col" >MUESTRA</th>
<th scope ="col" >FOLIO</th>
<th scope ="col" >AFILIACION</th>
<th scope ="col" >CLAPRO</th>
<th scope ="col" >CLAEDO</th>
<th scope ="col" >CLAREG</th>
<th scope ="col" >CLADIR</th>
<th scope ="col" >CLAUNI</th>
<th scope ="col" >NOMBRES</th>
<th scope ="col" >APELLIDO_P</th>
<th scope ="col" >APELLIDO_M</th>
<th scope ="col" >FEC_NAC</th>
<th scope ="col" >EDAD</th>
<th scope ="col" >FEC_REP</th>
<th scope ="col" >RESULTADO</th>
<th scope ="col" >OBSERVA</th>
<th scope ="col" >SUPLEMENTO</th>
<th scope ="col" >FEC_TOM</th>
<th scope ="col" >ESTUDIO</th>
<th colspan="2" >Acciones</th>
</tr>
        </thead>
<tbody>
        {this.loadFilData()}
        </tbody>
      </table>
    );
  }
loadFilData(){
return this.state.listtblcalidad9.map((data)=>{
return(
  <tr>
  <th>{data.idtblcalidad9}</th>

<td>{data.MUESTRA}</td>
<td>{data.FOLIO}</td>
<td>{data.AFILIACION}</td>
<td>{data.CLAPRO}</td>
<td>{data.CLAEDO}</td>
<td>{data.CLAREG}</td>
<td>{data.CLADIR}</td>
<td>{data.CLAUNI}</td>
<td>{data.NOMBRES}</td>
<td>{data.APELLIDO_P}</td>
<td>{data.APELLIDO_M}</td>
<td>{data.FEC_NAC}</td>
<td>{data.EDAD}</td>
<td>{data.FEC_REP}</td>
<td>{data.RESULTADO}</td>
<td>{data.OBSERVA}</td>
<td>{data.SUPLEMENTO}</td>
<td>{data.FEC_TOM}</td>
<td>{data.ESTUDIO}</td>
<td>
<Link class="btn btn-outline-info "  to={"/tblcalidad9Edit/"+data.idtblcalidad9} >Edit</Link>
</td>
<td>
  <button class="btn btn-outline-danger "> Delete </button>
</td>
</tr>
)
}
)
}
}
export default listComponent;
