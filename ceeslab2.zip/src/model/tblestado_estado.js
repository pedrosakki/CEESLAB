const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tblestado_estado')
var nametable = 'tblestado_estado';
var tblestado_estado = sequelize.define(nametable,{
idtblestado_estado:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


CLAEDO:  Sequelize.STRING,
ESTADO:  Sequelize.STRING,
NOM_ABR:  Sequelize.STRING,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tblestado_estado;
