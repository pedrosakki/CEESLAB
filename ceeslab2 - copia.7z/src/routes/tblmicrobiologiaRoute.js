const express = require('express');
const router = express.Router();
const tblmicrobiologiaController = require('../Controllers/tblmicrobiologiaController')


router.post('/update/:id',tblmicrobiologiaController.update)
router.get('/get/:id', tblmicrobiologiaController.get)
router.get('/list', tblmicrobiologiaController.list);
router.post('/create', tblmicrobiologiaController.create);


module.exports = router;
