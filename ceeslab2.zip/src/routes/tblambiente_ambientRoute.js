const express = require('express');
const router = express.Router();
const tblambiente_ambientController = require('../Controllers/tblambiente_ambientController')


router.post('/update/:id',tblambiente_ambientController.update)
router.get('/get/:id', tblambiente_ambientController.get)
router.get('/list', tblambiente_ambientController.list);
router.post('/create', tblambiente_ambientController.create);


module.exports = router;
