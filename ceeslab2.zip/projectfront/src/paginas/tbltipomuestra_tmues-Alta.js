import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios';
class EditComponent extends React.Component{
constructor(props){
super(props);
this.state = {
CLAMUE:"",
T_MUES:"",
GRUPO:""
}
}
render(){
  return (
<div>
 <div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAMUE </label>
<input type="text" class="form-control" placeholder="CLAMUE" value={this.state.CLAMUE} onChange={(value)=> this.setState({CLAMUE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">T_MUES </label>
<input type="text" class="form-control" placeholder="T_MUES" value={this.state.T_MUES} onChange={(value)=> this.setState({T_MUES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">GRUPO </label>
<input type="text" class="form-control" placeholder="GRUPO" value={this.state.GRUPO} onChange={(value)=> this.setState({GRUPO:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendSave()}>Save</button>
</div>
</div>
);
}
  sendSave(){
const baseUrl = "http://localhost:3000/Rtbltipomuestra_tmues/create"
const datapost = {
CLAMUE: this.state.CLAMUE,
T_MUES: this.state.T_MUES,
GRUPO: this.state.GRUPO
}
axios.post(baseUrl,datapost)
      .then(response=>{
 if (response.data.success===true) {
  alert(response.data.message)
}
else {
alert(response.data.message)
}
}).catch(error=>{
   alert("Error 34 "+error)
 })
 }
}
export default EditComponent;
