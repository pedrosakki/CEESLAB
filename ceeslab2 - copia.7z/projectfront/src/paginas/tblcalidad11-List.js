import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { Link } from "react-router-dom";
import axios from 'axios';
const url= 'http://localhost:3000/Rtblcalidad11/list';
class listComponent extends React.Component  {
constructor(props){
super(props);
this.state ={
listtblcalidad11:[]
}
}
componentDidMount(){
axios.get(url)
.then(res=>{
if(res.data.sucess){
const data = res.data.data
this.setState({listtblcalidad11:data})
}
else{
alert("Error web service")
}
})
.catch(error=>{
alert("Error Server"+error)
})
}
render()
{
    return (
      <table class="table table-hover table-striped">

        <thead class="thead-dark">

<tr>
<th scope = "col" >#</th>
<th scope ="col" >MUESTRA</th>
<th scope ="col" >PAQUETEVPH</th>
<th scope ="col" >FOLIO</th>
<th scope ="col" >AFILIACION</th>
<th scope ="col" >CLAPRO</th>
<th scope ="col" >CLAEDO</th>
<th scope ="col" >CLAREG</th>
<th scope ="col" >CLADIR</th>
<th scope ="col" >CLAUNI</th>
<th scope ="col" >NOMBRES</th>
<th scope ="col" >APELLIDO_P</th>
<th scope ="col" >APELLIDO_M</th>
<th scope ="col" >FEC_NAC</th>
<th scope ="col" >EDAD</th>
<th scope ="col" >FEC_TOM</th>
<th scope ="col" >FEC_REP</th>
<th scope ="col" >NUM_LAM</th>
<th scope ="col" >FORMATO</th>
<th scope ="col" >DX_CITO</th>
<th scope ="col" >HALL_CITO</th>
<th scope ="col" >DX_PATO</th>
<th scope ="col" >HALL_PATO</th>
<th scope ="col" >RFC_CITO</th>
<th scope ="col" >RFC_PATO</th>
<th scope ="col" >REV</th>
<th scope ="col" >TUMORAL</th>
<th scope ="col" >FEC_REP_MT</th>
<th scope ="col" >RFC_PATO_M</th>
<th scope ="col" >OBSERVA</th>
<th scope ="col" >SUPLEMENTO</th>
<th scope ="col" >RESULTADO</th>
<th colspan="2" >Acciones</th>
</tr>
        </thead>
<tbody>
        {this.loadFilData()}
        </tbody>
      </table>
    );
  }
loadFilData(){
return this.state.listtblcalidad11.map((data)=>{
return(
  <tr>
  <th>{data.idtblcalidad11}</th>

<td>{data.MUESTRA}</td>
<td>{data.PAQUETEVPH}</td>
<td>{data.FOLIO}</td>
<td>{data.AFILIACION}</td>
<td>{data.CLAPRO}</td>
<td>{data.CLAEDO}</td>
<td>{data.CLAREG}</td>
<td>{data.CLADIR}</td>
<td>{data.CLAUNI}</td>
<td>{data.NOMBRES}</td>
<td>{data.APELLIDO_P}</td>
<td>{data.APELLIDO_M}</td>
<td>{data.FEC_NAC}</td>
<td>{data.EDAD}</td>
<td>{data.FEC_TOM}</td>
<td>{data.FEC_REP}</td>
<td>{data.NUM_LAM}</td>
<td>{data.FORMATO}</td>
<td>{data.DX_CITO}</td>
<td>{data.HALL_CITO}</td>
<td>{data.DX_PATO}</td>
<td>{data.HALL_PATO}</td>
<td>{data.RFC_CITO}</td>
<td>{data.RFC_PATO}</td>
<td>{data.REV}</td>
<td>{data.TUMORAL}</td>
<td>{data.FEC_REP_MT}</td>
<td>{data.RFC_PATO_M}</td>
<td>{data.OBSERVA}</td>
<td>{data.SUPLEMENTO}</td>
<td>{data.RESULTADO}</td>
<td>
<Link class="btn btn-outline-info "  to={"/tblcalidad11Edit/"+data.idtblcalidad11} >Edit</Link>
</td>
<td>
  <button class="btn btn-outline-danger "> Delete </button>
</td>
</tr>
)
}
)
}
}
export default listComponent;
