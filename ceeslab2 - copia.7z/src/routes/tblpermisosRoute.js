const express = require('express');
const router = express.Router();
const tblpermisosController = require('../Controllers/tblpermisosController')


router.post('/update/:id',tblpermisosController.update)
router.get('/get/:id', tblpermisosController.get)
router.get('/list', tblpermisosController.list);
router.post('/create', tblpermisosController.create);


module.exports = router;
