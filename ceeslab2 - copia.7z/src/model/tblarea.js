const Sequelize = require('sequelize');
var sequelize = require('./database');
var area = require('./tblarea')
var nametable = 'tblarea';
var tblarea = sequelize.define(nametable,{
idTBLAREA:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: false},

DESCRIPCION: Sequelize.STRING,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tblarea;
