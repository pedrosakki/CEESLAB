const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tblcalidad5')
var nametable = 'tblcalidad5';
var tblcalidad5 = sequelize.define(nametable,{
idtblcalidad5:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


CLAPRO:  Sequelize.DECIMAL,
CLARMUE:  Sequelize.DECIMAL,
FEC_REP:  Sequelize.DATE,
FEC_CAP:  Sequelize.DATE,
FEC_IMP:  Sequelize.DATE,
FEC_VAL:  Sequelize.DATE,
VALIDADO:  Sequelize.INTEGER,
CLACAU:  Sequelize.INTEGER,
SUPLEMENTO:  Sequelize.INTEGER,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tblcalidad5;
