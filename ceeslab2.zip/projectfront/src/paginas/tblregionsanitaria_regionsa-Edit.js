import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios'
const baseUrl= "http: //localhost:3000"
class EditComponent extends React.Component{

constructor(props){

super(props);
this.state={
edittblregionsanitaria_regionsas:[],
datatblregionsanitaria_regionsa:{},
CLAPRO: "",
CLAEDO: "",
CLAREG: "",
REGION: ""
}
}


componentDidMount(){
let userId = this.props.match.params.tblregionsanitaria_regionsaid;
  const url = baseUrl+"/Rtblregionsanitaria_regionsa/get/"+userId

  axios.get(url)
 .then(res=>{
  if(res.data.sucess){
  const data = res.data.data[0] 
this.setState({
edittblregionsanitaria_regionsas:data,
CLAPRO: data.CLAPRO,
CLAEDO: data.CLAEDO,
CLAREG: data.CLAREG,
REGION: data.REGION
} ) }
else{
alert("Error web service")
} } )
  .catch(error=>{
  })
}


  render(){
   let userId = 0;
 return (
<div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAPRO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAPRO} onChange={(value)=> this.setState({CLAPRO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAEDO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAEDO} onChange={(value)=> this.setState({CLAEDO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAREG </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAREG} onChange={(value)=> this.setState({CLAREG:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">REGION </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.REGION} onChange={(value)=> this.setState({REGION:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendUpdate()}>Update</button>  
</div>
); }
sendUpdate(){
let userId = this.props.match.params.tblregionsanitaria_regionsaid;
const baseUrl = "http://localhost:3000/Rtblregionsanitaria_regionsa/Update/"+ userId
const datapost = {
CLAPRO: this.state.CLAPRO,
CLAEDO: this.state.CLAEDO,
CLAREG: this.state.CLAREG,
REGION: this.state.REGION
}
axios.post(baseUrl,datapost)
.then(response=>{
if (response.data.success===true) {
alert(response.data.message)
}
else {
alert(response.data.message)
alert(JSON.stringify(response))
}
}).catch(error=>{
alert("Error 34 "+error)
})
}
}
export default EditComponent;
