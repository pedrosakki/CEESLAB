 const controllers = {}
var sequelize = require('../model/database');
var tblmuestra_recep = require('../model/tblmuestra_recep');

//METODO GET//

controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tblmuestra_recep.findAll({
where: {idtblmuestra_recep: id }  })
.then(function(data){
    return data;})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}


//METODO LIST//

controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tblmuestra_recep.findAll();
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}



//METODO CREATE//
controllers.create = async (req, res)=>{
const  {MUESTRA,MUESTRA2,FEC_REC,HOR_REC,CLAPRO,CLAMUE,AMPLIAR_TM,TEM_REC,CONFIRMAR,OBSERVA,AM,AF,AMP,HT,VALIDADO,MOTIVO,PRIORIDAD,E1,EXAM1,E2,EXAM2,E3,EXAM3,E4,EXAM4,E5,EXAM5,E6,EXAM6,E7,EXAM7,E8,EXAM8,E9,EXAM9,E10,EXAM10,MODIFICADO,FEC_LAB,HOR_LAB,CLAREC}=req.body;
const data = await tblmuestra_recep.create({
MUESTRA: MUESTRA,
MUESTRA2: MUESTRA2,
FEC_REC: FEC_REC,
HOR_REC: HOR_REC,
CLAPRO: CLAPRO,
CLAMUE: CLAMUE,
AMPLIAR_TM: AMPLIAR_TM,
TEM_REC: TEM_REC,
CONFIRMAR: CONFIRMAR,
OBSERVA: OBSERVA,
AM: AM,
AF: AF,
AMP: AMP,
HT: HT,
VALIDADO: VALIDADO,
MOTIVO: MOTIVO,
PRIORIDAD: PRIORIDAD,
E1: E1,
EXAM1: EXAM1,
E2: E2,
EXAM2: EXAM2,
E3: E3,
EXAM3: EXAM3,
E4: E4,
EXAM4: EXAM4,
E5: E5,
EXAM5: EXAM5,
E6: E6,
EXAM6: EXAM6,
E7: E7,
EXAM7: EXAM7,
E8: E8,
EXAM8: EXAM8,
E9: E9,
EXAM9: EXAM9,
E10: E10,
EXAM10: EXAM10,
MODIFICADO: MODIFICADO,
FEC_LAB: FEC_LAB,
HOR_LAB: HOR_LAB,
CLAREC: CLAREC
}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data
})
}


//METODO UPDATE//
controllers.update = async (req, res)=>{
  const { id } = req.params;
const  {MUESTRA,MUESTRA2,FEC_REC,HOR_REC,CLAPRO,CLAMUE,AMPLIAR_TM,TEM_REC,CONFIRMAR,OBSERVA,AM,AF,AMP,HT,VALIDADO,MOTIVO,PRIORIDAD,E1,EXAM1,E2,EXAM2,E3,EXAM3,E4,EXAM4,E5,EXAM5,E6,EXAM6,E7,EXAM7,E8,EXAM8,E9,EXAM9,E10,EXAM10,MODIFICADO,FEC_LAB,HOR_LAB,CLAREC}=req.body;

 const data = await tblmuestra_recep.update({
MUESTRA: MUESTRA,
MUESTRA2: MUESTRA2,
FEC_REC: FEC_REC,
HOR_REC: HOR_REC,
CLAPRO: CLAPRO,
CLAMUE: CLAMUE,
AMPLIAR_TM: AMPLIAR_TM,
TEM_REC: TEM_REC,
CONFIRMAR: CONFIRMAR,
OBSERVA: OBSERVA,
AM: AM,
AF: AF,
AMP: AMP,
HT: HT,
VALIDADO: VALIDADO,
MOTIVO: MOTIVO,
PRIORIDAD: PRIORIDAD,
E1: E1,
EXAM1: EXAM1,
E2: E2,
EXAM2: EXAM2,
E3: E3,
EXAM3: EXAM3,
E4: E4,
EXAM4: EXAM4,
E5: E5,
EXAM5: EXAM5,
E6: E6,
EXAM6: EXAM6,
E7: E7,
EXAM7: EXAM7,
E8: E8,
EXAM8: EXAM8,
E9: E9,
EXAM9: EXAM9,
E10: E10,
EXAM10: EXAM10,
MODIFICADO: MODIFICADO,
FEC_LAB: FEC_LAB,
HOR_LAB: HOR_LAB,
CLAREC: CLAREC
   },{
          where: { idtblmuestra_recep: id}
     })
  .then( function(data){
    return data;
      })
       .catch(error => {
        return error;
   }) 
   res.json({success:true, data:data, message:"Updated successful"});
 }

 //BUSCA LA ULTIMA MUESTRA EN RECEPCION
controllers.ultima = async(req,res)=>{
  const data = await tblmuestra_recep.max('IDTBLMUESTRA_RECEP')
    .then(max => {
      //  console.log('Max Result....'+ max)
        if (max) { res.json(max+1)
        } else {
          if(max===0){ res.json(1)
          }else{ res.send('Num de Muestra no existente....(tblmuestra_recepController)')}         
        }        
      })
    .catch(err => {
        res.send('error (tblmuestra_recepController): ' + err)
      })
  .then(function(data){
      return data
    })
  .catch(error =>{
  return error
})
  res.json({sucess:true,data})
  }

 module.exports = controllers;
