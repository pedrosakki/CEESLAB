import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios'
const baseUrl= "http: //localhost:3000"
class EditComponent extends React.Component{

constructor(props){

super(props);
this.state={
edittblusuario_usuarioss:[],
datatblusuario_usuarios:{},
USUARIO: "",
PASSWORD: "",
ACCESO: "",
SECCION: "",
TIPO: "",
NIVEL: "",
SESION: "",
CODIGO: "",
NOMBRE: ""
}
}


componentDidMount(){
let userId = this.props.match.params.tblusuario_usuariosid;
  const url = baseUrl+"/Rtblusuario_usuarios/get/"+userId

  axios.get(url)
 .then(res=>{
  if(res.data.sucess){
  const data = res.data.data[0] 
this.setState({
edittblusuario_usuarioss:data,
USUARIO: data.USUARIO,
PASSWORD: data.PASSWORD,
ACCESO: data.ACCESO,
SECCION: data.SECCION,
TIPO: data.TIPO,
NIVEL: data.NIVEL,
SESION: data.SESION,
CODIGO: data.CODIGO,
NOMBRE: data.NOMBRE
} ) }
else{
alert("Error web service")
} } )
  .catch(error=>{
  })
}


  render(){
   let userId = 0;
 return (
<div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">USUARIO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.USUARIO} onChange={(value)=> this.setState({USUARIO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">PASSWORD </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.PASSWORD} onChange={(value)=> this.setState({PASSWORD:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ACCESO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ACCESO} onChange={(value)=> this.setState({ACCESO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SECCION </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.SECCION} onChange={(value)=> this.setState({SECCION:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TIPO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.TIPO} onChange={(value)=> this.setState({TIPO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">NIVEL </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.NIVEL} onChange={(value)=> this.setState({NIVEL:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SESION </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.SESION} onChange={(value)=> this.setState({SESION:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CODIGO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CODIGO} onChange={(value)=> this.setState({CODIGO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">NOMBRE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.NOMBRE} onChange={(value)=> this.setState({NOMBRE:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendUpdate()}>Update</button>  
</div>
); }
sendUpdate(){
let userId = this.props.match.params.tblusuario_usuariosid;
const baseUrl = "http://localhost:3000/Rtblusuario_usuarios/Update/"+ userId
const datapost = {
USUARIO: this.state.USUARIO,
PASSWORD: this.state.PASSWORD,
ACCESO: this.state.ACCESO,
SECCION: this.state.SECCION,
TIPO: this.state.TIPO,
NIVEL: this.state.NIVEL,
SESION: this.state.SESION,
CODIGO: this.state.CODIGO,
NOMBRE: this.state.NOMBRE
}
axios.post(baseUrl,datapost)
.then(response=>{
if (response.data.success===true) {
alert(response.data.message)
}
else {
alert(response.data.message)
alert(JSON.stringify(response))
}
}).catch(error=>{
alert("Error 34 "+error)
})
}
}
export default EditComponent;
