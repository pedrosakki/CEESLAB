const express = require('express');
const router = express.Router();
const tblenviodeta_envdetController = require('../Controllers/tblenviodeta_envdetController')


router.post('/update/:id',tblenviodeta_envdetController.update)
router.get('/get/:id', tblenviodeta_envdetController.get)
router.get('/list', tblenviodeta_envdetController.list);
router.post('/create', tblenviodeta_envdetController.create);


module.exports = router;
