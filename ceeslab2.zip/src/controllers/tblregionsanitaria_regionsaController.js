 const controllers = {}
var sequelize = require('../model/database');
var tblregionsanitaria_regionsa = require('../model/tblregionsanitaria_regionsa');

//METODO GET//

controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tblregionsanitaria_regionsa.findAll({
where: {idtblregionsanitaria_regionsa: id }  })
.then(function(data){
    return data;})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}


//METODO LIST//

controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tblregionsanitaria_regionsa.findAll();
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}



//METODO CREATE//
controllers.create = async (req, res)=>{
const  {CLAPRO,CLAEDO,CLAREG,REGION}=req.body;
const data = await tblregionsanitaria_regionsa.create({
CLAPRO: CLAPRO,
CLAEDO: CLAEDO,
CLAREG: CLAREG,
REGION: REGION
}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data
})
}


//METODO UPDATE//
controllers.update = async (req, res)=>{
  const { id } = req.params;
const  {CLAPRO,CLAEDO,CLAREG,REGION}=req.body;

 const data = await tblregionsanitaria_regionsa.update({
CLAPRO: CLAPRO,
CLAEDO: CLAEDO,
CLAREG: CLAREG,
REGION: REGION
   },{
          where: { idtblregionsanitaria_regionsa: id}
     })
  .then( function(data){
    return data;
      })
       .catch(error => {
        return error;
   }) 
   res.json({success:true, data:data, message:"Updated successful"});
 }



 module.exports = controllers;
