import React, { Component } from 'react'


class PageError extends Component {
  constructor() {
    super()
    this.state = {     
    }
  }


  render() {
    return (
<div className="page-404-3">

<div className="container error-404">
	<h1>404</h1>
	<h2>Houston, Tenemos un problema.</h2>
	<p>
		La página que buscas no existe....
	</p>	
</div>
</div>
    )
  }
}

export default PageError

