import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios'
const baseUrl= "http: //localhost:3000"
class EditComponent extends React.Component{

constructor(props){

super(props);
this.state={
edittbltiporesultado_tiporess:[],
datatbltiporesultado_tipores:{},
CLARES: "",
RESULTADO: ""
}
}


componentDidMount(){
let userId = this.props.match.params.tbltiporesultado_tiporesid;
  const url = baseUrl+"/Rtbltiporesultado_tipores/get/"+userId

  axios.get(url)
 .then(res=>{
  if(res.data.sucess){
  const data = res.data.data[0] 
this.setState({
edittbltiporesultado_tiporess:data,
CLARES: data.CLARES,
RESULTADO: data.RESULTADO
} ) }
else{
alert("Error web service")
} } )
  .catch(error=>{
  })
}


  render(){
   let userId = 0;
 return (
<div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLARES </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLARES} onChange={(value)=> this.setState({CLARES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RESULTADO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RESULTADO} onChange={(value)=> this.setState({RESULTADO:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendUpdate()}>Update</button>  
</div>
); }
sendUpdate(){
let userId = this.props.match.params.tbltiporesultado_tiporesid;
const baseUrl = "http://localhost:3000/Rtbltiporesultado_tipores/Update/"+ userId
const datapost = {
CLARES: this.state.CLARES,
RESULTADO: this.state.RESULTADO
}
axios.post(baseUrl,datapost)
.then(response=>{
if (response.data.success===true) {
alert(response.data.message)
}
else {
alert(response.data.message)
alert(JSON.stringify(response))
}
}).catch(error=>{
alert("Error 34 "+error)
})
}
}
export default EditComponent;
