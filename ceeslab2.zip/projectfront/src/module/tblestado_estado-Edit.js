import React from 'react';import 'bootstrap/dist/css/bootstrap.min.css';import 'bootstrap/dist/js/bootstrap.bundle.min';import axios from 'axios'const baseUrl= "http: //localhost:3000"class EditComponent extends React.Component{
constructor(props){
super(props);this.state={edittblestado_estados:[],datatblestado_estado:{},CLAEDO: CLAEDO,
ESTADO: ESTADO
NOM_ABR: NOM_ABR
}}componentDidMount(){let userId = this.props.match.params.tblestado_estadoid;  const url = baseUrl+"/Rtblestado_estado/get/"+userId  axios.get(url) .then(res=>{  if(res.data.sucess){  const data = res.data.data[0] this.setState({edittblestado_estados:data,CLAEDO: CLAEDO,
ESTADO: ESTADO
NOM_ABR: NOM_ABR
} ) }else{alert("Error web service")} } )  .catch(error=>{  })}  render(){   let userId = 0; return (<div class="form-row justify-content-center"><div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAEDO </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAEDO} onChange={(value)=> this.setState({CLAEDO:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">ESTADO </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ESTADO} onChange={(value)=> this.setState({ESTADO:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">NOM_ABR </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.NOM_ABR} onChange={(value)=> this.setState({NOM_ABR:value.target.value})}/></div><button type="submit" class="btn btn-primary" onClick={()=>this.sendUpdate()}>Update</button>  </div>); }sendUpdate(){let userId = this.props.match.params.tblestado_estadoid;const baseUrl = "http://localhost:3000/Rtblestado_estado/update/"+userIdconst datapost = {CLAEDO: tjos-state. CLAEDO,
ESTADO: tjos-state. ESTADO
NOM_ABR: tjos-state. NOM_ABR
}axios.post(baseUrl,datapost).then(response=>{if (response.data.success===true) {alert(response.data.message)}else {alert(response.data.message)alert(JSON.stringify(response))}}).catch(error=>{alert("Error 34 "+error)})}}export default EditComponent;