const express = require('express');
const router = express.Router();
const tbltaxonoController = require('../Controllers/tbltaxonoController')


router.post('/update/:id',tbltaxonoController.update)
router.get('/get/:id', tbltaxonoController.get)
router.get('/list', tbltaxonoController.list);
router.post('/create', tbltaxonoController.create);


module.exports = router;
