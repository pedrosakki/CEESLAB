const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tblcalidad7')
var nametable = 'tblcalidad7';
var tblcalidad7 = sequelize.define(nametable,{
idtblcalidad7:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


MUESTRA:  Sequelize.STRING,
CLAPRO:  Sequelize.DECIMAL,
CLAMUE:  Sequelize.DECIMAL,
OFICIO:  Sequelize.STRING,
FEC_REP:  Sequelize.DATE,
OBSERVA:  Sequelize.STRING,
CITOTECNO:  Sequelize.INTEGER,
LR:  Sequelize.STRING,
TLI:  Sequelize.STRING,
CRN:  Sequelize.STRING,
CRP:  Sequelize.STRING,
IPD:  Sequelize.STRING,
EL_LPRNE:  Sequelize.STRING,
EL_LPRMS:  Sequelize.STRING,
EL_LPRT:  Sequelize.STRING,
EL_LPRP:  Sequelize.STRING,
EL_LNRNE:  Sequelize.STRING,
EL_LNRNS:  Sequelize.STRING,
EL_LNRT:  Sequelize.STRING,
EL_LNRP:  Sequelize.STRING,
CD_PDN:  Sequelize.STRING,
CD_PDP:  Sequelize.STRING,
CD_PD_FPN:  Sequelize.STRING,
CD_NDN:  Sequelize.STRING,
CD_NDP:  Sequelize.STRING,
CD_ND_FNN:  Sequelize.STRING,
CD_ND_IN:  Sequelize.STRING,
TOT_IN:  Sequelize.STRING,
TOT_IP:  Sequelize.STRING,
FEC_CAP:  Sequelize.DATE,
FEC_IMP:  Sequelize.DATE,
FEC_VAL:  Sequelize.DATE,
VALIDADO:  Sequelize.INTEGER,
CLACAU:  Sequelize.INTEGER,
SUPLEMENTO:  Sequelize.INTEGER,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tblcalidad7;
