 const controllers = {}
var sequelize = require('../model/database');
var tblcalidad4 = require('../model/tblcalidad4');

//METODO GET//

controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tblcalidad4.findAll({
where: {idtblcalidad4: id }  })
.then(function(data){
    return data;})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}


//METODO LIST//

controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tblcalidad4.findAll();
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}



//METODO CREATE//
controllers.create = async (req, res)=>{
const  {MUESTRA,CLAPRO,CLAMUE,OFICIO,FEC_REP,OBSERVA,CITOTECNO,TLI,CRN,CRP,IPD,EL_LPRNE,EL_LPRNS,EL_LPRT,EL_LPRP,EL_LNRNE,EL_LNRNS,EL_LNRT,EL_LNRP,EL_LIRNE,EL_LIRT,EL_LIRP,CD_PDN,CD_PDP,CD_PD_FPN,CD_PD_IN,CD_NDN,CD_NDP,CD_ND_FNN,CD_ND_IN,CD_FIN,CD_FIP,CD_FI_PN,CF_FI_PP,CD_FI_NN,CD_FI_NP,TOT_IN,TOT_IP,FEC_CAP,FEC_IMP,FEC_VAL,VALIDADO,VLAVAU,SUPLEMENTO}=req.body;
const data = await tblcalidad4.create({
MUESTRA: MUESTRA,
CLAPRO: CLAPRO,
CLAMUE: CLAMUE,
OFICIO: OFICIO,
FEC_REP: FEC_REP,
OBSERVA: OBSERVA,
CITOTECNO: CITOTECNO,
TLI: TLI,
CRN: CRN,
CRP: CRP,
IPD: IPD,
EL_LPRNE: EL_LPRNE,
EL_LPRNS: EL_LPRNS,
EL_LPRT: EL_LPRT,
EL_LPRP: EL_LPRP,
EL_LNRNE: EL_LNRNE,
EL_LNRNS: EL_LNRNS,
EL_LNRT: EL_LNRT,
EL_LNRP: EL_LNRP,
EL_LIRNE: EL_LIRNE,
EL_LIRT: EL_LIRT,
EL_LIRP: EL_LIRP,
CD_PDN: CD_PDN,
CD_PDP: CD_PDP,
CD_PD_FPN: CD_PD_FPN,
CD_PD_IN: CD_PD_IN,
CD_NDN: CD_NDN,
CD_NDP: CD_NDP,
CD_ND_FNN: CD_ND_FNN,
CD_ND_IN: CD_ND_IN,
CD_FIN: CD_FIN,
CD_FIP: CD_FIP,
CD_FI_PN: CD_FI_PN,
CF_FI_PP: CF_FI_PP,
CD_FI_NN: CD_FI_NN,
CD_FI_NP: CD_FI_NP,
TOT_IN: TOT_IN,
TOT_IP: TOT_IP,
FEC_CAP: FEC_CAP,
FEC_IMP: FEC_IMP,
FEC_VAL: FEC_VAL,
VALIDADO: VALIDADO,
VLAVAU: VLAVAU,
SUPLEMENTO: SUPLEMENTO
}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data
})
}


//METODO UPDATE//
controllers.update = async (req, res)=>{
  const { id } = req.params;
const  {MUESTRA,CLAPRO,CLAMUE,OFICIO,FEC_REP,OBSERVA,CITOTECNO,TLI,CRN,CRP,IPD,EL_LPRNE,EL_LPRNS,EL_LPRT,EL_LPRP,EL_LNRNE,EL_LNRNS,EL_LNRT,EL_LNRP,EL_LIRNE,EL_LIRT,EL_LIRP,CD_PDN,CD_PDP,CD_PD_FPN,CD_PD_IN,CD_NDN,CD_NDP,CD_ND_FNN,CD_ND_IN,CD_FIN,CD_FIP,CD_FI_PN,CF_FI_PP,CD_FI_NN,CD_FI_NP,TOT_IN,TOT_IP,FEC_CAP,FEC_IMP,FEC_VAL,VALIDADO,VLAVAU,SUPLEMENTO}=req.body;

 const data = await tblcalidad4.update({
MUESTRA: MUESTRA,
CLAPRO: CLAPRO,
CLAMUE: CLAMUE,
OFICIO: OFICIO,
FEC_REP: FEC_REP,
OBSERVA: OBSERVA,
CITOTECNO: CITOTECNO,
TLI: TLI,
CRN: CRN,
CRP: CRP,
IPD: IPD,
EL_LPRNE: EL_LPRNE,
EL_LPRNS: EL_LPRNS,
EL_LPRT: EL_LPRT,
EL_LPRP: EL_LPRP,
EL_LNRNE: EL_LNRNE,
EL_LNRNS: EL_LNRNS,
EL_LNRT: EL_LNRT,
EL_LNRP: EL_LNRP,
EL_LIRNE: EL_LIRNE,
EL_LIRT: EL_LIRT,
EL_LIRP: EL_LIRP,
CD_PDN: CD_PDN,
CD_PDP: CD_PDP,
CD_PD_FPN: CD_PD_FPN,
CD_PD_IN: CD_PD_IN,
CD_NDN: CD_NDN,
CD_NDP: CD_NDP,
CD_ND_FNN: CD_ND_FNN,
CD_ND_IN: CD_ND_IN,
CD_FIN: CD_FIN,
CD_FIP: CD_FIP,
CD_FI_PN: CD_FI_PN,
CF_FI_PP: CF_FI_PP,
CD_FI_NN: CD_FI_NN,
CD_FI_NP: CD_FI_NP,
TOT_IN: TOT_IN,
TOT_IP: TOT_IP,
FEC_CAP: FEC_CAP,
FEC_IMP: FEC_IMP,
FEC_VAL: FEC_VAL,
VALIDADO: VALIDADO,
VLAVAU: VLAVAU,
SUPLEMENTO: SUPLEMENTO
   },{
          where: { idtblcalidad4: id}
     })
  .then( function(data){
    return data;
      })
       .catch(error => {
        return error;
   }) 
   res.json({success:true, data:data, message:"Updated successful"});
 }



 module.exports = controllers;
