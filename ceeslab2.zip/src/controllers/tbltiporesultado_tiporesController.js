 const controllers = {}
var sequelize = require('../model/database');
var tbltiporesultado_tipores = require('../model/tbltiporesultado_tipores');

//METODO GET//

controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tbltiporesultado_tipores.findAll({
where: {idtbltiporesultado_tipores: id }  })
.then(function(data){
    return data;})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}


//METODO LIST//

controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tbltiporesultado_tipores.findAll();
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}



//METODO CREATE//
controllers.create = async (req, res)=>{
const  {CLARES,RESULTADO}=req.body;
const data = await tbltiporesultado_tipores.create({
CLARES: CLARES,
RESULTADO: RESULTADO
}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data
})
}


//METODO UPDATE//
controllers.update = async (req, res)=>{
  const { id } = req.params;
const  {CLARES,RESULTADO}=req.body;

 const data = await tbltiporesultado_tipores.update({
CLARES: CLARES,
RESULTADO: RESULTADO
   },{
          where: { idtbltiporesultado_tipores: id}
     })
  .then( function(data){
    return data;
      })
       .catch(error => {
        return error;
   }) 
   res.json({success:true, data:data, message:"Updated successful"});
 }



 module.exports = controllers;
