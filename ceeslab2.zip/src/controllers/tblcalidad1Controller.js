 const controllers = {}
var sequelize = require('../model/database');
var tblcalidad1 = require('../model/tblcalidad1');

//METODO GET//

controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tblcalidad1.findAll({
where: {idtblcalidad1: id }  })
.then(function(data){
    return data;})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}


//METODO LIST//

controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tblcalidad1.findAll();
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}



//METODO CREATE//
controllers.create = async (req, res)=>{
const  {MUESTRA,CLAPRO,CLAMUE,E1,EXAM1,FEC_RESP,MES,LABORATORIO,OBSERVA,FN_1,FN_2,NEW,HEMOLI,LIPEMI,CONTAM,INSUFI,ADECUA,TOT_SUE,FEC_CAP,FEC_IMP,FEC_VAL,VALIDADO,CLACAU,SUPLEMENTO}=req.body;
const data = await tblcalidad1.create({
MUESTRA: MUESTRA,
CLAPRO: CLAPRO,
CLAMUE: CLAMUE,
E1: E1,
EXAM1: EXAM1,
FEC_RESP: FEC_RESP,
MES: MES,
LABORATORIO: LABORATORIO,
OBSERVA: OBSERVA,
FN_1: FN_1,
FN_2: FN_2,
NEW: NEW,
HEMOLI: HEMOLI,
LIPEMI: LIPEMI,
CONTAM: CONTAM,
INSUFI: INSUFI,
ADECUA: ADECUA,
TOT_SUE: TOT_SUE,
FEC_CAP: FEC_CAP,
FEC_IMP: FEC_IMP,
FEC_VAL: FEC_VAL,
VALIDADO: VALIDADO,
CLACAU: CLACAU,
SUPLEMENTO: SUPLEMENTO
}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data
})
}


//METODO UPDATE//
controllers.update = async (req, res)=>{
  const { id } = req.params;
const  {MUESTRA,CLAPRO,CLAMUE,E1,EXAM1,FEC_RESP,MES,LABORATORIO,OBSERVA,FN_1,FN_2,NEW,HEMOLI,LIPEMI,CONTAM,INSUFI,ADECUA,TOT_SUE,FEC_CAP,FEC_IMP,FEC_VAL,VALIDADO,CLACAU,SUPLEMENTO}=req.body;

 const data = await tblcalidad1.update({
MUESTRA: MUESTRA,
CLAPRO: CLAPRO,
CLAMUE: CLAMUE,
E1: E1,
EXAM1: EXAM1,
FEC_RESP: FEC_RESP,
MES: MES,
LABORATORIO: LABORATORIO,
OBSERVA: OBSERVA,
FN_1: FN_1,
FN_2: FN_2,
NEW: NEW,
HEMOLI: HEMOLI,
LIPEMI: LIPEMI,
CONTAM: CONTAM,
INSUFI: INSUFI,
ADECUA: ADECUA,
TOT_SUE: TOT_SUE,
FEC_CAP: FEC_CAP,
FEC_IMP: FEC_IMP,
FEC_VAL: FEC_VAL,
VALIDADO: VALIDADO,
CLACAU: CLACAU,
SUPLEMENTO: SUPLEMENTO
   },{
          where: { idtblcalidad1: id}
     })
  .then( function(data){
    return data;
      })
       .catch(error => {
        return error;
   }) 
   res.json({success:true, data:data, message:"Updated successful"});
 }



 module.exports = controllers;
