import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios';
class EditComponent extends React.Component{
constructor(props){
super(props);
this.state = {
MUESTRA:"",
FOLIO:"",
AFILIACION:"",
CLAPRO:"",
CLAEDO:"",
CLAREG:"",
CLADIR:"",
CLAUNI:"",
NOMBRES:"",
APELLIDO_P:"",
APELLIDO_M:"",
FEC_NAC:"",
EDAD:"",
FEC_REP:"",
RESULTADO:"",
OBSERVA:"",
SUPLEMENTO:"",
FEC_TOM:"",
ESTUDIO:""
}
}
render(){
  return (
<div>
 <div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MUESTRA </label>
<input type="text" class="form-control" placeholder="MUESTRA" value={this.state.MUESTRA} onChange={(value)=> this.setState({MUESTRA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FOLIO </label>
<input type="text" class="form-control" placeholder="FOLIO" value={this.state.FOLIO} onChange={(value)=> this.setState({FOLIO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">AFILIACION </label>
<input type="text" class="form-control" placeholder="AFILIACION" value={this.state.AFILIACION} onChange={(value)=> this.setState({AFILIACION:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAPRO </label>
<input type="text" class="form-control" placeholder="CLAPRO" value={this.state.CLAPRO} onChange={(value)=> this.setState({CLAPRO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAEDO </label>
<input type="text" class="form-control" placeholder="CLAEDO" value={this.state.CLAEDO} onChange={(value)=> this.setState({CLAEDO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAREG </label>
<input type="text" class="form-control" placeholder="CLAREG" value={this.state.CLAREG} onChange={(value)=> this.setState({CLAREG:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLADIR </label>
<input type="text" class="form-control" placeholder="CLADIR" value={this.state.CLADIR} onChange={(value)=> this.setState({CLADIR:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAUNI </label>
<input type="text" class="form-control" placeholder="CLAUNI" value={this.state.CLAUNI} onChange={(value)=> this.setState({CLAUNI:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">NOMBRES </label>
<input type="text" class="form-control" placeholder="NOMBRES" value={this.state.NOMBRES} onChange={(value)=> this.setState({NOMBRES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">APELLIDO_P </label>
<input type="text" class="form-control" placeholder="APELLIDO_P" value={this.state.APELLIDO_P} onChange={(value)=> this.setState({APELLIDO_P:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">APELLIDO_M </label>
<input type="text" class="form-control" placeholder="APELLIDO_M" value={this.state.APELLIDO_M} onChange={(value)=> this.setState({APELLIDO_M:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_NAC </label>
<input type="text" class="form-control" placeholder="FEC_NAC" value={this.state.FEC_NAC} onChange={(value)=> this.setState({FEC_NAC:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EDAD </label>
<input type="text" class="form-control" placeholder="EDAD" value={this.state.EDAD} onChange={(value)=> this.setState({EDAD:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_REP </label>
<input type="text" class="form-control" placeholder="FEC_REP" value={this.state.FEC_REP} onChange={(value)=> this.setState({FEC_REP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RESULTADO </label>
<input type="text" class="form-control" placeholder="RESULTADO" value={this.state.RESULTADO} onChange={(value)=> this.setState({RESULTADO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OBSERVA </label>
<input type="text" class="form-control" placeholder="OBSERVA" value={this.state.OBSERVA} onChange={(value)=> this.setState({OBSERVA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SUPLEMENTO </label>
<input type="text" class="form-control" placeholder="SUPLEMENTO" value={this.state.SUPLEMENTO} onChange={(value)=> this.setState({SUPLEMENTO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_TOM </label>
<input type="text" class="form-control" placeholder="FEC_TOM" value={this.state.FEC_TOM} onChange={(value)=> this.setState({FEC_TOM:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ESTUDIO </label>
<input type="text" class="form-control" placeholder="ESTUDIO" value={this.state.ESTUDIO} onChange={(value)=> this.setState({ESTUDIO:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendSave()}>Save</button>
</div>
</div>
);
}
  sendSave(){
const baseUrl = "http://localhost:3000/Rtblcalidad9/create"
const datapost = {
MUESTRA: this.state.MUESTRA,
FOLIO: this.state.FOLIO,
AFILIACION: this.state.AFILIACION,
CLAPRO: this.state.CLAPRO,
CLAEDO: this.state.CLAEDO,
CLAREG: this.state.CLAREG,
CLADIR: this.state.CLADIR,
CLAUNI: this.state.CLAUNI,
NOMBRES: this.state.NOMBRES,
APELLIDO_P: this.state.APELLIDO_P,
APELLIDO_M: this.state.APELLIDO_M,
FEC_NAC: this.state.FEC_NAC,
EDAD: this.state.EDAD,
FEC_REP: this.state.FEC_REP,
RESULTADO: this.state.RESULTADO,
OBSERVA: this.state.OBSERVA,
SUPLEMENTO: this.state.SUPLEMENTO,
FEC_TOM: this.state.FEC_TOM,
ESTUDIO: this.state.ESTUDIO
}
axios.post(baseUrl,datapost)
      .then(response=>{
 if (response.data.success===true) {
  alert(response.data.message)
}
else {
alert(response.data.message)
}
}).catch(error=>{
   alert("Error 34 "+error)
 })
 }
}
export default EditComponent;
