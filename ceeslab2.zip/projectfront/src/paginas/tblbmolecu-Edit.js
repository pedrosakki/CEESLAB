import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios'
const baseUrl= "http: //localhost:3000"
class EditComponent extends React.Component{

constructor(props){

super(props);
this.state={
edittblbmolecus:[],
datatblbmolecu:{},
MUESTRA: "",
DOCTO: "",
NUM_DOC: "",
CLAPRO: "",
CLAMUE: "",
CONFIRMAR: "",
AFILIACION: "",
PRIORIDAD: "",
NOMBRES: "",
APELLIDO_P: "",
APELLIDO_M: "",
ANIOS: "",
MESES: "",
SEXO: "",
DOMICILIO: "",
COLONIA: "",
LOCALIDAD: "",
CLAEDO: "",
CLAMUN: "",
FEC_TOM: "",
HOR_TOM: "",
FEC_IEN: "",
E1: "",
EXAM1: "",
RES1: "",
RESUL1: "",
FR1: "",
INDRE1: "",
E10: "",
E9: "",
E8: "",
E7: "",
E6: "",
E5: "",
E4: "",
E3: "",
E2: "",
EXAM10: "",
EXAM9: "",
EXAM8: "",
EXAM7: "",
EXAM6: "",
EXAM5: "",
EXAM4: "",
EXAM3: "",
EXAM2: "",
RES10: "",
RES9: "",
RES8: "",
RES7: "",
RES6: "",
RES5: "",
RES4: "",
RES3: "",
RES2: "",
RESUL10: "",
RESUL9: "",
RESUL8: "",
RESUL7: "",
RESUL6: "",
RESUL5: "",
RESUL4: "",
RESUL3: "",
RESUL2: "",
FR10: "",
FR9: "",
FR8: "",
FR7: "",
FR6: "",
FR5: "",
FR4: "",
FR3: "",
FR2: "",
INDRE10: "",
INDRE9: "",
INDRE8: "",
INDRE7: "",
INDRE6: "",
INDRE5: "",
INDRE4: "",
INDRE3: "",
INDRE2: ""
}
}


componentDidMount(){
let userId = this.props.match.params.tblbmolecuid;
  const url = baseUrl+"/Rtblbmolecu/get/"+userId

  axios.get(url)
 .then(res=>{
  if(res.data.sucess){
  const data = res.data.data[0] 
this.setState({
edittblbmolecus:data,
MUESTRA: data.MUESTRA,
DOCTO: data.DOCTO,
NUM_DOC: data.NUM_DOC,
CLAPRO: data.CLAPRO,
CLAMUE: data.CLAMUE,
CONFIRMAR: data.CONFIRMAR,
AFILIACION: data.AFILIACION,
PRIORIDAD: data.PRIORIDAD,
NOMBRES: data.NOMBRES,
APELLIDO_P: data.APELLIDO_P,
APELLIDO_M: data.APELLIDO_M,
ANIOS: data.ANIOS,
MESES: data.MESES,
SEXO: data.SEXO,
DOMICILIO: data.DOMICILIO,
COLONIA: data.COLONIA,
LOCALIDAD: data.LOCALIDAD,
CLAEDO: data.CLAEDO,
CLAMUN: data.CLAMUN,
FEC_TOM: data.FEC_TOM,
HOR_TOM: data.HOR_TOM,
FEC_IEN: data.FEC_IEN,
E1: data.E1,
EXAM1: data.EXAM1,
RES1: data.RES1,
RESUL1: data.RESUL1,
FR1: data.FR1,
INDRE1: data.INDRE1,
E10: data.E10,
E9: data.E9,
E8: data.E8,
E7: data.E7,
E6: data.E6,
E5: data.E5,
E4: data.E4,
E3: data.E3,
E2: data.E2,
EXAM10: data.EXAM10,
EXAM9: data.EXAM9,
EXAM8: data.EXAM8,
EXAM7: data.EXAM7,
EXAM6: data.EXAM6,
EXAM5: data.EXAM5,
EXAM4: data.EXAM4,
EXAM3: data.EXAM3,
EXAM2: data.EXAM2,
RES10: data.RES10,
RES9: data.RES9,
RES8: data.RES8,
RES7: data.RES7,
RES6: data.RES6,
RES5: data.RES5,
RES4: data.RES4,
RES3: data.RES3,
RES2: data.RES2,
RESUL10: data.RESUL10,
RESUL9: data.RESUL9,
RESUL8: data.RESUL8,
RESUL7: data.RESUL7,
RESUL6: data.RESUL6,
RESUL5: data.RESUL5,
RESUL4: data.RESUL4,
RESUL3: data.RESUL3,
RESUL2: data.RESUL2,
FR10: data.FR10,
FR9: data.FR9,
FR8: data.FR8,
FR7: data.FR7,
FR6: data.FR6,
FR5: data.FR5,
FR4: data.FR4,
FR3: data.FR3,
FR2: data.FR2,
INDRE10: data.INDRE10,
INDRE9: data.INDRE9,
INDRE8: data.INDRE8,
INDRE7: data.INDRE7,
INDRE6: data.INDRE6,
INDRE5: data.INDRE5,
INDRE4: data.INDRE4,
INDRE3: data.INDRE3,
INDRE2: data.INDRE2
} ) }
else{
alert("Error web service")
} } )
  .catch(error=>{
  })
}


  render(){
   let userId = 0;
 return (
<div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MUESTRA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.MUESTRA} onChange={(value)=> this.setState({MUESTRA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DOCTO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DOCTO} onChange={(value)=> this.setState({DOCTO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">NUM_DOC </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.NUM_DOC} onChange={(value)=> this.setState({NUM_DOC:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAPRO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAPRO} onChange={(value)=> this.setState({CLAPRO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAMUE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAMUE} onChange={(value)=> this.setState({CLAMUE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CONFIRMAR </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CONFIRMAR} onChange={(value)=> this.setState({CONFIRMAR:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">AFILIACION </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.AFILIACION} onChange={(value)=> this.setState({AFILIACION:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">PRIORIDAD </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.PRIORIDAD} onChange={(value)=> this.setState({PRIORIDAD:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">NOMBRES </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.NOMBRES} onChange={(value)=> this.setState({NOMBRES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">APELLIDO_P </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.APELLIDO_P} onChange={(value)=> this.setState({APELLIDO_P:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">APELLIDO_M </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.APELLIDO_M} onChange={(value)=> this.setState({APELLIDO_M:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ANIOS </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ANIOS} onChange={(value)=> this.setState({ANIOS:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MESES </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.MESES} onChange={(value)=> this.setState({MESES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SEXO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.SEXO} onChange={(value)=> this.setState({SEXO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DOMICILIO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DOMICILIO} onChange={(value)=> this.setState({DOMICILIO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">COLONIA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.COLONIA} onChange={(value)=> this.setState({COLONIA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">LOCALIDAD </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.LOCALIDAD} onChange={(value)=> this.setState({LOCALIDAD:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAEDO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAEDO} onChange={(value)=> this.setState({CLAEDO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAMUN </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAMUN} onChange={(value)=> this.setState({CLAMUN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_TOM </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_TOM} onChange={(value)=> this.setState({FEC_TOM:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">HOR_TOM </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.HOR_TOM} onChange={(value)=> this.setState({HOR_TOM:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_IEN </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_IEN} onChange={(value)=> this.setState({FEC_IEN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E1} onChange={(value)=> this.setState({E1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM1} onChange={(value)=> this.setState({EXAM1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RES1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RES1} onChange={(value)=> this.setState({RES1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RESUL1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RESUL1} onChange={(value)=> this.setState({RESUL1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FR1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FR1} onChange={(value)=> this.setState({FR1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">INDRE1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.INDRE1} onChange={(value)=> this.setState({INDRE1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E10 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E10} onChange={(value)=> this.setState({E10:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E9 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E9} onChange={(value)=> this.setState({E9:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E8 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E8} onChange={(value)=> this.setState({E8:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E7 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E7} onChange={(value)=> this.setState({E7:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E6 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E6} onChange={(value)=> this.setState({E6:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E5 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E5} onChange={(value)=> this.setState({E5:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E4 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E4} onChange={(value)=> this.setState({E4:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E3 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E3} onChange={(value)=> this.setState({E3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E2} onChange={(value)=> this.setState({E2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM10 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM10} onChange={(value)=> this.setState({EXAM10:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM9 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM9} onChange={(value)=> this.setState({EXAM9:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM8 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM8} onChange={(value)=> this.setState({EXAM8:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM7 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM7} onChange={(value)=> this.setState({EXAM7:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM6 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM6} onChange={(value)=> this.setState({EXAM6:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM5 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM5} onChange={(value)=> this.setState({EXAM5:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM4 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM4} onChange={(value)=> this.setState({EXAM4:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM3 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM3} onChange={(value)=> this.setState({EXAM3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM2} onChange={(value)=> this.setState({EXAM2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RES10 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RES10} onChange={(value)=> this.setState({RES10:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RES9 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RES9} onChange={(value)=> this.setState({RES9:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RES8 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RES8} onChange={(value)=> this.setState({RES8:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RES7 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RES7} onChange={(value)=> this.setState({RES7:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RES6 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RES6} onChange={(value)=> this.setState({RES6:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RES5 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RES5} onChange={(value)=> this.setState({RES5:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RES4 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RES4} onChange={(value)=> this.setState({RES4:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RES3 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RES3} onChange={(value)=> this.setState({RES3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RES2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RES2} onChange={(value)=> this.setState({RES2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RESUL10 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RESUL10} onChange={(value)=> this.setState({RESUL10:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RESUL9 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RESUL9} onChange={(value)=> this.setState({RESUL9:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RESUL8 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RESUL8} onChange={(value)=> this.setState({RESUL8:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RESUL7 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RESUL7} onChange={(value)=> this.setState({RESUL7:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RESUL6 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RESUL6} onChange={(value)=> this.setState({RESUL6:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RESUL5 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RESUL5} onChange={(value)=> this.setState({RESUL5:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RESUL4 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RESUL4} onChange={(value)=> this.setState({RESUL4:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RESUL3 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RESUL3} onChange={(value)=> this.setState({RESUL3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RESUL2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RESUL2} onChange={(value)=> this.setState({RESUL2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FR10 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FR10} onChange={(value)=> this.setState({FR10:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FR9 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FR9} onChange={(value)=> this.setState({FR9:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FR8 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FR8} onChange={(value)=> this.setState({FR8:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FR7 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FR7} onChange={(value)=> this.setState({FR7:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FR6 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FR6} onChange={(value)=> this.setState({FR6:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FR5 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FR5} onChange={(value)=> this.setState({FR5:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FR4 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FR4} onChange={(value)=> this.setState({FR4:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FR3 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FR3} onChange={(value)=> this.setState({FR3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FR2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FR2} onChange={(value)=> this.setState({FR2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">INDRE10 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.INDRE10} onChange={(value)=> this.setState({INDRE10:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">INDRE9 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.INDRE9} onChange={(value)=> this.setState({INDRE9:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">INDRE8 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.INDRE8} onChange={(value)=> this.setState({INDRE8:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">INDRE7 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.INDRE7} onChange={(value)=> this.setState({INDRE7:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">INDRE6 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.INDRE6} onChange={(value)=> this.setState({INDRE6:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">INDRE5 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.INDRE5} onChange={(value)=> this.setState({INDRE5:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">INDRE4 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.INDRE4} onChange={(value)=> this.setState({INDRE4:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">INDRE3 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.INDRE3} onChange={(value)=> this.setState({INDRE3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">INDRE2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.INDRE2} onChange={(value)=> this.setState({INDRE2:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendUpdate()}>Update</button>  
</div>
); }
sendUpdate(){
let userId = this.props.match.params.tblbmolecuid;
const baseUrl = "http://localhost:3000/Rtblbmolecu/Update/"+ userId
const datapost = {
MUESTRA: this.state.MUESTRA,
DOCTO: this.state.DOCTO,
NUM_DOC: this.state.NUM_DOC,
CLAPRO: this.state.CLAPRO,
CLAMUE: this.state.CLAMUE,
CONFIRMAR: this.state.CONFIRMAR,
AFILIACION: this.state.AFILIACION,
PRIORIDAD: this.state.PRIORIDAD,
NOMBRES: this.state.NOMBRES,
APELLIDO_P: this.state.APELLIDO_P,
APELLIDO_M: this.state.APELLIDO_M,
ANIOS: this.state.ANIOS,
MESES: this.state.MESES,
SEXO: this.state.SEXO,
DOMICILIO: this.state.DOMICILIO,
COLONIA: this.state.COLONIA,
LOCALIDAD: this.state.LOCALIDAD,
CLAEDO: this.state.CLAEDO,
CLAMUN: this.state.CLAMUN,
FEC_TOM: this.state.FEC_TOM,
HOR_TOM: this.state.HOR_TOM,
FEC_IEN: this.state.FEC_IEN,
E1: this.state.E1,
EXAM1: this.state.EXAM1,
RES1: this.state.RES1,
RESUL1: this.state.RESUL1,
FR1: this.state.FR1,
INDRE1: this.state.INDRE1,
E10: this.state.E10,
E9: this.state.E9,
E8: this.state.E8,
E7: this.state.E7,
E6: this.state.E6,
E5: this.state.E5,
E4: this.state.E4,
E3: this.state.E3,
E2: this.state.E2,
EXAM10: this.state.EXAM10,
EXAM9: this.state.EXAM9,
EXAM8: this.state.EXAM8,
EXAM7: this.state.EXAM7,
EXAM6: this.state.EXAM6,
EXAM5: this.state.EXAM5,
EXAM4: this.state.EXAM4,
EXAM3: this.state.EXAM3,
EXAM2: this.state.EXAM2,
RES10: this.state.RES10,
RES9: this.state.RES9,
RES8: this.state.RES8,
RES7: this.state.RES7,
RES6: this.state.RES6,
RES5: this.state.RES5,
RES4: this.state.RES4,
RES3: this.state.RES3,
RES2: this.state.RES2,
RESUL10: this.state.RESUL10,
RESUL9: this.state.RESUL9,
RESUL8: this.state.RESUL8,
RESUL7: this.state.RESUL7,
RESUL6: this.state.RESUL6,
RESUL5: this.state.RESUL5,
RESUL4: this.state.RESUL4,
RESUL3: this.state.RESUL3,
RESUL2: this.state.RESUL2,
FR10: this.state.FR10,
FR9: this.state.FR9,
FR8: this.state.FR8,
FR7: this.state.FR7,
FR6: this.state.FR6,
FR5: this.state.FR5,
FR4: this.state.FR4,
FR3: this.state.FR3,
FR2: this.state.FR2,
INDRE10: this.state.INDRE10,
INDRE9: this.state.INDRE9,
INDRE8: this.state.INDRE8,
INDRE7: this.state.INDRE7,
INDRE6: this.state.INDRE6,
INDRE5: this.state.INDRE5,
INDRE4: this.state.INDRE4,
INDRE3: this.state.INDRE3,
INDRE2: this.state.INDRE2
}
axios.post(baseUrl,datapost)
.then(response=>{
if (response.data.success===true) {
alert(response.data.message)
}
else {
alert(response.data.message)
alert(JSON.stringify(response))
}
}).catch(error=>{
alert("Error 34 "+error)
})
}
}
export default EditComponent;
