import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios'
const baseUrl= "http: //localhost:3000"
class EditComponent extends React.Component{

constructor(props){

super(props);
this.state={
edittblcalidad4s:[],
datatblcalidad4:{},
MUESTRA: "",
CLAPRO: "",
CLAMUE: "",
OFICIO: "",
FEC_REP: "",
OBSERVA: "",
CITOTECNO: "",
TLI: "",
CRN: "",
CRP: "",
IPD: "",
EL_LPRNE: "",
EL_LPRNS: "",
EL_LPRT: "",
EL_LPRP: "",
EL_LNRNE: "",
EL_LNRNS: "",
EL_LNRT: "",
EL_LNRP: "",
EL_LIRNE: "",
EL_LIRT: "",
EL_LIRP: "",
CD_PDN: "",
CD_PDP: "",
CD_PD_FPN: "",
CD_PD_IN: "",
CD_NDN: "",
CD_NDP: "",
CD_ND_FNN: "",
CD_ND_IN: "",
CD_FIN: "",
CD_FIP: "",
CD_FI_PN: "",
CF_FI_PP: "",
CD_FI_NN: "",
CD_FI_NP: "",
TOT_IN: "",
TOT_IP: "",
FEC_CAP: "",
FEC_IMP: "",
FEC_VAL: "",
VALIDADO: "",
VLAVAU: "",
SUPLEMENTO: ""
}
}


componentDidMount(){
let userId = this.props.match.params.tblcalidad4id;
  const url = baseUrl+"/Rtblcalidad4/get/"+userId

  axios.get(url)
 .then(res=>{
  if(res.data.sucess){
  const data = res.data.data[0] 
this.setState({
edittblcalidad4s:data,
MUESTRA: data.MUESTRA,
CLAPRO: data.CLAPRO,
CLAMUE: data.CLAMUE,
OFICIO: data.OFICIO,
FEC_REP: data.FEC_REP,
OBSERVA: data.OBSERVA,
CITOTECNO: data.CITOTECNO,
TLI: data.TLI,
CRN: data.CRN,
CRP: data.CRP,
IPD: data.IPD,
EL_LPRNE: data.EL_LPRNE,
EL_LPRNS: data.EL_LPRNS,
EL_LPRT: data.EL_LPRT,
EL_LPRP: data.EL_LPRP,
EL_LNRNE: data.EL_LNRNE,
EL_LNRNS: data.EL_LNRNS,
EL_LNRT: data.EL_LNRT,
EL_LNRP: data.EL_LNRP,
EL_LIRNE: data.EL_LIRNE,
EL_LIRT: data.EL_LIRT,
EL_LIRP: data.EL_LIRP,
CD_PDN: data.CD_PDN,
CD_PDP: data.CD_PDP,
CD_PD_FPN: data.CD_PD_FPN,
CD_PD_IN: data.CD_PD_IN,
CD_NDN: data.CD_NDN,
CD_NDP: data.CD_NDP,
CD_ND_FNN: data.CD_ND_FNN,
CD_ND_IN: data.CD_ND_IN,
CD_FIN: data.CD_FIN,
CD_FIP: data.CD_FIP,
CD_FI_PN: data.CD_FI_PN,
CF_FI_PP: data.CF_FI_PP,
CD_FI_NN: data.CD_FI_NN,
CD_FI_NP: data.CD_FI_NP,
TOT_IN: data.TOT_IN,
TOT_IP: data.TOT_IP,
FEC_CAP: data.FEC_CAP,
FEC_IMP: data.FEC_IMP,
FEC_VAL: data.FEC_VAL,
VALIDADO: data.VALIDADO,
VLAVAU: data.VLAVAU,
SUPLEMENTO: data.SUPLEMENTO
} ) }
else{
alert("Error web service")
} } )
  .catch(error=>{
  })
}


  render(){
   let userId = 0;
 return (
<div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MUESTRA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.MUESTRA} onChange={(value)=> this.setState({MUESTRA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAPRO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAPRO} onChange={(value)=> this.setState({CLAPRO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAMUE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAMUE} onChange={(value)=> this.setState({CLAMUE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OFICIO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.OFICIO} onChange={(value)=> this.setState({OFICIO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_REP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_REP} onChange={(value)=> this.setState({FEC_REP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OBSERVA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.OBSERVA} onChange={(value)=> this.setState({OBSERVA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CITOTECNO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CITOTECNO} onChange={(value)=> this.setState({CITOTECNO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TLI </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.TLI} onChange={(value)=> this.setState({TLI:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CRN </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CRN} onChange={(value)=> this.setState({CRN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CRP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CRP} onChange={(value)=> this.setState({CRP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">IPD </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.IPD} onChange={(value)=> this.setState({IPD:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EL_LPRNE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EL_LPRNE} onChange={(value)=> this.setState({EL_LPRNE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EL_LPRNS </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EL_LPRNS} onChange={(value)=> this.setState({EL_LPRNS:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EL_LPRT </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EL_LPRT} onChange={(value)=> this.setState({EL_LPRT:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EL_LPRP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EL_LPRP} onChange={(value)=> this.setState({EL_LPRP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EL_LNRNE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EL_LNRNE} onChange={(value)=> this.setState({EL_LNRNE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EL_LNRNS </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EL_LNRNS} onChange={(value)=> this.setState({EL_LNRNS:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EL_LNRT </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EL_LNRT} onChange={(value)=> this.setState({EL_LNRT:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EL_LNRP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EL_LNRP} onChange={(value)=> this.setState({EL_LNRP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EL_LIRNE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EL_LIRNE} onChange={(value)=> this.setState({EL_LIRNE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EL_LIRT </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EL_LIRT} onChange={(value)=> this.setState({EL_LIRT:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EL_LIRP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EL_LIRP} onChange={(value)=> this.setState({EL_LIRP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD_PDN </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CD_PDN} onChange={(value)=> this.setState({CD_PDN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD_PDP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CD_PDP} onChange={(value)=> this.setState({CD_PDP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD_PD_FPN </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CD_PD_FPN} onChange={(value)=> this.setState({CD_PD_FPN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD_PD_IN </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CD_PD_IN} onChange={(value)=> this.setState({CD_PD_IN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD_NDN </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CD_NDN} onChange={(value)=> this.setState({CD_NDN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD_NDP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CD_NDP} onChange={(value)=> this.setState({CD_NDP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD_ND_FNN </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CD_ND_FNN} onChange={(value)=> this.setState({CD_ND_FNN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD_ND_IN </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CD_ND_IN} onChange={(value)=> this.setState({CD_ND_IN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD_FIN </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CD_FIN} onChange={(value)=> this.setState({CD_FIN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD_FIP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CD_FIP} onChange={(value)=> this.setState({CD_FIP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD_FI_PN </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CD_FI_PN} onChange={(value)=> this.setState({CD_FI_PN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CF_FI_PP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CF_FI_PP} onChange={(value)=> this.setState({CF_FI_PP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD_FI_NN </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CD_FI_NN} onChange={(value)=> this.setState({CD_FI_NN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD_FI_NP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CD_FI_NP} onChange={(value)=> this.setState({CD_FI_NP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TOT_IN </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.TOT_IN} onChange={(value)=> this.setState({TOT_IN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TOT_IP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.TOT_IP} onChange={(value)=> this.setState({TOT_IP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_CAP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_CAP} onChange={(value)=> this.setState({FEC_CAP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_IMP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_IMP} onChange={(value)=> this.setState({FEC_IMP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_VAL </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_VAL} onChange={(value)=> this.setState({FEC_VAL:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">VALIDADO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.VALIDADO} onChange={(value)=> this.setState({VALIDADO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">VLAVAU </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.VLAVAU} onChange={(value)=> this.setState({VLAVAU:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SUPLEMENTO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.SUPLEMENTO} onChange={(value)=> this.setState({SUPLEMENTO:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendUpdate()}>Update</button>  
</div>
); }
sendUpdate(){
let userId = this.props.match.params.tblcalidad4id;
const baseUrl = "http://localhost:3000/Rtblcalidad4/Update/"+ userId
const datapost = {
MUESTRA: this.state.MUESTRA,
CLAPRO: this.state.CLAPRO,
CLAMUE: this.state.CLAMUE,
OFICIO: this.state.OFICIO,
FEC_REP: this.state.FEC_REP,
OBSERVA: this.state.OBSERVA,
CITOTECNO: this.state.CITOTECNO,
TLI: this.state.TLI,
CRN: this.state.CRN,
CRP: this.state.CRP,
IPD: this.state.IPD,
EL_LPRNE: this.state.EL_LPRNE,
EL_LPRNS: this.state.EL_LPRNS,
EL_LPRT: this.state.EL_LPRT,
EL_LPRP: this.state.EL_LPRP,
EL_LNRNE: this.state.EL_LNRNE,
EL_LNRNS: this.state.EL_LNRNS,
EL_LNRT: this.state.EL_LNRT,
EL_LNRP: this.state.EL_LNRP,
EL_LIRNE: this.state.EL_LIRNE,
EL_LIRT: this.state.EL_LIRT,
EL_LIRP: this.state.EL_LIRP,
CD_PDN: this.state.CD_PDN,
CD_PDP: this.state.CD_PDP,
CD_PD_FPN: this.state.CD_PD_FPN,
CD_PD_IN: this.state.CD_PD_IN,
CD_NDN: this.state.CD_NDN,
CD_NDP: this.state.CD_NDP,
CD_ND_FNN: this.state.CD_ND_FNN,
CD_ND_IN: this.state.CD_ND_IN,
CD_FIN: this.state.CD_FIN,
CD_FIP: this.state.CD_FIP,
CD_FI_PN: this.state.CD_FI_PN,
CF_FI_PP: this.state.CF_FI_PP,
CD_FI_NN: this.state.CD_FI_NN,
CD_FI_NP: this.state.CD_FI_NP,
TOT_IN: this.state.TOT_IN,
TOT_IP: this.state.TOT_IP,
FEC_CAP: this.state.FEC_CAP,
FEC_IMP: this.state.FEC_IMP,
FEC_VAL: this.state.FEC_VAL,
VALIDADO: this.state.VALIDADO,
VLAVAU: this.state.VLAVAU,
SUPLEMENTO: this.state.SUPLEMENTO
}
axios.post(baseUrl,datapost)
.then(response=>{
if (response.data.success===true) {
alert(response.data.message)
}
else {
alert(response.data.message)
alert(JSON.stringify(response))
}
}).catch(error=>{
alert("Error 34 "+error)
})
}
}
export default EditComponent;
