const express = require('express');
const router = express.Router();
const tblcalidad6Controller = require('../Controllers/tblcalidad6Controller')


router.post('/update/:id',tblcalidad6Controller.update)
router.get('/get/:id', tblcalidad6Controller.get)
router.get('/list', tblcalidad6Controller.list);
router.post('/create', tblcalidad6Controller.create);


module.exports = router;
