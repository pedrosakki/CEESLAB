const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tblcalidad3')
var nametable = 'tblcalidad3';
var tblcalidad3 = sequelize.define(nametable,{
idtblcalidad3:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


MUESTRA:  Sequelize.INTEGER,
CLAPRO:  Sequelize.DECIMAL,
CLAMUE:  Sequelize.DECIMAL,
FEC_REP:  Sequelize.DATE,
OBSERVA:  Sequelize.STRING,
SEMANA:  Sequelize.STRING,
MICROSCO:  Sequelize.STRING,
REVIS:  Sequelize.INTEGER,
CMUESTRA:  Sequelize.STRING,
CTINCINO:  Sequelize.STRING,
FNEGATIVAS:  Sequelize.INTEGER,
FPOSITIVAS:  Sequelize.INTEGER,
TGOT:  Sequelize.STRING,
FEC_CAP:  Sequelize.DATE,
FEC_IMP:  Sequelize.DATE,
FEC_VAL:  Sequelize.DATE,
VALIDADO:  Sequelize.INTEGER,
CLACAU:  Sequelize.INTEGER,
SUPLEMENTO:  Sequelize.INTEGER,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tblcalidad3;
