const express = require('express');
const router = express.Router();
const tblusuario_usuariosController = require('../Controllers/tblusuario_usuariosController')


router.post('/update/:id',tblusuario_usuariosController.update)
router.get('/get/:id', tblusuario_usuariosController.get)
router.get('/list', tblusuario_usuariosController.list);
router.post('/create', tblusuario_usuariosController.create);
router.post('/LogAccess', tblusuario_usuariosController.LogAccess);


module.exports = router;
