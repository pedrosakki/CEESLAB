const express = require('express');
const router = express.Router();
const tbltiporesultado_tiporesController = require('../Controllers/tbltiporesultado_tiporesController')


router.post('/update/:id',tbltiporesultado_tiporesController.update)
router.get('/get/:id', tbltiporesultado_tiporesController.get)
router.get('/list', tbltiporesultado_tiporesController.list);
router.post('/create', tbltiporesultado_tiporesController.create);


module.exports = router;
