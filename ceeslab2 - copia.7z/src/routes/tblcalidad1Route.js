const express = require('express');
const router = express.Router();
const tblcalidad1Controller = require('../Controllers/tblcalidad1Controller')


router.post('/update/:id',tblcalidad1Controller.update)
router.get('/get/:id', tblcalidad1Controller.get)
router.get('/list', tblcalidad1Controller.list);
router.post('/create', tblcalidad1Controller.create);


module.exports = router;
