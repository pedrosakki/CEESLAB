const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tblcargaviral_carvir')
var nametable = 'tblcargaviral_carvir';
var tblcargaviral_carvir = sequelize.define(nametable,{
idtblcargaviral_carvir:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


MUESTRA:  Sequelize.INTEGER,
ID_SALVAR:  Sequelize.INTEGER,
FEC_PRO:  Sequelize.DATE,
CLARES:  Sequelize.INTEGER,
COPIAS_ML:  Sequelize.STRING,
LOG:  Sequelize.INTEGER,
CD3:  Sequelize.INTEGER,
P_CD3:  Sequelize.INTEGER,
CD3_CD4:  Sequelize.INTEGER,
P_CD3_CD4:  Sequelize.INTEGER,
CD3_CD8:  Sequelize.INTEGER,
P_CD3_CD8:  Sequelize.INTEGER,
CD4_CD8:  Sequelize.INTEGER,
FEC_REP:  Sequelize.DATE,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tblcargaviral_carvir;
