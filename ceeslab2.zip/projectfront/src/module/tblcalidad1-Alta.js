import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios';
class EditComponent extends React.Component{
  constructor(props){super(props);
    this.state = {
      MUESTRA:"",
CLAPRO:"",
CLAMUE:"",
E1:"",
EXAM1:"",
FEC_RESP:"",
MES:"",
LABORATORIO:"",
OBSERVA:"",
FN_1:"",
FN_2:"",
NEW:"",
HEMOLI:"",
LIPEMI:"",
CONTAM:"",
INSUFI:"",
ADECUA:"",
TOT_SUE:"",
FEC_CAP:"",
FEC_IMP:"",
FEC_VAL:"",
VALIDADO:"",
CLACAU:""
SUPLEMENTO:""
}}  return (
  <div>
  <div class="form-row justify-content-center">
  <div class="form-group col-md-6">
<label for="inputApellidoPaterno">MUESTRA </label><input type="text" class="form-control" placeholder="MUESTRA" value={this.state.MUESTRA} onChange={(value)=> this.setState({MUESTRA:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAPRO </label><input type="text" class="form-control" placeholder="CLAPRO" value={this.state.CLAPRO} onChange={(value)=> this.setState({CLAPRO:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAMUE </label><input type="text" class="form-control" placeholder="CLAMUE" value={this.state.CLAMUE} onChange={(value)=> this.setState({CLAMUE:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">E1 </label><input type="text" class="form-control" placeholder="E1" value={this.state.E1} onChange={(value)=> this.setState({E1:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM1 </label><input type="text" class="form-control" placeholder="EXAM1" value={this.state.EXAM1} onChange={(value)=> this.setState({EXAM1:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_RESP </label><input type="text" class="form-control" placeholder="FEC_RESP" value={this.state.FEC_RESP} onChange={(value)=> this.setState({FEC_RESP:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">MES </label><input type="text" class="form-control" placeholder="MES" value={this.state.MES} onChange={(value)=> this.setState({MES:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">LABORATORIO </label><input type="text" class="form-control" placeholder="LABORATORIO" value={this.state.LABORATORIO} onChange={(value)=> this.setState({LABORATORIO:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">OBSERVA </label><input type="text" class="form-control" placeholder="OBSERVA" value={this.state.OBSERVA} onChange={(value)=> this.setState({OBSERVA:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN_1 </label><input type="text" class="form-control" placeholder="FN_1" value={this.state.FN_1} onChange={(value)=> this.setState({FN_1:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN_2 </label><input type="text" class="form-control" placeholder="FN_2" value={this.state.FN_2} onChange={(value)=> this.setState({FN_2:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">NEW </label><input type="text" class="form-control" placeholder="NEW" value={this.state.NEW} onChange={(value)=> this.setState({NEW:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">HEMOLI </label><input type="text" class="form-control" placeholder="HEMOLI" value={this.state.HEMOLI} onChange={(value)=> this.setState({HEMOLI:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">LIPEMI </label><input type="text" class="form-control" placeholder="LIPEMI" value={this.state.LIPEMI} onChange={(value)=> this.setState({LIPEMI:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">CONTAM </label><input type="text" class="form-control" placeholder="CONTAM" value={this.state.CONTAM} onChange={(value)=> this.setState({CONTAM:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">INSUFI </label><input type="text" class="form-control" placeholder="INSUFI" value={this.state.INSUFI} onChange={(value)=> this.setState({INSUFI:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">ADECUA </label><input type="text" class="form-control" placeholder="ADECUA" value={this.state.ADECUA} onChange={(value)=> this.setState({ADECUA:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">TOT_SUE </label><input type="text" class="form-control" placeholder="TOT_SUE" value={this.state.TOT_SUE} onChange={(value)=> this.setState({TOT_SUE:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_CAP </label><input type="text" class="form-control" placeholder="FEC_CAP" value={this.state.FEC_CAP} onChange={(value)=> this.setState({FEC_CAP:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_IMP </label><input type="text" class="form-control" placeholder="FEC_IMP" value={this.state.FEC_IMP} onChange={(value)=> this.setState({FEC_IMP:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_VAL </label><input type="text" class="form-control" placeholder="FEC_VAL" value={this.state.FEC_VAL} onChange={(value)=> this.setState({FEC_VAL:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">VALIDADO </label><input type="text" class="form-control" placeholder="VALIDADO" value={this.state.VALIDADO} onChange={(value)=> this.setState({VALIDADO:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLACAU </label><input type="text" class="form-control" placeholder="CLACAU" value={this.state.CLACAU} onChange={(value)=> this.setState({CLACAU:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">SUPLEMENTO </label><input type="text" class="form-control" placeholder="SUPLEMENTO" value={this.state.SUPLEMENTO} onChange={(value)=> this.setState({SUPLEMENTO:value.target.value})}/></div><button type="submit" class="btn btn-primary" onClick={()=>this.sendSave()}>Save</button></div></div>);}  sendSave(){const baseUrl = "http: //localhost:3000/R"tblcalidad1/create"const datapost = {MUESTRA: this.state.MUESTRA,
CLAPRO: this.state.CLAPRO,
CLAMUE: this.state.CLAMUE,
E1: this.state.E1,
EXAM1: this.state.EXAM1,
FEC_RESP: this.state.FEC_RESP,
MES: this.state.MES,
LABORATORIO: this.state.LABORATORIO,
OBSERVA: this.state.OBSERVA,
FN_1: this.state.FN_1,
FN_2: this.state.FN_2,
NEW: this.state.NEW,
HEMOLI: this.state.HEMOLI,
LIPEMI: this.state.LIPEMI,
CONTAM: this.state.CONTAM,
INSUFI: this.state.INSUFI,
ADECUA: this.state.ADECUA,
TOT_SUE: this.state.TOT_SUE,
FEC_CAP: this.state.FEC_CAP,
FEC_IMP: this.state.FEC_IMP,
FEC_VAL: this.state.FEC_VAL,
VALIDADO: this.state.VALIDADO,
CLACAU: this.state.CLACAU
SUPLEMENTO: this.state.SUPLEMENTO
}axios.post(baseUrl,datapost)
  .then(response=>{ if (response.data.success===true) {
     alert(response.data.message)
   }else {alert(response.data.message)}})
   .catch(error=>{   alert("Error 34 "+error) })
 }}
   export default EditComponent;
