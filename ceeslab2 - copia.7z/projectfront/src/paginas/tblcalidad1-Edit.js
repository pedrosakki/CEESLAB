import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios'
const baseUrl= "http: //localhost:3000"
class EditComponent extends React.Component{

constructor(props){

super(props);
this.state={
edittblcalidad1s:[],
datatblcalidad1:{},
MUESTRA: "",
CLAPRO: "",
CLAMUE: "",
E1: "",
EXAM1: "",
FEC_RESP: "",
MES: "",
LABORATORIO: "",
OBSERVA: "",
FN_1: "",
FN_2: "",
NEW: "",
HEMOLI: "",
LIPEMI: "",
CONTAM: "",
INSUFI: "",
ADECUA: "",
TOT_SUE: "",
FEC_CAP: "",
FEC_IMP: "",
FEC_VAL: "",
VALIDADO: "",
CLACAU: "",
SUPLEMENTO: ""
}
}


componentDidMount(){
let userId = this.props.match.params.tblcalidad1id;
  const url = baseUrl+"/Rtblcalidad1/get/"+userId

  axios.get(url)
 .then(res=>{
  if(res.data.sucess){
  const data = res.data.data[0] 
this.setState({
edittblcalidad1s:data,
MUESTRA: data.MUESTRA,
CLAPRO: data.CLAPRO,
CLAMUE: data.CLAMUE,
E1: data.E1,
EXAM1: data.EXAM1,
FEC_RESP: data.FEC_RESP,
MES: data.MES,
LABORATORIO: data.LABORATORIO,
OBSERVA: data.OBSERVA,
FN_1: data.FN_1,
FN_2: data.FN_2,
NEW: data.NEW,
HEMOLI: data.HEMOLI,
LIPEMI: data.LIPEMI,
CONTAM: data.CONTAM,
INSUFI: data.INSUFI,
ADECUA: data.ADECUA,
TOT_SUE: data.TOT_SUE,
FEC_CAP: data.FEC_CAP,
FEC_IMP: data.FEC_IMP,
FEC_VAL: data.FEC_VAL,
VALIDADO: data.VALIDADO,
CLACAU: data.CLACAU,
SUPLEMENTO: data.SUPLEMENTO
} ) }
else{
alert("Error web service")
} } )
  .catch(error=>{
  })
}


  render(){
   let userId = 0;
 return (
<div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MUESTRA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.MUESTRA} onChange={(value)=> this.setState({MUESTRA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAPRO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAPRO} onChange={(value)=> this.setState({CLAPRO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAMUE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAMUE} onChange={(value)=> this.setState({CLAMUE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E1} onChange={(value)=> this.setState({E1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM1} onChange={(value)=> this.setState({EXAM1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_RESP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_RESP} onChange={(value)=> this.setState({FEC_RESP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MES </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.MES} onChange={(value)=> this.setState({MES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">LABORATORIO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.LABORATORIO} onChange={(value)=> this.setState({LABORATORIO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OBSERVA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.OBSERVA} onChange={(value)=> this.setState({OBSERVA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN_1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FN_1} onChange={(value)=> this.setState({FN_1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN_2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FN_2} onChange={(value)=> this.setState({FN_2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">NEW </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.NEW} onChange={(value)=> this.setState({NEW:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">HEMOLI </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.HEMOLI} onChange={(value)=> this.setState({HEMOLI:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">LIPEMI </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.LIPEMI} onChange={(value)=> this.setState({LIPEMI:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CONTAM </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CONTAM} onChange={(value)=> this.setState({CONTAM:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">INSUFI </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.INSUFI} onChange={(value)=> this.setState({INSUFI:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ADECUA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ADECUA} onChange={(value)=> this.setState({ADECUA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TOT_SUE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.TOT_SUE} onChange={(value)=> this.setState({TOT_SUE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_CAP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_CAP} onChange={(value)=> this.setState({FEC_CAP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_IMP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_IMP} onChange={(value)=> this.setState({FEC_IMP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_VAL </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_VAL} onChange={(value)=> this.setState({FEC_VAL:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">VALIDADO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.VALIDADO} onChange={(value)=> this.setState({VALIDADO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLACAU </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLACAU} onChange={(value)=> this.setState({CLACAU:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SUPLEMENTO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.SUPLEMENTO} onChange={(value)=> this.setState({SUPLEMENTO:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendUpdate()}>Update</button>  
</div>
); }
sendUpdate(){
let userId = this.props.match.params.tblcalidad1id;
const baseUrl = "http://localhost:3000/Rtblcalidad1/Update/"+ userId
const datapost = {
MUESTRA: this.state.MUESTRA,
CLAPRO: this.state.CLAPRO,
CLAMUE: this.state.CLAMUE,
E1: this.state.E1,
EXAM1: this.state.EXAM1,
FEC_RESP: this.state.FEC_RESP,
MES: this.state.MES,
LABORATORIO: this.state.LABORATORIO,
OBSERVA: this.state.OBSERVA,
FN_1: this.state.FN_1,
FN_2: this.state.FN_2,
NEW: this.state.NEW,
HEMOLI: this.state.HEMOLI,
LIPEMI: this.state.LIPEMI,
CONTAM: this.state.CONTAM,
INSUFI: this.state.INSUFI,
ADECUA: this.state.ADECUA,
TOT_SUE: this.state.TOT_SUE,
FEC_CAP: this.state.FEC_CAP,
FEC_IMP: this.state.FEC_IMP,
FEC_VAL: this.state.FEC_VAL,
VALIDADO: this.state.VALIDADO,
CLACAU: this.state.CLACAU,
SUPLEMENTO: this.state.SUPLEMENTO
}
axios.post(baseUrl,datapost)
.then(response=>{
if (response.data.success===true) {
alert(response.data.message)
}
else {
alert(response.data.message)
alert(JSON.stringify(response))
}
}).catch(error=>{
alert("Error 34 "+error)
})
}
}
export default EditComponent;
