 const controllers = {}
var sequelize = require('../model/database');
var tblcalidad10 = require('../model/tblcalidad10');

//METODO GET//

controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tblcalidad10.findAll({
where: {idtblcalidad10: id }  })
.then(function(data){
    return data;})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}


//METODO LIST//

controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tblcalidad10.findAll();
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}



//METODO CREATE//
controllers.create = async (req, res)=>{
const  {CLAPRO,CLAMUE,FEC_REP,FEC_CAP,FEC_IMP,FEC_VAL,VALIDADO,CLACAU,SUPLEMENTO}=req.body;
const data = await tblcalidad10.create({
CLAPRO: CLAPRO,
CLAMUE: CLAMUE,
FEC_REP: FEC_REP,
FEC_CAP: FEC_CAP,
FEC_IMP: FEC_IMP,
FEC_VAL: FEC_VAL,
VALIDADO: VALIDADO,
CLACAU: CLACAU,
SUPLEMENTO: SUPLEMENTO
}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data
})
}


//METODO UPDATE//
controllers.update = async (req, res)=>{
  const { id } = req.params;
const  {CLAPRO,CLAMUE,FEC_REP,FEC_CAP,FEC_IMP,FEC_VAL,VALIDADO,CLACAU,SUPLEMENTO}=req.body;

 const data = await tblcalidad10.update({
CLAPRO: CLAPRO,
CLAMUE: CLAMUE,
FEC_REP: FEC_REP,
FEC_CAP: FEC_CAP,
FEC_IMP: FEC_IMP,
FEC_VAL: FEC_VAL,
VALIDADO: VALIDADO,
CLACAU: CLACAU,
SUPLEMENTO: SUPLEMENTO
   },{
          where: { idtblcalidad10: id}
     })
  .then( function(data){
    return data;
      })
       .catch(error => {
        return error;
   }) 
   res.json({success:true, data:data, message:"Updated successful"});
 }



 module.exports = controllers;
