 const controllers = {}
var sequelize = require('../model/database');
var tbltipomuestra_tmues = require('../model/tbltipomuestra_tmues');

//METODO GET//

controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tbltipomuestra_tmues.findAll({
where: {idtbltipomuestra_tmues: id }  })
.then(function(data){
    return data;})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}


//METODO LIST//

controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tbltipomuestra_tmues.findAll();
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}



//METODO CREATE//
controllers.create = async (req, res)=>{
const  {CLAMUE,T_MUES,GRUPO}=req.body;
const data = await tbltipomuestra_tmues.create({
CLAMUE: CLAMUE,
T_MUES: T_MUES,
GRUPO: GRUPO
}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data
})
}


//METODO UPDATE//
controllers.update = async (req, res)=>{
  const { id } = req.params;
const  {CLAMUE,T_MUES,GRUPO}=req.body;

 const data = await tbltipomuestra_tmues.update({
CLAMUE: CLAMUE,
T_MUES: T_MUES,
GRUPO: GRUPO
   },{
          where: { idtbltipomuestra_tmues: id}
     })
  .then( function(data){
    return data;
      })
       .catch(error => {
        return error;
   }) 
   res.json({success:true, data:data, message:"Updated successful"});
 }





 module.exports = controllers;
