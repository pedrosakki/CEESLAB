import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios'
const baseUrl= "http: //localhost:3000"
class EditComponent extends React.Component{

constructor(props){

super(props);
this.state={
edittblcalidad5s:[],
datatblcalidad5:{},
CLAPRO: "",
CLARMUE: "",
FEC_REP: "",
FEC_CAP: "",
FEC_IMP: "",
FEC_VAL: "",
VALIDADO: "",
CLACAU: "",
SUPLEMENTO: ""
}
}


componentDidMount(){
let userId = this.props.match.params.tblcalidad5id;
  const url = baseUrl+"/Rtblcalidad5/get/"+userId

  axios.get(url)
 .then(res=>{
  if(res.data.sucess){
  const data = res.data.data[0] 
this.setState({
edittblcalidad5s:data,
CLAPRO: data.CLAPRO,
CLARMUE: data.CLARMUE,
FEC_REP: data.FEC_REP,
FEC_CAP: data.FEC_CAP,
FEC_IMP: data.FEC_IMP,
FEC_VAL: data.FEC_VAL,
VALIDADO: data.VALIDADO,
CLACAU: data.CLACAU,
SUPLEMENTO: data.SUPLEMENTO
} ) }
else{
alert("Error web service")
} } )
  .catch(error=>{
  })
}


  render(){
   let userId = 0;
 return (
<div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAPRO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAPRO} onChange={(value)=> this.setState({CLAPRO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLARMUE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLARMUE} onChange={(value)=> this.setState({CLARMUE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_REP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_REP} onChange={(value)=> this.setState({FEC_REP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_CAP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_CAP} onChange={(value)=> this.setState({FEC_CAP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_IMP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_IMP} onChange={(value)=> this.setState({FEC_IMP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_VAL </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_VAL} onChange={(value)=> this.setState({FEC_VAL:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">VALIDADO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.VALIDADO} onChange={(value)=> this.setState({VALIDADO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLACAU </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLACAU} onChange={(value)=> this.setState({CLACAU:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SUPLEMENTO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.SUPLEMENTO} onChange={(value)=> this.setState({SUPLEMENTO:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendUpdate()}>Update</button>  
</div>
); }
sendUpdate(){
let userId = this.props.match.params.tblcalidad5id;
const baseUrl = "http://localhost:3000/Rtblcalidad5/Update/"+ userId
const datapost = {
CLAPRO: this.state.CLAPRO,
CLARMUE: this.state.CLARMUE,
FEC_REP: this.state.FEC_REP,
FEC_CAP: this.state.FEC_CAP,
FEC_IMP: this.state.FEC_IMP,
FEC_VAL: this.state.FEC_VAL,
VALIDADO: this.state.VALIDADO,
CLACAU: this.state.CLACAU,
SUPLEMENTO: this.state.SUPLEMENTO
}
axios.post(baseUrl,datapost)
.then(response=>{
if (response.data.success===true) {
alert(response.data.message)
}
else {
alert(response.data.message)
alert(JSON.stringify(response))
}
}).catch(error=>{
alert("Error 34 "+error)
})
}
}
export default EditComponent;
