import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { Link } from "react-router-dom";
import axios from 'axios';
const url= 'http://localhost:3000/Rtblpermisos/list';
class listComponent extends React.Component  {
constructor(props){
super(props);
this.state ={
listtblpermisos:[]
}
}
componentDidMount(){
axios.get(url)
.then(res=>{
if(res.data.sucess){
const data = res.data.data
this.setState({listtblpermisos:data})
}
else{
alert("Error web service")
}
})
.catch(error=>{
alert("Error Server"+error)
})
}
render()
{
    return (
      <table class="table table-hover table-striped">

        <thead class="thead-dark">

<tr>
<th scope = "col" >#</th>
<th scope ="col" >IDTBLPERMISOS</th>
<th scope ="col" >accion</th>
<th colspan="2" >Acciones</th>
</tr>
        </thead>
<tbody>
        {this.loadFilData()}
        </tbody>
      </table>
    );
  }
loadFilData(){
return this.state.listtblpermisos.map((data)=>{
return(
  <tr>
  <th>{data.idtblpermisos}</th>

<td>{data.IDTBLPERMISOS}</td>
<td>{data.accion}</td>
<td>
<Link class="btn btn-outline-info "  to={"/tblpermisosEdit/"+data.idtblpermisos} >Edit</Link>
</td>
<td>
  <button class="btn btn-outline-danger "> Delete </button>
</td>
</tr>
)
}
)
}
}
export default listComponent;
