const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tbltipomuestra_tmues')
var nametable = 'tbltipomuestra_tmues';
var tbltipomuestra_tmues = sequelize.define(nametable,{
idtbltipomuestra_tmues:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


CLAMUE:  Sequelize.DECIMAL,
T_MUES:  Sequelize.STRING,
GRUPO:  Sequelize.INTEGER,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tbltipomuestra_tmues;
