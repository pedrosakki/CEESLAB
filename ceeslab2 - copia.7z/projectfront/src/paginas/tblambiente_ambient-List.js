import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { Link } from "react-router-dom";
import axios from 'axios';
const url= 'http://localhost:3000/Rtblambiente_ambient/list';
class listComponent extends React.Component  {
constructor(props){
super(props);
this.state ={
listtblambiente_ambient:[]
}
}
componentDidMount(){
axios.get(url)
.then(res=>{
if(res.data.sucess){
const data = res.data.data
this.setState({listtblambiente_ambient:data})
}
else{
alert("Error web service")
}
})
.catch(error=>{
alert("Error Server"+error)
})
}
render()
{
    return (
      <table class="table table-hover table-striped">

        <thead class="thead-dark">

<tr>
<th scope = "col" >#</th>
<th scope ="col" >MUESTRA</th>
<th scope ="col" >CLAPRO</th>
<th scope ="col" >CLAMUE</th>
<th scope ="col" >AMPLIAR_TM</th>
<th scope ="col" >DOCTO</th>
<th scope ="col" >NUM_DOC</th>
<th scope ="col" >MARCA</th>
<th scope ="col" >PRESEN</th>
<th scope ="col" >LOTE</th>
<th scope ="col" >CADUCIDAD</th>
<th scope ="col" >FEC_MUES</th>
<th scope ="col" >HOR_MUES</th>
<th scope ="col" >TEM_MOT</th>
<th scope ="col" >MOT_MUES</th>
<th scope ="col" >PUNT_MUES</th>
<th scope ="col" >FEC_ENS1</th>
<th scope ="col" >FEC_ENS2</th>
<th scope ="col" >FEC_ENS3</th>
<th scope ="col" >FEC_ENS4</th>
<th scope ="col" >FEC_ENS5</th>
<th scope ="col" >FEC_ENS6</th>
<th scope ="col" >FEC_DES</th>
<th scope ="col" >NOM_GIRO</th>
<th scope ="col" >RFC</th>
<th scope ="col" >DOMICILIO</th>
<th scope ="col" >COLONIA</th>
<th scope ="col" >LOCALIDAD</th>
<th scope ="col" >CP</th>
<th scope ="col" >CLAEDO</th>
<th scope ="col" >CLAMUN</th>
<th scope ="col" >OBSERV</th>
<th scope ="col" >MA_UFCGM</th>
<th scope ="col" >MA_UFC</th>
<th scope ="col" >OCT_UFCGM</th>
<th scope ="col" >OCT_UFC</th>
<th scope ="col" >OCT_UFC100</th>
<th scope ="col" >OCT_NMPGM</th>
<th scope ="col" >OCT_NMP100</th>
<th scope ="col" >OFC_NMPGM</th>
<th scope ="col" >OCF_NMP100</th>
<th scope ="col" >SALMO25GM</th>
<th scope ="col" >SALMO30G</th>
<th scope ="col" >SALMO100ML</th>
<th scope ="col" >S_AREUS</th>
<th scope ="col" >LEVADURAS</th>
<th scope ="col" >HONGOS</th>
<th scope ="col" >ECOLINMPGM</th>
<th scope ="col" >ECOLI100ML</th>
<th scope ="col" >INHIBIDORE</th>
<th scope ="col" >VCO1</th>
<th scope ="col" >VCONOO1</th>
<th scope ="col" >VP_NMP</th>
<th scope ="col" >ENTEROCOCO</th>
<th scope ="col" >E_ESTAFILO</th>
<th scope ="col" >SALMO1000</th>
<th scope ="col" >SALMO_EN_C</th>
<th scope ="col" >SALMO_EN_R</th>
<th scope ="col" >HUMEDAD</th>
<th scope ="col" >FOSFATSA</th>
<th scope ="col" >NUTRITOS</th>
<th scope ="col" >FECULA</th>
<th scope ="col" >DERCLOCUAL</th>
<th scope ="col" >OXIDANTES</th>
<th scope ="col" >SALESCUATE</th>
<th scope ="col" >FLUOR</th>
<th scope ="col" >YODO</th>
<th scope ="col" >YODATO_K</th>
<th scope ="col" >M_EXTRANA</th>
<th scope ="col" >PH</th>
<th scope ="col" >OLOR</th>
<th scope ="col" >UNI_COLOR</th>
<th scope ="col" >SDT</th>
<th scope ="col" >CLORUROS</th>
<th scope ="col" >SULFATOS</th>
<th scope ="col" >DUREZA_TOT</th>
<th scope ="col" >FLUORUROS</th>
<th scope ="col" >CRL_SEMICU</th>
<th scope ="col" >CRL_CUANTI</th>
<th scope ="col" >CLENBUTERO</th>
<th scope ="col" >AC_FOLICO</th>
<th scope ="col" >DET_MIC</th>
<th scope ="col" >DET_FIS</th>
<th scope ="col" >FN_MI</th>
<th scope ="col" >FN_FI</th>
<th scope ="col" >DE_FN_MI</th>
<th scope ="col" >DEF_FN_FI</th>
<th scope ="col" >FN1</th>
<th scope ="col" >FN2</th>
<th scope ="col" >FN3</th>
<th scope ="col" >FN4</th>
<th scope ="col" >FN5</th>
<th scope ="col" >FN6</th>
<th scope ="col" >FN7</th>
<th scope ="col" >FN8</th>
<th scope ="col" >FN9</th>
<th scope ="col" >FN10</th>
<th scope ="col" >FN11</th>
<th scope ="col" >FN12</th>
<th scope ="col" >FN13</th>
<th scope ="col" >FN14</th>
<th scope ="col" >FN15</th>
<th scope ="col" >FN16</th>
<th scope ="col" >FN17</th>
<th scope ="col" >FN18</th>
<th scope ="col" >FN19</th>
<th scope ="col" >FN20</th>
<th scope ="col" >FN21</th>
<th scope ="col" >FN22</th>
<th scope ="col" >FN23</th>
<th scope ="col" >FN24</th>
<th scope ="col" >FN25</th>
<th scope ="col" >FN26</th>
<th scope ="col" >FN27</th>
<th scope ="col" >FN28</th>
<th scope ="col" >FN29</th>
<th scope ="col" >FN30</th>
<th scope ="col" >FN31</th>
<th scope ="col" >FN32</th>
<th scope ="col" >FN33</th>
<th scope ="col" >FN34</th>
<th scope ="col" >FN35</th>
<th scope ="col" >FN36</th>
<th scope ="col" >FN37</th>
<th scope ="col" >FN38</th>
<th scope ="col" >FN39</th>
<th scope ="col" >FN40</th>
<th scope ="col" >FN41</th>
<th scope ="col" >FN42</th>
<th scope ="col" >FN43</th>
<th scope ="col" >FN44</th>
<th scope ="col" >FN45</th>
<th scope ="col" >FN46</th>
<th scope ="col" >FN47</th>
<th scope ="col" >FN48</th>
<th scope ="col" >FN49</th>
<th scope ="col" >FN50</th>
<th scope ="col" >FN51</th>
<th scope ="col" >FN52</th>
<th scope ="col" >FN53</th>
<th scope ="col" >FN54</th>
<th scope ="col" >FN55</th>
<th scope ="col" >FN56</th>
<th scope ="col" >FN57</th>
<th scope ="col" >FN73</th>
<th scope ="col" >FN74</th>
<th scope ="col" >FN76</th>
<th scope ="col" >FN77</th>
<th scope ="col" >FN78</th>
<th scope ="col" >FN79</th>
<th scope ="col" >FN80</th>
<th scope ="col" >FN81</th>
<th scope ="col" >FN82</th>
<th scope ="col" >AG</th>
<th scope ="col" >AL</th>
<th scope ="col" >AS</th>
<th scope ="col" >B</th>
<th scope ="col" >BA</th>
<th scope ="col" >CD</th>
<th scope ="col" >CR</th>
<th scope ="col" >CU</th>
<th scope ="col" >FE</th>
<th scope ="col" >MN</th>
<th scope ="col" >NA</th>
<th scope ="col" >NI</th>
<th scope ="col" >PB</th>
<th scope ="col" >SE</th>
<th scope ="col" >ZN</th>
<th scope ="col" >VIDRIADO</th>
<th scope ="col" >DECO_INT</th>
<th scope ="col" >COLOR</th>
<th scope ="col" >P_ANALIZAD</th>
<th scope ="col" >VOLUMEN_ML</th>
<th scope ="col" >SOL_US</th>
<th scope ="col" >C_CD</th>
<th scope ="col" >C_PB</th>
<th scope ="col" >LIMITES</th>
<th scope ="col" >FN58</th>
<th scope ="col" >FN59</th>
<th scope ="col" >FN60</th>
<th scope ="col" >FN61</th>
<th scope ="col" >FN62</th>
<th scope ="col" >FN63</th>
<th scope ="col" >FN64</th>
<th scope ="col" >FN65</th>
<th scope ="col" >FN66</th>
<th scope ="col" >FN67</th>
<th scope ="col" >FN68</th>
<th scope ="col" >FN70</th>
<th scope ="col" >FN71</th>
<th scope ="col" >FN72</th>
<th scope ="col" >FN75</th>
<th scope ="col" >FEC_CAP</th>
<th scope ="col" >FEC_IMP</th>
<th scope ="col" >FEC_VAL</th>
<th scope ="col" >AM</th>
<th scope ="col" >AF</th>
<th scope ="col" >AMP</th>
<th scope ="col" >AT</th>
<th scope ="col" >VALIDADO</th>
<th scope ="col" >CLACAU</th>
<th scope ="col" >SUPLEMENTO</th>
<th scope ="col" >NOTAS</th>
<th colspan="2" >Acciones</th>
</tr>
        </thead>
<tbody>
        {this.loadFilData()}
        </tbody>
      </table>
    );
  }
loadFilData(){
return this.state.listtblambiente_ambient.map((data)=>{
return(
  <tr>
  <th>{data.idtblambiente_ambient}</th>

<td>{data.MUESTRA}</td>
<td>{data.CLAPRO}</td>
<td>{data.CLAMUE}</td>
<td>{data.AMPLIAR_TM}</td>
<td>{data.DOCTO}</td>
<td>{data.NUM_DOC}</td>
<td>{data.MARCA}</td>
<td>{data.PRESEN}</td>
<td>{data.LOTE}</td>
<td>{data.CADUCIDAD}</td>
<td>{data.FEC_MUES}</td>
<td>{data.HOR_MUES}</td>
<td>{data.TEM_MOT}</td>
<td>{data.MOT_MUES}</td>
<td>{data.PUNT_MUES}</td>
<td>{data.FEC_ENS1}</td>
<td>{data.FEC_ENS2}</td>
<td>{data.FEC_ENS3}</td>
<td>{data.FEC_ENS4}</td>
<td>{data.FEC_ENS5}</td>
<td>{data.FEC_ENS6}</td>
<td>{data.FEC_DES}</td>
<td>{data.NOM_GIRO}</td>
<td>{data.RFC}</td>
<td>{data.DOMICILIO}</td>
<td>{data.COLONIA}</td>
<td>{data.LOCALIDAD}</td>
<td>{data.CP}</td>
<td>{data.CLAEDO}</td>
<td>{data.CLAMUN}</td>
<td>{data.OBSERV}</td>
<td>{data.MA_UFCGM}</td>
<td>{data.MA_UFC}</td>
<td>{data.OCT_UFCGM}</td>
<td>{data.OCT_UFC}</td>
<td>{data.OCT_UFC100}</td>
<td>{data.OCT_NMPGM}</td>
<td>{data.OCT_NMP100}</td>
<td>{data.OFC_NMPGM}</td>
<td>{data.OCF_NMP100}</td>
<td>{data.SALMO25GM}</td>
<td>{data.SALMO30G}</td>
<td>{data.SALMO100ML}</td>
<td>{data.S_AREUS}</td>
<td>{data.LEVADURAS}</td>
<td>{data.HONGOS}</td>
<td>{data.ECOLINMPGM}</td>
<td>{data.ECOLI100ML}</td>
<td>{data.INHIBIDORE}</td>
<td>{data.VCO1}</td>
<td>{data.VCONOO1}</td>
<td>{data.VP_NMP}</td>
<td>{data.ENTEROCOCO}</td>
<td>{data.E_ESTAFILO}</td>
<td>{data.SALMO1000}</td>
<td>{data.SALMO_EN_C}</td>
<td>{data.SALMO_EN_R}</td>
<td>{data.HUMEDAD}</td>
<td>{data.FOSFATSA}</td>
<td>{data.NUTRITOS}</td>
<td>{data.FECULA}</td>
<td>{data.DERCLOCUAL}</td>
<td>{data.OXIDANTES}</td>
<td>{data.SALESCUATE}</td>
<td>{data.FLUOR}</td>
<td>{data.YODO}</td>
<td>{data.YODATO_K}</td>
<td>{data.M_EXTRANA}</td>
<td>{data.PH}</td>
<td>{data.OLOR}</td>
<td>{data.UNI_COLOR}</td>
<td>{data.SDT}</td>
<td>{data.CLORUROS}</td>
<td>{data.SULFATOS}</td>
<td>{data.DUREZA_TOT}</td>
<td>{data.FLUORUROS}</td>
<td>{data.CRL_SEMICU}</td>
<td>{data.CRL_CUANTI}</td>
<td>{data.CLENBUTERO}</td>
<td>{data.AC_FOLICO}</td>
<td>{data.DET_MIC}</td>
<td>{data.DET_FIS}</td>
<td>{data.FN_MI}</td>
<td>{data.FN_FI}</td>
<td>{data.DE_FN_MI}</td>
<td>{data.DEF_FN_FI}</td>
<td>{data.FN1}</td>
<td>{data.FN2}</td>
<td>{data.FN3}</td>
<td>{data.FN4}</td>
<td>{data.FN5}</td>
<td>{data.FN6}</td>
<td>{data.FN7}</td>
<td>{data.FN8}</td>
<td>{data.FN9}</td>
<td>{data.FN10}</td>
<td>{data.FN11}</td>
<td>{data.FN12}</td>
<td>{data.FN13}</td>
<td>{data.FN14}</td>
<td>{data.FN15}</td>
<td>{data.FN16}</td>
<td>{data.FN17}</td>
<td>{data.FN18}</td>
<td>{data.FN19}</td>
<td>{data.FN20}</td>
<td>{data.FN21}</td>
<td>{data.FN22}</td>
<td>{data.FN23}</td>
<td>{data.FN24}</td>
<td>{data.FN25}</td>
<td>{data.FN26}</td>
<td>{data.FN27}</td>
<td>{data.FN28}</td>
<td>{data.FN29}</td>
<td>{data.FN30}</td>
<td>{data.FN31}</td>
<td>{data.FN32}</td>
<td>{data.FN33}</td>
<td>{data.FN34}</td>
<td>{data.FN35}</td>
<td>{data.FN36}</td>
<td>{data.FN37}</td>
<td>{data.FN38}</td>
<td>{data.FN39}</td>
<td>{data.FN40}</td>
<td>{data.FN41}</td>
<td>{data.FN42}</td>
<td>{data.FN43}</td>
<td>{data.FN44}</td>
<td>{data.FN45}</td>
<td>{data.FN46}</td>
<td>{data.FN47}</td>
<td>{data.FN48}</td>
<td>{data.FN49}</td>
<td>{data.FN50}</td>
<td>{data.FN51}</td>
<td>{data.FN52}</td>
<td>{data.FN53}</td>
<td>{data.FN54}</td>
<td>{data.FN55}</td>
<td>{data.FN56}</td>
<td>{data.FN57}</td>
<td>{data.FN73}</td>
<td>{data.FN74}</td>
<td>{data.FN76}</td>
<td>{data.FN77}</td>
<td>{data.FN78}</td>
<td>{data.FN79}</td>
<td>{data.FN80}</td>
<td>{data.FN81}</td>
<td>{data.FN82}</td>
<td>{data.AG}</td>
<td>{data.AL}</td>
<td>{data.AS}</td>
<td>{data.B}</td>
<td>{data.BA}</td>
<td>{data.CD}</td>
<td>{data.CR}</td>
<td>{data.CU}</td>
<td>{data.FE}</td>
<td>{data.MN}</td>
<td>{data.NA}</td>
<td>{data.NI}</td>
<td>{data.PB}</td>
<td>{data.SE}</td>
<td>{data.ZN}</td>
<td>{data.VIDRIADO}</td>
<td>{data.DECO_INT}</td>
<td>{data.COLOR}</td>
<td>{data.P_ANALIZAD}</td>
<td>{data.VOLUMEN_ML}</td>
<td>{data.SOL_US}</td>
<td>{data.C_CD}</td>
<td>{data.C_PB}</td>
<td>{data.LIMITES}</td>
<td>{data.FN58}</td>
<td>{data.FN59}</td>
<td>{data.FN60}</td>
<td>{data.FN61}</td>
<td>{data.FN62}</td>
<td>{data.FN63}</td>
<td>{data.FN64}</td>
<td>{data.FN65}</td>
<td>{data.FN66}</td>
<td>{data.FN67}</td>
<td>{data.FN68}</td>
<td>{data.FN70}</td>
<td>{data.FN71}</td>
<td>{data.FN72}</td>
<td>{data.FN75}</td>
<td>{data.FEC_CAP}</td>
<td>{data.FEC_IMP}</td>
<td>{data.FEC_VAL}</td>
<td>{data.AM}</td>
<td>{data.AF}</td>
<td>{data.AMP}</td>
<td>{data.AT}</td>
<td>{data.VALIDADO}</td>
<td>{data.CLACAU}</td>
<td>{data.SUPLEMENTO}</td>
<td>{data.NOTAS}</td>
<td>
<Link class="btn btn-outline-info "  to={"/tblambiente_ambientEdit/"+data.idtblambiente_ambient} >Edit</Link>
</td>
<td>
  <button class="btn btn-outline-danger "> Delete </button>
</td>
</tr>
)
}
)
}
}
export default listComponent;
