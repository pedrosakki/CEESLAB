import React from 'react';import 'bootstrap/dist/css/bootstrap.min.css';import 'bootstrap/dist/js/bootstrap.bundle.min';import axios from 'axios'const baseUrl= "http: //localhost:3000"class EditComponent extends React.Component{
constructor(props){
super(props);this.state={edittblcalidad1s:[],datatblcalidad1:{},MUESTRA: MUESTRA,
CLAPRO: CLAPRO,
CLAMUE: CLAMUE,
E1: E1,
EXAM1: EXAM1,
FEC_RESP: FEC_RESP,
MES: MES,
LABORATORIO: LABORATORIO,
OBSERVA: OBSERVA,
FN_1: FN_1,
FN_2: FN_2,
NEW: NEW,
HEMOLI: HEMOLI,
LIPEMI: LIPEMI,
CONTAM: CONTAM,
INSUFI: INSUFI,
ADECUA: ADECUA,
TOT_SUE: TOT_SUE,
FEC_CAP: FEC_CAP,
FEC_IMP: FEC_IMP,
FEC_VAL: FEC_VAL,
VALIDADO: VALIDADO,
CLACAU: CLACAU
SUPLEMENTO: SUPLEMENTO
}}componentDidMount(){let userId = this.props.match.params.tblcalidad1id;  const url = baseUrl+"/Rtblcalidad1/get/"+userId  axios.get(url) .then(res=>{  if(res.data.sucess){  const data = res.data.data[0] this.setState({edittblcalidad1s:data,MUESTRA: MUESTRA,
CLAPRO: CLAPRO,
CLAMUE: CLAMUE,
E1: E1,
EXAM1: EXAM1,
FEC_RESP: FEC_RESP,
MES: MES,
LABORATORIO: LABORATORIO,
OBSERVA: OBSERVA,
FN_1: FN_1,
FN_2: FN_2,
NEW: NEW,
HEMOLI: HEMOLI,
LIPEMI: LIPEMI,
CONTAM: CONTAM,
INSUFI: INSUFI,
ADECUA: ADECUA,
TOT_SUE: TOT_SUE,
FEC_CAP: FEC_CAP,
FEC_IMP: FEC_IMP,
FEC_VAL: FEC_VAL,
VALIDADO: VALIDADO,
CLACAU: CLACAU
SUPLEMENTO: SUPLEMENTO
} ) }else{alert("Error web service")} } )  .catch(error=>{  })}  render(){   let userId = 0; return (<div class="form-row justify-content-center"><div class="form-group col-md-6">
<label for="inputApellidoPaterno">MUESTRA </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.MUESTRA} onChange={(value)=> this.setState({MUESTRA:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAPRO </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAPRO} onChange={(value)=> this.setState({CLAPRO:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAMUE </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAMUE} onChange={(value)=> this.setState({CLAMUE:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">E1 </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E1} onChange={(value)=> this.setState({E1:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM1 </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM1} onChange={(value)=> this.setState({EXAM1:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_RESP </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_RESP} onChange={(value)=> this.setState({FEC_RESP:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">MES </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.MES} onChange={(value)=> this.setState({MES:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">LABORATORIO </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.LABORATORIO} onChange={(value)=> this.setState({LABORATORIO:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">OBSERVA </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.OBSERVA} onChange={(value)=> this.setState({OBSERVA:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN_1 </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FN_1} onChange={(value)=> this.setState({FN_1:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN_2 </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FN_2} onChange={(value)=> this.setState({FN_2:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">NEW </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.NEW} onChange={(value)=> this.setState({NEW:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">HEMOLI </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.HEMOLI} onChange={(value)=> this.setState({HEMOLI:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">LIPEMI </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.LIPEMI} onChange={(value)=> this.setState({LIPEMI:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">CONTAM </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CONTAM} onChange={(value)=> this.setState({CONTAM:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">INSUFI </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.INSUFI} onChange={(value)=> this.setState({INSUFI:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">ADECUA </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ADECUA} onChange={(value)=> this.setState({ADECUA:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">TOT_SUE </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.TOT_SUE} onChange={(value)=> this.setState({TOT_SUE:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_CAP </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_CAP} onChange={(value)=> this.setState({FEC_CAP:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_IMP </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_IMP} onChange={(value)=> this.setState({FEC_IMP:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_VAL </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_VAL} onChange={(value)=> this.setState({FEC_VAL:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">VALIDADO </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.VALIDADO} onChange={(value)=> this.setState({VALIDADO:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLACAU </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLACAU} onChange={(value)=> this.setState({CLACAU:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">SUPLEMENTO </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.SUPLEMENTO} onChange={(value)=> this.setState({SUPLEMENTO:value.target.value})}/></div><button type="submit" class="btn btn-primary" onClick={()=>this.sendUpdate()}>Update</button>  </div>); }sendUpdate(){let userId = this.props.match.params.tblcalidad1id;const baseUrl = "http://localhost:3000/Rtblcalidad1/update/"+userIdconst datapost = {MUESTRA: tjos-state. MUESTRA,
CLAPRO: tjos-state. CLAPRO,
CLAMUE: tjos-state. CLAMUE,
E1: tjos-state. E1,
EXAM1: tjos-state. EXAM1,
FEC_RESP: tjos-state. FEC_RESP,
MES: tjos-state. MES,
LABORATORIO: tjos-state. LABORATORIO,
OBSERVA: tjos-state. OBSERVA,
FN_1: tjos-state. FN_1,
FN_2: tjos-state. FN_2,
NEW: tjos-state. NEW,
HEMOLI: tjos-state. HEMOLI,
LIPEMI: tjos-state. LIPEMI,
CONTAM: tjos-state. CONTAM,
INSUFI: tjos-state. INSUFI,
ADECUA: tjos-state. ADECUA,
TOT_SUE: tjos-state. TOT_SUE,
FEC_CAP: tjos-state. FEC_CAP,
FEC_IMP: tjos-state. FEC_IMP,
FEC_VAL: tjos-state. FEC_VAL,
VALIDADO: tjos-state. VALIDADO,
CLACAU: tjos-state. CLACAU
SUPLEMENTO: tjos-state. SUPLEMENTO
}axios.post(baseUrl,datapost).then(response=>{if (response.data.success===true) {alert(response.data.message)}else {alert(response.data.message)alert(JSON.stringify(response))}}).catch(error=>{alert("Error 34 "+error)})}}export default EditComponent;