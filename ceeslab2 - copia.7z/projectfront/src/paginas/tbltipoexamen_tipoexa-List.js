import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { Link } from "react-router-dom";
import axios from 'axios';
const url= 'http://localhost:3000/Rtbltipoexamen_tipoexa/list';
class listComponent extends React.Component  {
constructor(props){
super(props);
this.state ={
listtbltipoexamen_tipoexa:[]
}
}
componentDidMount(){
axios.get(url)
.then(res=>{
if(res.data.sucess){
const data = res.data.data
this.setState({listtbltipoexamen_tipoexa:data})
}
else{
alert("Error web service")
}
})
.catch(error=>{
alert("Error Server"+error)
})
}
render()
{
    return (
      <table class="table table-hover table-striped">

        <thead class="thead-dark">

<tr>
<th scope = "col" >#</th>
<th scope ="col" >CLAEXA</th>
<th scope ="col" >EXAMEN</th>
<th scope ="col" >UNIDAD</th>
<th scope ="col" >METODO</th>
<th scope ="col" >TECNICA</th>
<th scope ="col" >REFERENCIA</th>
<th scope ="col" >GRUPO</th>
<th colspan="2" >Acciones</th>
</tr>
        </thead>
<tbody>
        {this.loadFilData()}
        </tbody>
      </table>
    );
  }
loadFilData(){
return this.state.listtbltipoexamen_tipoexa.map((data)=>{
return(
  <tr>
  <th>{data.idtbltipoexamen_tipoexa}</th>

<td>{data.CLAEXA}</td>
<td>{data.EXAMEN}</td>
<td>{data.UNIDAD}</td>
<td>{data.METODO}</td>
<td>{data.TECNICA}</td>
<td>{data.REFERENCIA}</td>
<td>{data.GRUPO}</td>
<td>
<Link class="btn btn-outline-info "  to={"/tbltipoexamen_tipoexaEdit/"+data.idtbltipoexamen_tipoexa} >Edit</Link>
</td>
<td>
  <button class="btn btn-outline-danger "> Delete </button>
</td>
</tr>
)
}
)
}
}
export default listComponent;
