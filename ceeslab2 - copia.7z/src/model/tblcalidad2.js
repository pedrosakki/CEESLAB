const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tblcalidad2')
var nametable = 'tblcalidad2';
var tblcalidad2 = sequelize.define(nametable,{
idtblcalidad2:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


IDTBLCALIDAD2:  Sequelize.STRING,
MUESTRA:  Sequelize.STRING,
CLAPRO:  Sequelize.STRING,
CLAMUE:  Sequelize.STRING,
OFICIO:  Sequelize.STRING,
FEC_REP:  Sequelize.STRING,
TIPO:  Sequelize.STRING,
MES:  Sequelize.STRING,
LABORATORIO:  Sequelize.STRING,
REV_DIAG:  Sequelize.INTEGER,
DIAG_0:  Sequelize.INTEGER,
REV_CONT:  Sequelize.INTEGER,
CONT_0:  Sequelize.INTEGER,
DIAG_1:  Sequelize.INTEGER,
EXT_CONT:  Sequelize.INTEGER,
CONT_1:  Sequelize.INTEGER,
TINC_DIAG:  Sequelize.INTEGER,
DIAG_2:  Sequelize.INTEGER,
TINC_CONT:  Sequelize.INTEGER,
CONT_2:  Sequelize.INTEGER,
POS_DIAG:  Sequelize.INTEGER,
DIAG_3:  Sequelize.INTEGER,
NEG_DIAG:  Sequelize.INTEGER,
DIAG_4:  Sequelize.INTEGER,
NEG_CONT:  Sequelize.INTEGER,
CONT_4:  Sequelize.INTEGER,
EXT_ADE:  Sequelize.INTEGER,
EXT_INA:  Sequelize.INTEGER,
TIN_ADE:  Sequelize.INTEGER,
TIN_INA:  Sequelize.INTEGER,
TOT_BAC:  Sequelize.STRING,
OBSERVA:  Sequelize.STRING,
FEC_VAL:  Sequelize.DATE,
FEC_CAP:  Sequelize.DATE,
FEC_IMP:  Sequelize.DATE,
VALIDADO:  Sequelize.INTEGER,
CLACAU:  Sequelize.INTEGER,
SUPLEMENTO:  Sequelize.INTEGER,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tblcalidad2;
