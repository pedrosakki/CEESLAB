//const usersRouter = express.Router()
//const cors = require('cors')
const jwt = require('jsonwebtoken')
const bcrypt = require('bcryptjs')
//usersRouter.use(cors())

const controllers = {}
var sequelize = require('../model/database');
var tblusuario_usuarios = require('../model/tblusuario_usuarios');

process.env.SECRET_KEY = 'labceeslab2o!9'

//METODO GET//
controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tblusuario_usuarios.findAll({
where: {idtblusuario_usuarios: id }  })
.then(function(data){
    return data;})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}
//METODO LIST//
controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tblusuario_usuarios.findAll();
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}

//METODO CREATE//
controllers.create = async (req, res)=>{
const  {USUARIO,PASSWORD,ACCESO,SECCION,TIPO,NIVEL,SESION,CODIGO,NOMBRE}=req.body;
const data = await tblusuario_usuarios.create({
USUARIO: USUARIO,
PASSWORD: PASSWORD,
ACCESO: ACCESO,
SECCION: SECCION,
TIPO: TIPO,
NIVEL: NIVEL,
SESION: SESION,
CODIGO: CODIGO,
NOMBRE: NOMBRE
}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data
})
}

//METODO UPDATE//
controllers.update = async (req, res)=>{
  const { id } = req.params;
const  {USUARIO,PASSWORD,ACCESO,SECCION,TIPO,NIVEL,SESION,CODIGO,NOMBRE}=req.body;

 const data = await tblusuario_usuarios.update({
USUARIO: USUARIO,
PASSWORD: PASSWORD,
ACCESO: ACCESO,
SECCION: SECCION,
TIPO: TIPO,
NIVEL: NIVEL,
SESION: SESION,
CODIGO: CODIGO,
NOMBRE: NOMBRE
   },{
          where: { idtblusuario_usuarios: id}
     })
  .then( function(data){
    return data;
      })
       .catch(error => {
        return error;
   }) 
   res.json({success:true, data:data, message:"Updated successful"});
 }

 //METODO DE LOGIN
 controllers.LogAccess = async (req, res)=>{
  tblusuario_usuarios.findOne({
    where: {
      IDTBLUSUARIO: req.body.id,
      PASSWORD:req.body.password,
      activo:1
    }
  })
    .then(user => {
      if (user) {
      //  if (req.body.password===user.PASSWORD) {
         console.log(user.dataValues)
          let token = jwt.sign(user.dataValues, process.env.SECRET_KEY, {expiresIn: 1440 })
         res.send(token)      
         
      //  }
        
      } else {
       // alert('error: Usuario no existe....(UsersController)')
        res.status(400).json({ error: 'Usuario no existe....(UsersController)' })
      }
    })
    .catch(err => {
      res.status(400).json({ error: err })
    })
}

 

 module.exports = controllers;
