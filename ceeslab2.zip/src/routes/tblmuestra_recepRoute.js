const express = require('express');
const router = express.Router();
const tblmuestra_recepController = require('../Controllers/tblmuestra_recepController')


router.post('/update/:id',tblmuestra_recepController.update)
router.get('/get/:id', tblmuestra_recepController.get)
router.get('/list', tblmuestra_recepController.list);
router.post('/create', tblmuestra_recepController.create);
router.get('/ultima', tblmuestra_recepController.ultima)

module.exports = router;
