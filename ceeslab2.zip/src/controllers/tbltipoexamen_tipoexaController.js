 const controllers = {}
var sequelize = require('../model/database');
var tbltipoexamen_tipoexa = require('../model/tbltipoexamen_tipoexa');
//
//METODO GET//

controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tbltipoexamen_tipoexa.findAll({
where: {idtbltipoexamen_tipoexa: id }  })
.then(function(data){
    return data;})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}


//TIPOS DE EXAMEN
controllers.examen = async(req,res)=>{
  const {id}= req.params;
  const data = await tbltipoexamen_tipoexa.findAll({
  where: {CLAEXA: id }  })
  .then(function(data){
      return data;})
  .catch(error =>{
  return error;})
  res.json({sucess:true,data})
  }

  //TIPOS DE EXAMEN COMPLEMENTARIOS
controllers.complemento = async(req,res)=>{
  const Op = sequelize.Op
  const {id}= req.params  
  //console.log(id)
  //console.log("aqui")
  var arr = id.split(",");  
  //console.log(arr)
  const data = await tbltipoexamen_tipoexa.findAll({
  where: {COMPLEMENTO: arr}     
   })
  .then(function(data){
      return data;})
  .catch(error =>{
  return error;})
  res.json({sucess:true,data})
  }

 

//METODO LIST//
controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tbltipoexamen_tipoexa.findAll();
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}



//METODO CREATE//
controllers.create = async (req, res)=>{
const  {CLAEXA,EXAMEN,UNIDAD,METODO,TECNICA,REFERENCIA,GRUPO}=req.body;
const data = await tbltipoexamen_tipoexa.create({
CLAEXA: CLAEXA,
EXAMEN: EXAMEN,
UNIDAD: UNIDAD,
METODO: METODO,
TECNICA: TECNICA,
REFERENCIA: REFERENCIA,
GRUPO: GRUPO,
COMPLEMENTO:COMPLEMENTO
}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data
})
}


//METODO UPDATE//
controllers.update = async (req, res)=>{
  const { id } = req.params;
const  {CLAEXA,EXAMEN,UNIDAD,METODO,TECNICA,REFERENCIA,GRUPO}=req.body;

 const data = await tbltipoexamen_tipoexa.update({
CLAEXA: CLAEXA,
EXAMEN: EXAMEN,
UNIDAD: UNIDAD,
METODO: METODO,
TECNICA: TECNICA,
REFERENCIA: REFERENCIA,
GRUPO: GRUPO,
COMPLEMENTO:COMPLEMENTO
   },{
          where: { idtbltipoexamen_tipoexa: id}
     })
  .then( function(data){
    return data;
      })
       .catch(error => {
        return error;
   }) 
   res.json({success:true, data:data, message:"Updated successful"});
 }



 module.exports = controllers;
