import React, { Component } from 'react'
import clsx from 'clsx';
import { makeStyles,createStyles,Theme } from '@material-ui/core/styles';
//import Button from '@material-ui/core/Button';
//import Icon from '@material-ui/core/Icon';
import DoubleArrowOutlinedIcon from '@material-ui/icons/DoubleArrowOutlined';
//import { login } from './UserFunctions'
import Imagen from '../nuevo.png'
import Avatar from '@material-ui/core/Avatar';
//import RaisedButton from '@material-ui/core/RaisedButton';
import TextField from '@material-ui/core/TextField';
//import { Button, Icon } from 'semantic-ui-react'
//import ButtonN from './ButtonN'
//import Mensaje from './Mensaje'
import Recep2 from './Recep2'
import { Button,Container, Header, List,Icon } from "semantic-ui-react";
import axios from 'axios';
import Mensaje from './Mensaje'
const baseUrl ="http://localhost:3000"

class Login extends Component {
  constructor() {
    super()
    this.state = {
      id:'',
      email: '',
      password: '',
      foto:'',
      errors: {}

    }

    this.onChange = this.onChange.bind(this)
    this.onSubmit = this.onSubmit.bind(this)
  }

  onChange(e) {
    this.setState({ [e.target.name]: e.target.value })
  }

onSubmit(e) {
  e.preventDefault()
  const url = baseUrl +"/Rtblusuario_usuarios/LogAccess"
  const user = {
    id: this.state.id,
    password: this.state.password
  }
   axios
      .post(url, user)
      .then(response => {
        //console.log(response);
        if (response) {       //evaluar el rol para distribuir
          // console.log('1 de login');
          // console.log('Response data....'+response.data);
               //this.setState({foto:user.providerData[0].photoURL });
               //  <Avatar src={this.state.foto}/>            <Avatar src={Imagen}/>
            localStorage.setItem('usertoken', response.data)
            this.props.history.push(`/tblmuestra_recepAlta`)        
          }else {
             // alert('El usuario no existe');
              this.props.history.push(`/Login`)               
              } 
      // alert(response.data)
        return response.data
      })
      .catch(err => {
        console.log(err)
      })
}
   
 
render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-md-4 mt-5 mx-auto">
            <form noValidate onSubmit={this.onSubmit}>         
              <div className="card border-primary">
                <div className="card-header  bg-transparent ">
                        <img src={Imagen} width="210" height="150" className="portada centrado" alt="Imagen" />
                </div>
                <div className="card-body ">
                              <div className="form-group">
                              <label htmlFor="text" text-align="left">Código</label>
                              <input
                                type="text"
                                className="form-control"
                                name="id"
                                placeholder="Ingrese su codigo"
                                value={this.state.id}
                                onChange={this.onChange}
                              />  
                              </div>
                              <div className="form-group">
                                <label htmlFor="password">Password</label>
                                <input
                                  type="password"
                                  className="form-control"
                                  name="password"
                                  placeholder="Password"
                                  value={this.state.password}
                                  onChange={this.onChange}
                                />
                              </div >
                </div>
                <div className="card-footer   text-muted  text-center">
              <div className="form-group ">
              <button
                type="submit"
                className="btn  btn-primary btn-block">
                Entrar
              </button>
              </div>
  </div>
              </div>              
            </form>
          </div>
        </div>
      </div>
    )
  }
}

export default Login
