import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios'
const baseUrl= "http: //localhost:3000"
class EditComponent extends React.Component{

constructor(props){

super(props);
this.state={
edittblmicrobiologias:[],
datatblmicrobiologia:{},
MUESTRA: "",
DOCTO: "",
NUM_DOC: "",
CLAPRO: "",
CLAMUE: "",
CONFIRMAR: "",
AFILIACION: "",
PIORIDAD: "",
NOMBES: "",
APELLIDO_P: "",
APELLIDO_M: "",
ANIOS: "",
MESES: "",
SEXO: "",
DOMICILIO: "",
COLONIA: "",
LOCALIDAD: "",
CLAEDO: "",
CLAMUN: "",
FEC_TOM: "",
HOR_TOM: "",
FEC_IEN: "",
CONTACTODE: "",
E1: "",
EXAM1: "",
RES1: "",
RESUL1: "",
FR1: "",
INDRE1: "",
E2: "",
EXAM2: "",
RES2: "",
RESUL2: "",
FR2: "",
INDRE2: "",
E3: "",
EXAM3: "",
RES3: "",
RESUL3: "",
FR3: "",
INDRE3: "",
E4: "",
EXAM4: "",
RES4: "",
RESUL4: "",
FR4: "",
INDRE4: "",
E5: "",
EXAM5: "",
RES5: "",
RESUL5: "",
FR5: "",
INDRE5: "",
E6: "",
EXAM6: "",
RES6: "",
RESUL6: "",
FR6: "",
INDRE6: "",
E7: "",
EXAM7: "",
RES7: "",
RESUL7: "",
FR7: "",
INDRE7: "",
E8: "",
EXAM8: "",
RES8: "",
RESUL8: "",
FR8: "",
INDRE8: "",
E9: "",
EXAM9: "",
RES9: "",
RESUL9: "",
FR9: "",
INDRE9: "",
E10: "",
EXAM10: "",
RES10: "",
RESUL10: "",
FR10: "",
INDRE10: "",
ANTI_1: "",
ANTI_2: "",
ANTI_3: "",
ANTI_4: "",
ANTI_5: "",
ANTI_6: "",
ANTI_7: "",
ANTI_8: "",
ANTI_9: "",
ANTI_9D: "",
BAAR: "",
CULTIVO: "",
SEAISLO: "",
OBSERV: "",
F_LIBRE: "",
CONTROL: "",
DIAG: "",
M_PROCESAD: "",
TIPIFICS: "",
PCR_GX: "",
FEC_CAP: "",
FEC_IMP: "",
FEC_EINDRE: "",
FEC_RINDRE: "",
FEC_VAL: "",
VALIDADO: "",
CLACAU: "",
SUPLEMENTO: "",
NOTAS: ""
}
}


componentDidMount(){
let userId = this.props.match.params.tblmicrobiologiaid;
  const url = baseUrl+"/Rtblmicrobiologia/get/"+userId

  axios.get(url)
 .then(res=>{
  if(res.data.sucess){
  const data = res.data.data[0] 
this.setState({
edittblmicrobiologias:data,
MUESTRA: data.MUESTRA,
DOCTO: data.DOCTO,
NUM_DOC: data.NUM_DOC,
CLAPRO: data.CLAPRO,
CLAMUE: data.CLAMUE,
CONFIRMAR: data.CONFIRMAR,
AFILIACION: data.AFILIACION,
PIORIDAD: data.PIORIDAD,
NOMBES: data.NOMBES,
APELLIDO_P: data.APELLIDO_P,
APELLIDO_M: data.APELLIDO_M,
ANIOS: data.ANIOS,
MESES: data.MESES,
SEXO: data.SEXO,
DOMICILIO: data.DOMICILIO,
COLONIA: data.COLONIA,
LOCALIDAD: data.LOCALIDAD,
CLAEDO: data.CLAEDO,
CLAMUN: data.CLAMUN,
FEC_TOM: data.FEC_TOM,
HOR_TOM: data.HOR_TOM,
FEC_IEN: data.FEC_IEN,
CONTACTODE: data.CONTACTODE,
E1: data.E1,
EXAM1: data.EXAM1,
RES1: data.RES1,
RESUL1: data.RESUL1,
FR1: data.FR1,
INDRE1: data.INDRE1,
E2: data.E2,
EXAM2: data.EXAM2,
RES2: data.RES2,
RESUL2: data.RESUL2,
FR2: data.FR2,
INDRE2: data.INDRE2,
E3: data.E3,
EXAM3: data.EXAM3,
RES3: data.RES3,
RESUL3: data.RESUL3,
FR3: data.FR3,
INDRE3: data.INDRE3,
E4: data.E4,
EXAM4: data.EXAM4,
RES4: data.RES4,
RESUL4: data.RESUL4,
FR4: data.FR4,
INDRE4: data.INDRE4,
E5: data.E5,
EXAM5: data.EXAM5,
RES5: data.RES5,
RESUL5: data.RESUL5,
FR5: data.FR5,
INDRE5: data.INDRE5,
E6: data.E6,
EXAM6: data.EXAM6,
RES6: data.RES6,
RESUL6: data.RESUL6,
FR6: data.FR6,
INDRE6: data.INDRE6,
E7: data.E7,
EXAM7: data.EXAM7,
RES7: data.RES7,
RESUL7: data.RESUL7,
FR7: data.FR7,
INDRE7: data.INDRE7,
E8: data.E8,
EXAM8: data.EXAM8,
RES8: data.RES8,
RESUL8: data.RESUL8,
FR8: data.FR8,
INDRE8: data.INDRE8,
E9: data.E9,
EXAM9: data.EXAM9,
RES9: data.RES9,
RESUL9: data.RESUL9,
FR9: data.FR9,
INDRE9: data.INDRE9,
E10: data.E10,
EXAM10: data.EXAM10,
RES10: data.RES10,
RESUL10: data.RESUL10,
FR10: data.FR10,
INDRE10: data.INDRE10,
ANTI_1: data.ANTI_1,
ANTI_2: data.ANTI_2,
ANTI_3: data.ANTI_3,
ANTI_4: data.ANTI_4,
ANTI_5: data.ANTI_5,
ANTI_6: data.ANTI_6,
ANTI_7: data.ANTI_7,
ANTI_8: data.ANTI_8,
ANTI_9: data.ANTI_9,
ANTI_9D: data.ANTI_9D,
BAAR: data.BAAR,
CULTIVO: data.CULTIVO,
SEAISLO: data.SEAISLO,
OBSERV: data.OBSERV,
F_LIBRE: data.F_LIBRE,
CONTROL: data.CONTROL,
DIAG: data.DIAG,
M_PROCESAD: data.M_PROCESAD,
TIPIFICS: data.TIPIFICS,
PCR_GX: data.PCR_GX,
FEC_CAP: data.FEC_CAP,
FEC_IMP: data.FEC_IMP,
FEC_EINDRE: data.FEC_EINDRE,
FEC_RINDRE: data.FEC_RINDRE,
FEC_VAL: data.FEC_VAL,
VALIDADO: data.VALIDADO,
CLACAU: data.CLACAU,
SUPLEMENTO: data.SUPLEMENTO,
NOTAS: data.NOTAS
} ) }
else{
alert("Error web service")
} } )
  .catch(error=>{
  })
}


  render(){
   let userId = 0;
 return (
<div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MUESTRA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.MUESTRA} onChange={(value)=> this.setState({MUESTRA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DOCTO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DOCTO} onChange={(value)=> this.setState({DOCTO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">NUM_DOC </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.NUM_DOC} onChange={(value)=> this.setState({NUM_DOC:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAPRO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAPRO} onChange={(value)=> this.setState({CLAPRO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAMUE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAMUE} onChange={(value)=> this.setState({CLAMUE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CONFIRMAR </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CONFIRMAR} onChange={(value)=> this.setState({CONFIRMAR:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">AFILIACION </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.AFILIACION} onChange={(value)=> this.setState({AFILIACION:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">PIORIDAD </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.PIORIDAD} onChange={(value)=> this.setState({PIORIDAD:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">NOMBES </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.NOMBES} onChange={(value)=> this.setState({NOMBES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">APELLIDO_P </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.APELLIDO_P} onChange={(value)=> this.setState({APELLIDO_P:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">APELLIDO_M </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.APELLIDO_M} onChange={(value)=> this.setState({APELLIDO_M:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ANIOS </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ANIOS} onChange={(value)=> this.setState({ANIOS:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MESES </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.MESES} onChange={(value)=> this.setState({MESES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SEXO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.SEXO} onChange={(value)=> this.setState({SEXO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DOMICILIO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DOMICILIO} onChange={(value)=> this.setState({DOMICILIO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">COLONIA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.COLONIA} onChange={(value)=> this.setState({COLONIA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">LOCALIDAD </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.LOCALIDAD} onChange={(value)=> this.setState({LOCALIDAD:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAEDO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAEDO} onChange={(value)=> this.setState({CLAEDO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAMUN </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAMUN} onChange={(value)=> this.setState({CLAMUN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_TOM </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_TOM} onChange={(value)=> this.setState({FEC_TOM:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">HOR_TOM </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.HOR_TOM} onChange={(value)=> this.setState({HOR_TOM:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_IEN </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_IEN} onChange={(value)=> this.setState({FEC_IEN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CONTACTODE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CONTACTODE} onChange={(value)=> this.setState({CONTACTODE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E1} onChange={(value)=> this.setState({E1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM1} onChange={(value)=> this.setState({EXAM1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RES1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RES1} onChange={(value)=> this.setState({RES1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RESUL1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RESUL1} onChange={(value)=> this.setState({RESUL1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FR1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FR1} onChange={(value)=> this.setState({FR1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">INDRE1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.INDRE1} onChange={(value)=> this.setState({INDRE1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E2} onChange={(value)=> this.setState({E2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM2} onChange={(value)=> this.setState({EXAM2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RES2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RES2} onChange={(value)=> this.setState({RES2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RESUL2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RESUL2} onChange={(value)=> this.setState({RESUL2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FR2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FR2} onChange={(value)=> this.setState({FR2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">INDRE2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.INDRE2} onChange={(value)=> this.setState({INDRE2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E3 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E3} onChange={(value)=> this.setState({E3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM3 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM3} onChange={(value)=> this.setState({EXAM3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RES3 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RES3} onChange={(value)=> this.setState({RES3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RESUL3 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RESUL3} onChange={(value)=> this.setState({RESUL3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FR3 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FR3} onChange={(value)=> this.setState({FR3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">INDRE3 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.INDRE3} onChange={(value)=> this.setState({INDRE3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E4 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E4} onChange={(value)=> this.setState({E4:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM4 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM4} onChange={(value)=> this.setState({EXAM4:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RES4 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RES4} onChange={(value)=> this.setState({RES4:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RESUL4 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RESUL4} onChange={(value)=> this.setState({RESUL4:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FR4 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FR4} onChange={(value)=> this.setState({FR4:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">INDRE4 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.INDRE4} onChange={(value)=> this.setState({INDRE4:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E5 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E5} onChange={(value)=> this.setState({E5:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM5 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM5} onChange={(value)=> this.setState({EXAM5:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RES5 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RES5} onChange={(value)=> this.setState({RES5:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RESUL5 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RESUL5} onChange={(value)=> this.setState({RESUL5:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FR5 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FR5} onChange={(value)=> this.setState({FR5:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">INDRE5 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.INDRE5} onChange={(value)=> this.setState({INDRE5:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E6 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E6} onChange={(value)=> this.setState({E6:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM6 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM6} onChange={(value)=> this.setState({EXAM6:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RES6 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RES6} onChange={(value)=> this.setState({RES6:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RESUL6 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RESUL6} onChange={(value)=> this.setState({RESUL6:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FR6 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FR6} onChange={(value)=> this.setState({FR6:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">INDRE6 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.INDRE6} onChange={(value)=> this.setState({INDRE6:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E7 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E7} onChange={(value)=> this.setState({E7:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM7 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM7} onChange={(value)=> this.setState({EXAM7:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RES7 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RES7} onChange={(value)=> this.setState({RES7:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RESUL7 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RESUL7} onChange={(value)=> this.setState({RESUL7:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FR7 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FR7} onChange={(value)=> this.setState({FR7:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">INDRE7 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.INDRE7} onChange={(value)=> this.setState({INDRE7:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E8 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E8} onChange={(value)=> this.setState({E8:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM8 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM8} onChange={(value)=> this.setState({EXAM8:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RES8 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RES8} onChange={(value)=> this.setState({RES8:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RESUL8 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RESUL8} onChange={(value)=> this.setState({RESUL8:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FR8 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FR8} onChange={(value)=> this.setState({FR8:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">INDRE8 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.INDRE8} onChange={(value)=> this.setState({INDRE8:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E9 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E9} onChange={(value)=> this.setState({E9:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM9 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM9} onChange={(value)=> this.setState({EXAM9:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RES9 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RES9} onChange={(value)=> this.setState({RES9:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RESUL9 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RESUL9} onChange={(value)=> this.setState({RESUL9:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FR9 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FR9} onChange={(value)=> this.setState({FR9:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">INDRE9 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.INDRE9} onChange={(value)=> this.setState({INDRE9:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E10 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E10} onChange={(value)=> this.setState({E10:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM10 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM10} onChange={(value)=> this.setState({EXAM10:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RES10 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RES10} onChange={(value)=> this.setState({RES10:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RESUL10 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.RESUL10} onChange={(value)=> this.setState({RESUL10:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FR10 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FR10} onChange={(value)=> this.setState({FR10:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">INDRE10 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.INDRE10} onChange={(value)=> this.setState({INDRE10:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ANTI_1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ANTI_1} onChange={(value)=> this.setState({ANTI_1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ANTI_2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ANTI_2} onChange={(value)=> this.setState({ANTI_2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ANTI_3 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ANTI_3} onChange={(value)=> this.setState({ANTI_3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ANTI_4 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ANTI_4} onChange={(value)=> this.setState({ANTI_4:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ANTI_5 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ANTI_5} onChange={(value)=> this.setState({ANTI_5:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ANTI_6 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ANTI_6} onChange={(value)=> this.setState({ANTI_6:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ANTI_7 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ANTI_7} onChange={(value)=> this.setState({ANTI_7:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ANTI_8 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ANTI_8} onChange={(value)=> this.setState({ANTI_8:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ANTI_9 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ANTI_9} onChange={(value)=> this.setState({ANTI_9:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ANTI_9D </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ANTI_9D} onChange={(value)=> this.setState({ANTI_9D:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">BAAR </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.BAAR} onChange={(value)=> this.setState({BAAR:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CULTIVO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CULTIVO} onChange={(value)=> this.setState({CULTIVO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SEAISLO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.SEAISLO} onChange={(value)=> this.setState({SEAISLO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OBSERV </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.OBSERV} onChange={(value)=> this.setState({OBSERV:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">F_LIBRE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.F_LIBRE} onChange={(value)=> this.setState({F_LIBRE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CONTROL </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CONTROL} onChange={(value)=> this.setState({CONTROL:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DIAG </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DIAG} onChange={(value)=> this.setState({DIAG:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">M_PROCESAD </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.M_PROCESAD} onChange={(value)=> this.setState({M_PROCESAD:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TIPIFICS </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.TIPIFICS} onChange={(value)=> this.setState({TIPIFICS:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">PCR_GX </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.PCR_GX} onChange={(value)=> this.setState({PCR_GX:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_CAP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_CAP} onChange={(value)=> this.setState({FEC_CAP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_IMP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_IMP} onChange={(value)=> this.setState({FEC_IMP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_EINDRE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_EINDRE} onChange={(value)=> this.setState({FEC_EINDRE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_RINDRE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_RINDRE} onChange={(value)=> this.setState({FEC_RINDRE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_VAL </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_VAL} onChange={(value)=> this.setState({FEC_VAL:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">VALIDADO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.VALIDADO} onChange={(value)=> this.setState({VALIDADO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLACAU </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLACAU} onChange={(value)=> this.setState({CLACAU:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SUPLEMENTO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.SUPLEMENTO} onChange={(value)=> this.setState({SUPLEMENTO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">NOTAS </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.NOTAS} onChange={(value)=> this.setState({NOTAS:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendUpdate()}>Update</button>  
</div>
); }
sendUpdate(){
let userId = this.props.match.params.tblmicrobiologiaid;
const baseUrl = "http://localhost:3000/Rtblmicrobiologia/Update/"+ userId
const datapost = {
MUESTRA: this.state.MUESTRA,
DOCTO: this.state.DOCTO,
NUM_DOC: this.state.NUM_DOC,
CLAPRO: this.state.CLAPRO,
CLAMUE: this.state.CLAMUE,
CONFIRMAR: this.state.CONFIRMAR,
AFILIACION: this.state.AFILIACION,
PIORIDAD: this.state.PIORIDAD,
NOMBES: this.state.NOMBES,
APELLIDO_P: this.state.APELLIDO_P,
APELLIDO_M: this.state.APELLIDO_M,
ANIOS: this.state.ANIOS,
MESES: this.state.MESES,
SEXO: this.state.SEXO,
DOMICILIO: this.state.DOMICILIO,
COLONIA: this.state.COLONIA,
LOCALIDAD: this.state.LOCALIDAD,
CLAEDO: this.state.CLAEDO,
CLAMUN: this.state.CLAMUN,
FEC_TOM: this.state.FEC_TOM,
HOR_TOM: this.state.HOR_TOM,
FEC_IEN: this.state.FEC_IEN,
CONTACTODE: this.state.CONTACTODE,
E1: this.state.E1,
EXAM1: this.state.EXAM1,
RES1: this.state.RES1,
RESUL1: this.state.RESUL1,
FR1: this.state.FR1,
INDRE1: this.state.INDRE1,
E2: this.state.E2,
EXAM2: this.state.EXAM2,
RES2: this.state.RES2,
RESUL2: this.state.RESUL2,
FR2: this.state.FR2,
INDRE2: this.state.INDRE2,
E3: this.state.E3,
EXAM3: this.state.EXAM3,
RES3: this.state.RES3,
RESUL3: this.state.RESUL3,
FR3: this.state.FR3,
INDRE3: this.state.INDRE3,
E4: this.state.E4,
EXAM4: this.state.EXAM4,
RES4: this.state.RES4,
RESUL4: this.state.RESUL4,
FR4: this.state.FR4,
INDRE4: this.state.INDRE4,
E5: this.state.E5,
EXAM5: this.state.EXAM5,
RES5: this.state.RES5,
RESUL5: this.state.RESUL5,
FR5: this.state.FR5,
INDRE5: this.state.INDRE5,
E6: this.state.E6,
EXAM6: this.state.EXAM6,
RES6: this.state.RES6,
RESUL6: this.state.RESUL6,
FR6: this.state.FR6,
INDRE6: this.state.INDRE6,
E7: this.state.E7,
EXAM7: this.state.EXAM7,
RES7: this.state.RES7,
RESUL7: this.state.RESUL7,
FR7: this.state.FR7,
INDRE7: this.state.INDRE7,
E8: this.state.E8,
EXAM8: this.state.EXAM8,
RES8: this.state.RES8,
RESUL8: this.state.RESUL8,
FR8: this.state.FR8,
INDRE8: this.state.INDRE8,
E9: this.state.E9,
EXAM9: this.state.EXAM9,
RES9: this.state.RES9,
RESUL9: this.state.RESUL9,
FR9: this.state.FR9,
INDRE9: this.state.INDRE9,
E10: this.state.E10,
EXAM10: this.state.EXAM10,
RES10: this.state.RES10,
RESUL10: this.state.RESUL10,
FR10: this.state.FR10,
INDRE10: this.state.INDRE10,
ANTI_1: this.state.ANTI_1,
ANTI_2: this.state.ANTI_2,
ANTI_3: this.state.ANTI_3,
ANTI_4: this.state.ANTI_4,
ANTI_5: this.state.ANTI_5,
ANTI_6: this.state.ANTI_6,
ANTI_7: this.state.ANTI_7,
ANTI_8: this.state.ANTI_8,
ANTI_9: this.state.ANTI_9,
ANTI_9D: this.state.ANTI_9D,
BAAR: this.state.BAAR,
CULTIVO: this.state.CULTIVO,
SEAISLO: this.state.SEAISLO,
OBSERV: this.state.OBSERV,
F_LIBRE: this.state.F_LIBRE,
CONTROL: this.state.CONTROL,
DIAG: this.state.DIAG,
M_PROCESAD: this.state.M_PROCESAD,
TIPIFICS: this.state.TIPIFICS,
PCR_GX: this.state.PCR_GX,
FEC_CAP: this.state.FEC_CAP,
FEC_IMP: this.state.FEC_IMP,
FEC_EINDRE: this.state.FEC_EINDRE,
FEC_RINDRE: this.state.FEC_RINDRE,
FEC_VAL: this.state.FEC_VAL,
VALIDADO: this.state.VALIDADO,
CLACAU: this.state.CLACAU,
SUPLEMENTO: this.state.SUPLEMENTO,
NOTAS: this.state.NOTAS
}
axios.post(baseUrl,datapost)
.then(response=>{
if (response.data.success===true) {
alert(response.data.message)
}
else {
alert(response.data.message)
alert(JSON.stringify(response))
}
}).catch(error=>{
alert("Error 34 "+error)
})
}
}
export default EditComponent;
