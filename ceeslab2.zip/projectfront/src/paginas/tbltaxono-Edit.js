import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios'
const baseUrl= "http: //localhost:3000"
class EditComponent extends React.Component{

constructor(props){

super(props);
this.state={
edittbltaxonos:[],
datatbltaxono:{},
MUESTRA: "",
C_ENVASE: "",
ENVASE: "",
C_ESPECIME: "",
GENERO: "",
ESPECIE: "",
TOXICIDAD: "",
VECTOR: "",
C_VISITADA: "",
C_POSITIVA: "",
ICP: "",
IIC: "",
FEC_REP: "",
FEC_COL: "",
SITIO: "",
COLECTOR: "",
SUPLEMENTO: "",
CLAPRO: "",
CLAMUN: "",
CLAEDO: "",
OBSERV: ""
}
}


componentDidMount(){
let userId = this.props.match.params.tbltaxonoid;
  const url = baseUrl+"/Rtbltaxono/get/"+userId

  axios.get(url)
 .then(res=>{
  if(res.data.sucess){
  const data = res.data.data[0] 
this.setState({
edittbltaxonos:data,
MUESTRA: data.MUESTRA,
C_ENVASE: data.C_ENVASE,
ENVASE: data.ENVASE,
C_ESPECIME: data.C_ESPECIME,
GENERO: data.GENERO,
ESPECIE: data.ESPECIE,
TOXICIDAD: data.TOXICIDAD,
VECTOR: data.VECTOR,
C_VISITADA: data.C_VISITADA,
C_POSITIVA: data.C_POSITIVA,
ICP: data.ICP,
IIC: data.IIC,
FEC_REP: data.FEC_REP,
FEC_COL: data.FEC_COL,
SITIO: data.SITIO,
COLECTOR: data.COLECTOR,
SUPLEMENTO: data.SUPLEMENTO,
CLAPRO: data.CLAPRO,
CLAMUN: data.CLAMUN,
CLAEDO: data.CLAEDO,
OBSERV: data.OBSERV
} ) }
else{
alert("Error web service")
} } )
  .catch(error=>{
  })
}


  render(){
   let userId = 0;
 return (
<div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MUESTRA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.MUESTRA} onChange={(value)=> this.setState({MUESTRA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">C_ENVASE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.C_ENVASE} onChange={(value)=> this.setState({C_ENVASE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ENVASE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ENVASE} onChange={(value)=> this.setState({ENVASE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">C_ESPECIME </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.C_ESPECIME} onChange={(value)=> this.setState({C_ESPECIME:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">GENERO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.GENERO} onChange={(value)=> this.setState({GENERO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ESPECIE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ESPECIE} onChange={(value)=> this.setState({ESPECIE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TOXICIDAD </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.TOXICIDAD} onChange={(value)=> this.setState({TOXICIDAD:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">VECTOR </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.VECTOR} onChange={(value)=> this.setState({VECTOR:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">C_VISITADA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.C_VISITADA} onChange={(value)=> this.setState({C_VISITADA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">C_POSITIVA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.C_POSITIVA} onChange={(value)=> this.setState({C_POSITIVA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ICP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ICP} onChange={(value)=> this.setState({ICP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">IIC </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.IIC} onChange={(value)=> this.setState({IIC:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_REP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_REP} onChange={(value)=> this.setState({FEC_REP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_COL </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_COL} onChange={(value)=> this.setState({FEC_COL:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SITIO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.SITIO} onChange={(value)=> this.setState({SITIO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">COLECTOR </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.COLECTOR} onChange={(value)=> this.setState({COLECTOR:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SUPLEMENTO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.SUPLEMENTO} onChange={(value)=> this.setState({SUPLEMENTO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAPRO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAPRO} onChange={(value)=> this.setState({CLAPRO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAMUN </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAMUN} onChange={(value)=> this.setState({CLAMUN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAEDO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAEDO} onChange={(value)=> this.setState({CLAEDO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OBSERV </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.OBSERV} onChange={(value)=> this.setState({OBSERV:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendUpdate()}>Update</button>  
</div>
); }
sendUpdate(){
let userId = this.props.match.params.tbltaxonoid;
const baseUrl = "http://localhost:3000/Rtbltaxono/Update/"+ userId
const datapost = {
MUESTRA: this.state.MUESTRA,
C_ENVASE: this.state.C_ENVASE,
ENVASE: this.state.ENVASE,
C_ESPECIME: this.state.C_ESPECIME,
GENERO: this.state.GENERO,
ESPECIE: this.state.ESPECIE,
TOXICIDAD: this.state.TOXICIDAD,
VECTOR: this.state.VECTOR,
C_VISITADA: this.state.C_VISITADA,
C_POSITIVA: this.state.C_POSITIVA,
ICP: this.state.ICP,
IIC: this.state.IIC,
FEC_REP: this.state.FEC_REP,
FEC_COL: this.state.FEC_COL,
SITIO: this.state.SITIO,
COLECTOR: this.state.COLECTOR,
SUPLEMENTO: this.state.SUPLEMENTO,
CLAPRO: this.state.CLAPRO,
CLAMUN: this.state.CLAMUN,
CLAEDO: this.state.CLAEDO,
OBSERV: this.state.OBSERV
}
axios.post(baseUrl,datapost)
.then(response=>{
if (response.data.success===true) {
alert(response.data.message)
}
else {
alert(response.data.message)
alert(JSON.stringify(response))
}
}).catch(error=>{
alert("Error 34 "+error)
})
}
}
export default EditComponent;
