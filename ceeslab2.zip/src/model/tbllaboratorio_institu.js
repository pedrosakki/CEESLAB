const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tbllaboratorio_institu')
var nametable = 'tbllaboratorio_institu';
var tbllaboratorio_institu = sequelize.define(nametable,{
idtbllaboratorio_institu:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


LOGO1:  Sequelize.STRING,
LOGO2:  Sequelize.STRING,
ENCAB1:  Sequelize.STRING,
ENCAB2:  Sequelize.STRING,
ENCAB3:  Sequelize.STRING,
PIE1:  Sequelize.STRING,
DIRECC:  Sequelize.STRING,
DNOMBRE:  Sequelize.STRING,
MCPUESTO:  Sequelize.STRING,
MCNOMBRE1:  Sequelize.STRING,
AMPUESTO:  Sequelize.STRING,
AMNOMBRE:  Sequelize.STRING,
CCPUESTO:  Sequelize.STRING,
CCNOMBRE:  Sequelize.STRING,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tbllaboratorio_institu;
