import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios';
class EditComponent extends React.Component{
constructor(props){
super(props);
this.state = {
MUESTRA:"",
CLAPRO:"",
CLAMUE:"",
FEC_REP:"",
OBSERVA:"",
SEMANA:"",
MICROSCO:"",
REVIS:"",
CMUESTRA:"",
CTINCINO:"",
FNEGATIVAS:"",
FPOSITIVAS:"",
TGOT:"",
FEC_CAP:"",
FEC_IMP:"",
FEC_VAL:"",
VALIDADO:"",
CLACAU:"",
SUPLEMENTO:""
}
}
render(){
  return (
<div>
 <div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MUESTRA </label>
<input type="text" class="form-control" placeholder="MUESTRA" value={this.state.MUESTRA} onChange={(value)=> this.setState({MUESTRA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAPRO </label>
<input type="text" class="form-control" placeholder="CLAPRO" value={this.state.CLAPRO} onChange={(value)=> this.setState({CLAPRO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAMUE </label>
<input type="text" class="form-control" placeholder="CLAMUE" value={this.state.CLAMUE} onChange={(value)=> this.setState({CLAMUE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_REP </label>
<input type="text" class="form-control" placeholder="FEC_REP" value={this.state.FEC_REP} onChange={(value)=> this.setState({FEC_REP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OBSERVA </label>
<input type="text" class="form-control" placeholder="OBSERVA" value={this.state.OBSERVA} onChange={(value)=> this.setState({OBSERVA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SEMANA </label>
<input type="text" class="form-control" placeholder="SEMANA" value={this.state.SEMANA} onChange={(value)=> this.setState({SEMANA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MICROSCO </label>
<input type="text" class="form-control" placeholder="MICROSCO" value={this.state.MICROSCO} onChange={(value)=> this.setState({MICROSCO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">REVIS </label>
<input type="text" class="form-control" placeholder="REVIS" value={this.state.REVIS} onChange={(value)=> this.setState({REVIS:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CMUESTRA </label>
<input type="text" class="form-control" placeholder="CMUESTRA" value={this.state.CMUESTRA} onChange={(value)=> this.setState({CMUESTRA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CTINCINO </label>
<input type="text" class="form-control" placeholder="CTINCINO" value={this.state.CTINCINO} onChange={(value)=> this.setState({CTINCINO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FNEGATIVAS </label>
<input type="text" class="form-control" placeholder="FNEGATIVAS" value={this.state.FNEGATIVAS} onChange={(value)=> this.setState({FNEGATIVAS:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FPOSITIVAS </label>
<input type="text" class="form-control" placeholder="FPOSITIVAS" value={this.state.FPOSITIVAS} onChange={(value)=> this.setState({FPOSITIVAS:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TGOT </label>
<input type="text" class="form-control" placeholder="TGOT" value={this.state.TGOT} onChange={(value)=> this.setState({TGOT:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_CAP </label>
<input type="text" class="form-control" placeholder="FEC_CAP" value={this.state.FEC_CAP} onChange={(value)=> this.setState({FEC_CAP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_IMP </label>
<input type="text" class="form-control" placeholder="FEC_IMP" value={this.state.FEC_IMP} onChange={(value)=> this.setState({FEC_IMP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_VAL </label>
<input type="text" class="form-control" placeholder="FEC_VAL" value={this.state.FEC_VAL} onChange={(value)=> this.setState({FEC_VAL:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">VALIDADO </label>
<input type="text" class="form-control" placeholder="VALIDADO" value={this.state.VALIDADO} onChange={(value)=> this.setState({VALIDADO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLACAU </label>
<input type="text" class="form-control" placeholder="CLACAU" value={this.state.CLACAU} onChange={(value)=> this.setState({CLACAU:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SUPLEMENTO </label>
<input type="text" class="form-control" placeholder="SUPLEMENTO" value={this.state.SUPLEMENTO} onChange={(value)=> this.setState({SUPLEMENTO:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendSave()}>Save</button>
</div>
</div>
);
}
  sendSave(){
const baseUrl = "http://localhost:3000/Rtblcalidad3/create"
const datapost = {
MUESTRA: this.state.MUESTRA,
CLAPRO: this.state.CLAPRO,
CLAMUE: this.state.CLAMUE,
FEC_REP: this.state.FEC_REP,
OBSERVA: this.state.OBSERVA,
SEMANA: this.state.SEMANA,
MICROSCO: this.state.MICROSCO,
REVIS: this.state.REVIS,
CMUESTRA: this.state.CMUESTRA,
CTINCINO: this.state.CTINCINO,
FNEGATIVAS: this.state.FNEGATIVAS,
FPOSITIVAS: this.state.FPOSITIVAS,
TGOT: this.state.TGOT,
FEC_CAP: this.state.FEC_CAP,
FEC_IMP: this.state.FEC_IMP,
FEC_VAL: this.state.FEC_VAL,
VALIDADO: this.state.VALIDADO,
CLACAU: this.state.CLACAU,
SUPLEMENTO: this.state.SUPLEMENTO
}
axios.post(baseUrl,datapost)
      .then(response=>{
 if (response.data.success===true) {
  alert(response.data.message)
}
else {
alert(response.data.message)
}
}).catch(error=>{
   alert("Error 34 "+error)
 })
 }
}
export default EditComponent;
