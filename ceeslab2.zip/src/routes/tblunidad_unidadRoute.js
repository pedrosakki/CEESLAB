const express = require('express');
const router = express.Router();
const tblunidad_unidadController = require('../Controllers/tblunidad_unidadController')


router.post('/update/:id',tblunidad_unidadController.update)
router.get('/get/:id', tblunidad_unidadController.get)
router.get('/list', tblunidad_unidadController.list);
router.post('/create', tblunidad_unidadController.create);


module.exports = router;
