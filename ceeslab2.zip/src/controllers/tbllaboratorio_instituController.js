 const controllers = {}
var sequelize = require('../model/database');
var tbllaboratorio_institu = require('../model/tbllaboratorio_institu');

//METODO GET//

controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tbllaboratorio_institu.findAll({
where: {idtbllaboratorio_institu: id }  })
.then(function(data){
    return data;})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}


//METODO LIST//

controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tbllaboratorio_institu.findAll();
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}



//METODO CREATE//
controllers.create = async (req, res)=>{
const  {LOGO1,LOGO2,ENCAB1,ENCAB2,ENCAB3,PIE1,DIRECC,DNOMBRE,MCPUESTO,MCNOMBRE1,AMPUESTO,AMNOMBRE,CCPUESTO,CCNOMBRE}=req.body;
const data = await tbllaboratorio_institu.create({
LOGO1: LOGO1,
LOGO2: LOGO2,
ENCAB1: ENCAB1,
ENCAB2: ENCAB2,
ENCAB3: ENCAB3,
PIE1: PIE1,
DIRECC: DIRECC,
DNOMBRE: DNOMBRE,
MCPUESTO: MCPUESTO,
MCNOMBRE1: MCNOMBRE1,
AMPUESTO: AMPUESTO,
AMNOMBRE: AMNOMBRE,
CCPUESTO: CCPUESTO,
CCNOMBRE: CCNOMBRE
}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data
})
}


//METODO UPDATE//
controllers.update = async (req, res)=>{
  const { id } = req.params;
const  {LOGO1,LOGO2,ENCAB1,ENCAB2,ENCAB3,PIE1,DIRECC,DNOMBRE,MCPUESTO,MCNOMBRE1,AMPUESTO,AMNOMBRE,CCPUESTO,CCNOMBRE}=req.body;

 const data = await tbllaboratorio_institu.update({
LOGO1: LOGO1,
LOGO2: LOGO2,
ENCAB1: ENCAB1,
ENCAB2: ENCAB2,
ENCAB3: ENCAB3,
PIE1: PIE1,
DIRECC: DIRECC,
DNOMBRE: DNOMBRE,
MCPUESTO: MCPUESTO,
MCNOMBRE1: MCNOMBRE1,
AMPUESTO: AMPUESTO,
AMNOMBRE: AMNOMBRE,
CCPUESTO: CCPUESTO,
CCNOMBRE: CCNOMBRE
   },{
          where: { idtbllaboratorio_institu: id}
     })
  .then( function(data){
    return data;
      })
       .catch(error => {
        return error;
   }) 
   res.json({success:true, data:data, message:"Updated successful"});
 }



 module.exports = controllers;
