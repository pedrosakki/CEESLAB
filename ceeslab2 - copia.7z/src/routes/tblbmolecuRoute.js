const express = require('express');
const router = express.Router();
const tblbmolecuController = require('../Controllers/tblbmolecuController')


router.post('/update/:id',tblbmolecuController.update)
router.get('/get/:id', tblbmolecuController.get)
router.get('/list', tblbmolecuController.list);
router.post('/create', tblbmolecuController.create);


module.exports = router;
