import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios';
class EditComponent extends React.Component{
constructor(props){
super(props);
this.state = {
FOL_ENV:"",
FEC_ENV:"",
FEC_ARC:""
}
}
render(){
  return (
<div>
 <div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FOL_ENV </label>
<input type="text" class="form-control" placeholder="FOL_ENV" value={this.state.FOL_ENV} onChange={(value)=> this.setState({FOL_ENV:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_ENV </label>
<input type="text" class="form-control" placeholder="FEC_ENV" value={this.state.FEC_ENV} onChange={(value)=> this.setState({FEC_ENV:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_ARC </label>
<input type="text" class="form-control" placeholder="FEC_ARC" value={this.state.FEC_ARC} onChange={(value)=> this.setState({FEC_ARC:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendSave()}>Save</button>
</div>
</div>
);
}
  sendSave(){
const baseUrl = "http://localhost:3000/Rtblenvioenca_envios/create"
const datapost = {
FOL_ENV: this.state.FOL_ENV,
FEC_ENV: this.state.FEC_ENV,
FEC_ARC: this.state.FEC_ARC
}
axios.post(baseUrl,datapost)
      .then(response=>{
 if (response.data.success===true) {
  alert(response.data.message)
}
else {
alert(response.data.message)
}
}).catch(error=>{
   alert("Error 34 "+error)
 })
 }
}
export default EditComponent;
