const express = require('express');
const app = express();
//const pdf=require('html-pdf')
//const pdfTemplate= require('./documents')

//Settings
app.set('port', process.env.PORT || 3000);

//Middlewares
app.use(express.json());

//importing Route

// Configurar cabeceras y cors
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Authorization, X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Allow-Request-Method');
  res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
  res.header('Allow', 'GET, POST, OPTIONS, PUT, DELETE');
  next();
});


//post PDF generation and fetching  of the data
/*
app.post('/create-pdf', (req, res) => {
  pdf.create(pdfTemplate(req.body), {}).toFile('result.pdf', (err) => {
      if(err) {
          res.send(Promise.reject());
      }
          res.send(Promise.resolve());
  });
});
//GET send the generated pdf to the client
app.get('/fetch-pdf', (req, res) => {
  res.sendFile(`${__dirname}/result.pdf`)
})
*/


//const tblempleadoRouters = require('./routes/tblempleadoRoute')
//const permisosRouters = require('./routes/permisosRoute')
//const tblcalidad1Routers = require('./routes/tblcalidad1Route')
//const tblestado_estadoRouters = require('./routes/tblestado_estadoRoute')



//app.use('/Rtblcalidad1',tblcalidad1Routers)
//app.use('/Rtblestado_estado',tblestado_estadoRouters)
//app.use('/Empleados',tblempleadoRouters)
//app.use('/Rpermisos',permisosRouters)




const tblambiente_ambientRouters = require('./routes/tblambiente_ambientRoute');
const tblbmolecuRouters = require('./routes/tblbmolecuRoute');
const tblcalidad1Routers = require('./routes/tblcalidad1Route');
const tblcalidad10Routers = require('./routes/tblcalidad10Route');
const tblcalidad11Routers = require('./routes/tblcalidad11Route');
//const tblcalidad2Routers = require('./routes/tblcalidad2Route');
const tblcalidad3Routers = require('./routes/tblcalidad3Route');
const tblcalidad4Routers = require('./routes/tblcalidad4Route');
const tblcalidad5Routers = require('./routes/tblcalidad5Route');
const tblcalidad6Routers = require('./routes/tblcalidad6Route');
const tblcalidad7Routers = require('./routes/tblcalidad7Route');
const tblcalidad8Routers = require('./routes/tblcalidad8Route');
const tblcalidad9Routers = require('./routes/tblcalidad9Route');
const tblcargaviral_carvirRouters = require('./routes/tblcargaviral_carvirRoute');
const tblcausas_causasRouters = require('./routes/tblcausas_causasRoute');
const tbldireccion_direccRouters = require('./routes/tbldireccion_direccRoute');
const tblenviodeta_envdetRouters = require('./routes/tblenviodeta_envdetRoute');
const tblenvioenca_enviosRouters = require('./routes/tblenvioenca_enviosRoute');
const tblestado_estadoRouters = require('./routes/tblestado_estadoRoute');
const tbllaboratorio_instituRouters = require('./routes/tbllaboratorio_instituRoute');
const tblmicrobiologiaRouters = require('./routes/tblmicrobiologiaRoute');
const tblmotivomuestra_motmuesRouters = require('./routes/tblmotivomuestra_motmuesRoute');
const tblmuestra_recepRouters = require('./routes/tblmuestra_recepRoute');
const tblmunicipio_municipRouters = require('./routes/tblmunicipio_municipRoute');
const tblpermisosRouters = require('./routes/tblpermisosRoute');
const tblprocedencia_procedenRouters = require('./routes/tblprocedencia_procedenRoute');
const tblregionsanitaria_regionsaRouters = require('./routes/tblregionsanitaria_regionsaRoute');
const tbltaxonoRouters = require('./routes/tbltaxonoRoute');
const tbltipoexamen_tipoexaRouters = require('./routes/tbltipoexamen_tipoexaRoute');
const tbltipomuestra_tmuesRouters = require('./routes/tbltipomuestra_tmuesRoute');
const tbltiporesultado_tiporesRouters = require('./routes/tbltiporesultado_tiporesRoute');
const tblunidad_unidadRouters = require('./routes/tblunidad_unidadRoute');
const tblusuario_usuariosRouters = require('./routes/tblusuario_usuariosRoute');

app.use('/Rtblambiente_ambient',tblambiente_ambientRouters);
app.use('/Rtblbmolecu',tblbmolecuRouters);
app.use('/Rtblcalidad1',tblcalidad1Routers);
app.use('/Rtblcalidad10',tblcalidad10Routers);
app.use('/Rtblcalidad11',tblcalidad11Routers);
//app.use('/Rtblcalidad2',tblcalidad2Routers);
app.use('/Rtblcalidad3',tblcalidad3Routers);
app.use('/Rtblcalidad4',tblcalidad4Routers);
app.use('/Rtblcalidad5',tblcalidad5Routers);
app.use('/Rtblcalidad6',tblcalidad6Routers);
app.use('/Rtblcalidad7',tblcalidad7Routers);
app.use('/Rtblcalidad8',tblcalidad8Routers);
app.use('/Rtblcalidad9',tblcalidad9Routers);
app.use('/Rtblcargaviral_carvir',tblcargaviral_carvirRouters);
app.use('/Rtblcausas_causas',tblcausas_causasRouters);
app.use('/Rtbldireccion_direcc',tbldireccion_direccRouters);
app.use('/Rtblenviodeta_envdet',tblenviodeta_envdetRouters);
app.use('/Rtblenvioenca_envios',tblenvioenca_enviosRouters);
app.use('/Rtblestado_estado',tblestado_estadoRouters);
app.use('/Rtbllaboratorio_institu',tbllaboratorio_instituRouters);
app.use('/Rtblmicrobiologia',tblmicrobiologiaRouters);
app.use('/Rtblmotivomuestra_motmues',tblmotivomuestra_motmuesRouters);
app.use('/Rtblmuestra_recep',tblmuestra_recepRouters);
app.use('/Rtblmunicipio_municip',tblmunicipio_municipRouters);
app.use('/Rtblpermisos',tblpermisosRouters);
app.use('/Rtblprocedencia_proceden',tblprocedencia_procedenRouters);
app.use('/Rtblregionsanitaria_regionsa',tblregionsanitaria_regionsaRouters);
app.use('/Rtbltaxono',tbltaxonoRouters);
app.use('/Rtbltipoexamen_tipoexa',tbltipoexamen_tipoexaRouters);
app.use('/Rtbltipomuestra_tmues',tbltipomuestra_tmuesRouters);
app.use('/Rtbltiporesultado_tipores',tbltiporesultado_tiporesRouters);
app.use('/Rtblunidad_unidad',tblunidad_unidadRouters);
app.use('/Rtblusuario_usuarios',tblusuario_usuariosRouters);


app.use('/test', (req, res) => {
    res.send("Test route");
  });

app.use('/',(req,res)=>{
  res.send("Hello World form NodeJS express.");
});


app.listen(app.get('port'),()=>{
  console.log("Start server on port "+app.get('port'))
})