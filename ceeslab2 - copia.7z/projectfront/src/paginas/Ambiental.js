import React, { Component } from 'react';


class Ambiental extends Component{
    render() {
      return (
        <div>
          <hr id="Line1" style={{position: 'absolute', left: '137px', top: '34px', width: '1124px', zIndex: 244}} />
          <label htmlFor id="Label1" style={{position: 'absolute', left: '250px', top: '34px', width: '320px', height: '36px', lineHeight: '36px', zIndex: 245}}>Control Ambiental</label>
          <label htmlFor id="Label2" style={{position: 'absolute', left: '226px', top: '167px', width: '81px', height: '20px', lineHeight: '20px', zIndex: 246}}>Muestra No.</label>
          <input type="text" id="Editbox1" style={{position: 'absolute', left: '368px', top: '168px', width: '86px', height: '16px', zIndex: 247}} name="Editbox1" defaultValue spellCheck="false" />
          <label htmlFor id="Label3" style={{position: 'absolute', left: '482px', top: '167px', width: '55px', height: '20px', lineHeight: '20px', zIndex: 248}}>Fecha</label>
          <label htmlFor id="Label4" style={{position: 'absolute', left: '671px', top: '167px', width: '55px', height: '20px', lineHeight: '20px', zIndex: 249}}>Hora</label>
          <input type="text" id="Editbox2" style={{position: 'absolute', left: '541px', top: '168px', width: '86px', height: '16px', zIndex: 250}} name="Editbox1" defaultValue spellCheck="false" />
          <label htmlFor id="Label5" style={{position: 'absolute', left: '225px', top: '210px', width: '81px', height: '20px', lineHeight: '20px', zIndex: 251}}>Procedencia</label>
          <input type="text" id="Editbox3" style={{position: 'absolute', left: '367px', top: '211px', width: '86px', height: '16px', zIndex: 252}} name="Editbox1" defaultValue spellCheck="false" />
          <input type="text" id="Editbox4" style={{position: 'absolute', left: '482px', top: '211px', width: '540px', height: '16px', zIndex: 253}} name="Editbox1" defaultValue spellCheck="false" />
          <label htmlFor id="Label6" style={{position: 'absolute', left: '226px', top: '248px', width: '106px', height: '20px', lineHeight: '20px', zIndex: 254}}>Tipo de Muestra</label>
          <input type="text" id="Editbox5" style={{position: 'absolute', left: '367px', top: '249px', width: '86px', height: '16px', zIndex: 255}} name="Editbox1" defaultValue spellCheck="false" />
          <input type="text" id="Editbox6" style={{position: 'absolute', left: '482px', top: '249px', width: '540px', height: '16px', zIndex: 256}} name="Editbox1" defaultValue spellCheck="false" />
          <label htmlFor id="Label7" style={{position: 'absolute', left: '224px', top: '293px', width: '238px', height: '20px', lineHeight: '20px', zIndex: 257}}>Ampliar tipo de muestra (ambiental)</label>
          <input type="text" id="Editbox7" style={{position: 'absolute', left: '482px', top: '294px', width: '540px', height: '16px', zIndex: 258}} name="Editbox1" defaultValue spellCheck="false" />
          <label htmlFor id="Label9" style={{position: 'absolute', left: '224px', top: '414px', width: '81px', height: '20px', lineHeight: '20px', zIndex: 259}}>Temperatura</label>
          <input type="text" id="Editbox9" style={{position: 'absolute', left: '338px', top: '417px', width: '86px', height: '16px', zIndex: 260}} name="Editbox1" defaultValue spellCheck="false" />
          <div id="wb_Line2" style={{position: 'absolute', left: '212px', top: '449px', width: '1045px', height: '2px', zIndex: 261}}>
            <img src="images/img0001.png" id="Line2" alt="" /></div>
          <label htmlFor id="Label11" style={{position: 'absolute', left: '220px', top: '453px', width: '242px', height: '22px', lineHeight: '22px', zIndex: 262}}>DATOS DEL ESTABLECIMIENTO</label>
          <hr id="Line5" style={{position: 'absolute', left: '216px', top: '763px', width: '188px', zIndex: 263}} />
          <label htmlFor id="Label27" style={{position: 'absolute', left: '215px', top: '735px', width: '190px', height: '22px', lineHeight: '22px', zIndex: 264}}>DATOS DEL MUESTREO</label>
          <input type="submit" id="Button1" name defaultValue="Nuevo" style={{position: 'absolute', left: '247px', top: '110px', width: '72px', height: '18px', zIndex: 265}} />
          <input type="submit" id="Button2" name defaultValue="Guardar" style={{position: 'absolute', left: '339px', top: '110px', width: '72px', height: '18px', zIndex: 266}} />
          <input type="submit" id="Button3" name defaultValue="Modificar" style={{position: 'absolute', left: '433px', top: '110px', width: '72px', height: '18px', zIndex: 267}} />
          <input type="submit" id="Button4" name defaultValue="Hojas de Trabajo" style={{position: 'absolute', left: '888px', top: '110px', width: '144px', height: '18px', zIndex: 268}} />
          <input type="text" id="Editbox31" style={{position: 'absolute', left: '722px', top: '168px', width: '86px', height: '16px', zIndex: 269}} name="Editbox1" defaultValue spellCheck="false" />
          <label htmlFor id="Label31" style={{position: 'absolute', left: '831px', top: '167px', width: '55px', height: '20px', lineHeight: '20px', zIndex: 270}}>No.</label>
          <input type="text" id="Editbox32" style={{position: 'absolute', left: '888px', top: '168px', width: '86px', height: '16px', zIndex: 271}} name="Editbox1" defaultValue spellCheck="false" />
          <label htmlFor id="Label8" style={{position: 'absolute', left: '229px', top: '343px', width: '42px', height: '20px', lineHeight: '20px', zIndex: 272}}>Marca</label>
          <label htmlFor id="Label32" style={{position: 'absolute', left: '229px', top: '381px', width: '42px', height: '20px', lineHeight: '20px', zIndex: 273}}>Lote</label>
          <input type="text" id="Editbox8" style={{position: 'absolute', left: '300px', top: '344px', width: '195px', height: '16px', zIndex: 274}} name="Editbox1" defaultValue spellCheck="false" />
          <input type="text" id="Editbox33" style={{position: 'absolute', left: '300px', top: '383px', width: '195px', height: '16px', zIndex: 275}} name="Editbox1" defaultValue spellCheck="false" />
          <label htmlFor id="Label33" style={{position: 'absolute', left: '690px', top: '343px', width: '87px', height: '20px', lineHeight: '20px', zIndex: 276}}>Presentación</label>
          <label htmlFor id="Label34" style={{position: 'absolute', left: '690px', top: '381px', width: '87px', height: '20px', lineHeight: '20px', zIndex: 277}}>Caducidad</label>
          <input type="text" id="Editbox34" style={{position: 'absolute', left: '805px', top: '344px', width: '195px', height: '16px', zIndex: 278}} name="Editbox1" defaultValue spellCheck="false" />
          <input type="text" id="Editbox35" style={{position: 'absolute', left: '805px', top: '383px', width: '195px', height: '16px', zIndex: 279}} name="Editbox1" defaultValue spellCheck="false" />
          <hr id="Line7" style={{position: 'absolute', left: '214px', top: '483px', width: '256px', zIndex: 280}} />
          <label htmlFor id="Label10" style={{position: 'absolute', left: '209px', top: '498px', width: '97px', height: '20px', lineHeight: '20px', zIndex: 281}}>Nombre ó giro</label>
          <input type="text" id="Editbox10" style={{position: 'absolute', left: '320px', top: '499px', width: '392px', height: '16px', zIndex: 282}} name="Editbox1" defaultValue spellCheck="false" />
          <label htmlFor id="Label12" style={{position: 'absolute', left: '781px', top: '498px', width: '41px', height: '20px', lineHeight: '20px', zIndex: 283}}>RFC</label>
          <input type="text" id="Editbox36" style={{position: 'absolute', left: '834px', top: '499px', width: '208px', height: '16px', zIndex: 284}} name="Editbox1" defaultValue spellCheck="false" />
          <label htmlFor id="Label13" style={{position: 'absolute', left: '214px', top: '534px', width: '97px', height: '20px', lineHeight: '20px', zIndex: 285}}>Domicilio</label>
          <input type="text" id="Editbox37" style={{position: 'absolute', left: '320px', top: '535px', width: '335px', height: '16px', zIndex: 286}} name="Editbox1" defaultValue spellCheck="false" />
          <label htmlFor id="Label14" style={{position: 'absolute', left: '715px', top: '534px', width: '57px', height: '20px', lineHeight: '20px', zIndex: 287}}>Colonia</label>
          <input type="text" id="Editbox38" style={{position: 'absolute', left: '780px', top: '535px', width: '262px', height: '16px', zIndex: 288}} name="Editbox1" defaultValue spellCheck="false" />
          <label htmlFor id="Label15" style={{position: 'absolute', left: '215px', top: '569px', width: '97px', height: '20px', lineHeight: '20px', zIndex: 289}}>Localidad</label>
          <input type="text" id="Editbox39" style={{position: 'absolute', left: '320px', top: '570px', width: '335px', height: '16px', zIndex: 290}} name="Editbox1" defaultValue spellCheck="false" />
          <label htmlFor id="Label16" style={{position: 'absolute', left: '220px', top: '607px', width: '97px', height: '20px', lineHeight: '20px', zIndex: 291}}>Municipio</label>
          <input type="text" id="Editbox40" style={{position: 'absolute', left: '320px', top: '608px', width: '60px', height: '16px', zIndex: 292}} name="Editbox1" defaultValue spellCheck="false" />
          <input type="text" id="Editbox41" style={{position: 'absolute', left: '402px', top: '607px', width: '387px', height: '16px', zIndex: 293}} name="Editbox1" defaultValue spellCheck="false" />
          <label htmlFor id="Label17" style={{position: 'absolute', left: '221px', top: '644px', width: '97px', height: '20px', lineHeight: '20px', zIndex: 294}}>Estado</label>
          <input type="text" id="Editbox42" style={{position: 'absolute', left: '320px', top: '645px', width: '60px', height: '16px', zIndex: 295}} name="Editbox1" defaultValue spellCheck="false" />
          <input type="text" id="Editbox43" style={{position: 'absolute', left: '402px', top: '644px', width: '387px', height: '16px', zIndex: 296}} name="Editbox1" defaultValue spellCheck="false" />
          <label htmlFor id="Label18" style={{position: 'absolute', left: '221px', top: '683px', width: '97px', height: '20px', lineHeight: '20px', zIndex: 297}}>Codigo Postal</label>
          <input type="text" id="Editbox44" style={{position: 'absolute', left: '320px', top: '684px', width: '141px', height: '16px', zIndex: 298}} name="Editbox1" defaultValue spellCheck="false" />
          <label htmlFor id="Label19" style={{position: 'absolute', left: '214px', top: '778px', width: '48px', height: '20px', lineHeight: '20px', zIndex: 299}}>Fecha</label>
          <input type="text" id="Editbox11" style={{position: 'absolute', left: '280px', top: '780px', width: '141px', height: '16px', zIndex: 300}} name="Editbox1" defaultValue spellCheck="false" />
          <label htmlFor id="Label20" style={{position: 'absolute', left: '453px', top: '780px', width: '48px', height: '20px', lineHeight: '20px', zIndex: 301}}>Hora</label>
          <input type="text" id="Editbox12" style={{position: 'absolute', left: '520px', top: '782px', width: '141px', height: '16px', zIndex: 302}} name="Editbox1" defaultValue spellCheck="false" />
          <label htmlFor id="Label21" style={{position: 'absolute', left: '696px', top: '779px', width: '81px', height: '20px', lineHeight: '20px', zIndex: 303}}>Temperatura</label>
          <input type="text" id="Editbox13" style={{position: 'absolute', left: '819px', top: '781px', width: '141px', height: '16px', zIndex: 304}} name="Editbox1" defaultValue spellCheck="false" />
          <label htmlFor id="Label22" style={{position: 'absolute', left: '216px', top: '819px', width: '48px', height: '20px', lineHeight: '20px', zIndex: 305}}>Motivo</label>
          <input type="text" id="Editbox14" style={{position: 'absolute', left: '279px', top: '820px', width: '289px', height: '16px', zIndex: 306}} name="Editbox1" defaultValue spellCheck="false" />
          <label htmlFor id="Label23" style={{position: 'absolute', left: '646px', top: '821px', width: '48px', height: '20px', lineHeight: '20px', zIndex: 307}}>Punto</label>
          <input type="text" id="Editbox15" style={{position: 'absolute', left: '696px', top: '822px', width: '264px', height: '16px', zIndex: 308}} name="Editbox1" defaultValue spellCheck="false" />
          <hr id="Line6" style={{position: 'absolute', left: '216px', top: '912px', width: '188px', zIndex: 309}} />
          <label htmlFor id="Label24" style={{position: 'absolute', left: '215px', top: '884px', width: '190px', height: '22px', lineHeight: '22px', zIndex: 310}}>OBSERCACIONES</label>
          <input type="text" id="Editbox16" style={{position: 'absolute', left: '222px', top: '927px', width: '803px', height: '71px', zIndex: 311}} name="Editbox1" defaultValue spellCheck="false" />
          <hr id="Line10" style={{position: 'absolute', left: '226px', top: '1065px', width: '76px', zIndex: 312}} />
          <label htmlFor id="Label25" style={{position: 'absolute', left: '226px', top: '1035px', width: '79px', height: '22px', lineHeight: '22px', zIndex: 313}}>ESTATUS</label>
          <label htmlFor id="Label26" style={{position: 'absolute', left: '311px', top: '1037px', width: '104px', height: '18px', lineHeight: '18px', zIndex: 314}}>CAPTURADO</label>
          <label htmlFor id="Label28" style={{position: 'absolute', left: '531px', top: '1037px', width: '98px', height: '18px', lineHeight: '18px', zIndex: 315}}>VALIDADO</label>
          <label htmlFor id="Label29" style={{position: 'absolute', left: '703px', top: '1037px', width: '79px', height: '18px', lineHeight: '18px', zIndex: 316}}>IMPRESO</label>
          <label htmlFor id="Label30" style={{position: 'absolute', left: '415px', top: '1036px', width: '84px', height: '20px', lineHeight: '20px', zIndex: 317}}>Fecha</label>
          <label htmlFor id="Label35" style={{position: 'absolute', left: '613px', top: '1036px', width: '88px', height: '20px', lineHeight: '20px', zIndex: 318}}>FECHA</label>
          <label htmlFor id="Label36" style={{position: 'absolute', left: '793px', top: '1036px', width: '72px', height: '20px', lineHeight: '20px', zIndex: 319}}>Impreso</label>
          <label htmlFor id="Label37" style={{position: 'absolute', left: '864px', top: '1037px', width: '79px', height: '18px', lineHeight: '18px', zIndex: 320}}>FOLIO</label>
          <label htmlFor id="Label38" style={{position: 'absolute', left: '923px', top: '1037px', width: '79px', height: '18px', lineHeight: '18px', zIndex: 321}}>F1</label>
          <div id="wb_Line4" style={{position: 'absolute', left: '212px', top: '731px', width: '1045px', height: '2px', zIndex: 322}}>
            <img src="images/img0002.png" id="Line4" alt="" /></div>
          <div id="wb_Line3" style={{position: 'absolute', left: '212px', top: '880px', width: '1045px', height: '2px', zIndex: 323}}>
            <img src="images/img0003.png" id="Line3" alt="" /></div>
          <div id="wb_Line8" style={{position: 'absolute', left: '212px', top: '1017px', width: '1045px', height: '2px', zIndex: 324}}>
            <img src="images/img0004.png" id="Line8" alt="" /></div>
          <div id="wb_Line9" style={{position: 'absolute', left: '212px', top: '1075px', width: '1045px', height: '2px', zIndex: 325}}>
            <img src="images/img0005.png" id="Line9" alt="" /></div>
          <label htmlFor id="Label39" style={{position: 'absolute', left: '984px', top: '1037px', width: '79px', height: '18px', lineHeight: '18px', zIndex: 326}}>F2</label>
          <label htmlFor id="Label40" style={{position: 'absolute', left: '1052px', top: '1037px', width: '79px', height: '18px', lineHeight: '18px', zIndex: 327}}>GENERÓ</label>
          <label htmlFor id="Label41" style={{position: 'absolute', left: '1153px', top: '1037px', width: '79px', height: '18px', lineHeight: '18px', zIndex: 328}}>F2</label>
          <div id="Tabs1" style={{position: 'absolute', left: '154px', top: '1087px', width: '1114px', height: '554px', zIndex: 329}}>
            <ul>
              <li><a href="#tabs1-page-0"><span>MICROBIOLOGICO</span></a></li>
              <li><a href="#tabs1-page-1"><span>FISICO-QUIMICO</span></a></li>
              <li><a href="#tabs1-page-2"><span>METALES PESADOS</span></a></li>
            </ul>
            <div style={{height: '528px'}} id="tabs1-page-0">
              <label htmlFor id="Label42" style={{position: 'absolute', left: '18px', top: '18px', width: '81px', height: '20px', lineHeight: '20px', zIndex: 0}}>Muestra No.</label>
              <label htmlFor id="Label43" style={{position: 'absolute', left: '123px', top: '18px', width: '81px', height: '20px', lineHeight: '20px', zIndex: 1}}>Muestra No.</label>
              <label htmlFor id="Label45" style={{position: 'absolute', left: '14px', top: '45px', width: '151px', height: '20px', lineHeight: '20px', zIndex: 2}}>Fechas de Ensayo  Del</label>
              <input type="text" id="Editbox17" style={{position: 'absolute', left: '188px', top: '47px', width: '109px', height: '16px', zIndex: 3}} name="Editbox1" defaultValue spellCheck="false" />
              <label htmlFor id="Label46" style={{position: 'absolute', left: '325px', top: '46px', width: '18px', height: '20px', lineHeight: '20px', zIndex: 4}}>Al</label>
              <input type="text" id="Editbox18" style={{position: 'absolute', left: '361px', top: '47px', width: '109px', height: '16px', zIndex: 5}} name="Editbox1" defaultValue spellCheck="false" />
              <div id="wb_Line11" style={{position: 'absolute', left: '15px', top: '84px', width: '1062px', height: '2px', zIndex: 6}}>
                <img src="images/img0006.png" id="Line11" alt="" /></div>
              <label htmlFor id="Label47" style={{position: 'absolute', left: '432px', top: '18px', width: '81px', height: '20px', lineHeight: '20px', zIndex: 7}}>tmuest</label>
              <label htmlFor id="Label48" style={{position: 'absolute', left: '24px', top: '88px', width: '151px', height: '20px', lineHeight: '20px', zIndex: 8}}>Determinacion</label>
              <label htmlFor id="Label49" style={{position: 'absolute', left: '25px', top: '114px', width: '269px', height: '20px', lineHeight: '20px', zIndex: 9}}>Mesofilicos aerobicos en placa UFC/g o ml</label>
              <label htmlFor id="Label50" style={{position: 'absolute', left: '25px', top: '147px', width: '269px', height: '20px', lineHeight: '20px', zIndex: 10}}>Mesofilicos aerobios en placa UFC</label>
              <label htmlFor id="Label51" style={{position: 'absolute', left: '25px', top: '180px', width: '269px', height: '20px', lineHeight: '20px', zIndex: 11}}>Organismos coliformes totales UFC/g o ml</label>
              <label htmlFor id="Label52" style={{position: 'absolute', left: '25px', top: '212px', width: '269px', height: '20px', lineHeight: '20px', zIndex: 12}}>Organismos coliformes totales UFC</label>
              <label htmlFor id="Label53" style={{position: 'absolute', left: '24px', top: '243px', width: '269px', height: '20px', lineHeight: '20px', zIndex: 13}}>Organismos coliformes totales NMP/g o ml</label>
              <label htmlFor id="Label54" style={{position: 'absolute', left: '24px', top: '272px', width: '269px', height: '20px', lineHeight: '20px', zIndex: 14}}>Organismos coliformes totales NMP/100 ml</label>
              <label htmlFor id="Label55" style={{position: 'absolute', left: '24px', top: '302px', width: '269px', height: '20px', lineHeight: '20px', zIndex: 15}}>Organismos coliformes fecales NMP/g o ml</label>
              <label htmlFor id="Label56" style={{position: 'absolute', left: '24px', top: '331px', width: '269px', height: '20px', lineHeight: '20px', zIndex: 16}}>Organismos coliformes fecales NMP/100 o ml</label>
              <label htmlFor id="Label57" style={{position: 'absolute', left: '24px', top: '361px', width: '269px', height: '20px', lineHeight: '20px', zIndex: 17}}>Inhibidore bacterianos (cualitativo)</label>
              <label htmlFor id="Label58" style={{position: 'absolute', left: '24px', top: '391px', width: '269px', height: '20px', lineHeight: '20px', zIndex: 18}}>Esterococos NMP/100 ml</label>
              <label htmlFor id="Label59" style={{position: 'absolute', left: '24px', top: '420px', width: '269px', height: '20px', lineHeight: '20px', zIndex: 19}}>Hongos UFC/g o ml</label>
              <label htmlFor id="Label44" style={{position: 'absolute', left: '24px', top: '449px', width: '212px', height: '20px', lineHeight: '20px', zIndex: 20}}>Levaduras UFC/g o ml</label>
              <input type="text" id="Editbox19" style={{position: 'absolute', left: '340px', top: '116px', width: '180px', height: '16px', zIndex: 21}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox20" style={{position: 'absolute', left: '340px', top: '149px', width: '180px', height: '16px', zIndex: 22}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox21" style={{position: 'absolute', left: '340px', top: '182px', width: '180px', height: '16px', zIndex: 23}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox22" style={{position: 'absolute', left: '340px', top: '214px', width: '180px', height: '16px', zIndex: 24}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox23" style={{position: 'absolute', left: '339px', top: '245px', width: '180px', height: '16px', zIndex: 25}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox24" style={{position: 'absolute', left: '339px', top: '274px', width: '180px', height: '16px', zIndex: 26}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox25" style={{position: 'absolute', left: '339px', top: '304px', width: '180px', height: '16px', zIndex: 27}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox26" style={{position: 'absolute', left: '339px', top: '333px', width: '180px', height: '16px', zIndex: 28}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox27" style={{position: 'absolute', left: '339px', top: '363px', width: '180px', height: '16px', zIndex: 29}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox28" style={{position: 'absolute', left: '339px', top: '393px', width: '180px', height: '16px', zIndex: 30}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox29" style={{position: 'absolute', left: '339px', top: '422px', width: '180px', height: '16px', zIndex: 31}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox30" style={{position: 'absolute', left: '339px', top: '451px', width: '180px', height: '16px', zIndex: 32}} name="Editbox1" defaultValue spellCheck="false" />
              <div id="wb_Checkbox1" style={{position: 'absolute', left: '546px', top: '120px', width: '19px', height: '19px', zIndex: 33}}>
                <input type="checkbox" id="Checkbox1" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox1" /></div>
              <div id="wb_Checkbox2" style={{position: 'absolute', left: '546px', top: '153px', width: '19px', height: '19px', zIndex: 34}}>
                <input type="checkbox" id="Checkbox2" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox2" /></div>
              <div id="wb_Checkbox3" style={{position: 'absolute', left: '546px', top: '186px', width: '19px', height: '19px', zIndex: 35}}>
                <input type="checkbox" id="Checkbox3" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox3" /></div>
              <div id="wb_Checkbox4" style={{position: 'absolute', left: '545px', top: '218px', width: '19px', height: '19px', zIndex: 36}}>
                <input type="checkbox" id="Checkbox4" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox4" /></div>
              <div id="wb_Checkbox5" style={{position: 'absolute', left: '545px', top: '249px', width: '19px', height: '19px', zIndex: 37}}>
                <input type="checkbox" id="Checkbox5" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox5" /></div>
              <div id="wb_Checkbox6" style={{position: 'absolute', left: '545px', top: '278px', width: '19px', height: '19px', zIndex: 38}}>
                <input type="checkbox" id="Checkbox6" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox6" /></div>
              <div id="wb_Checkbox8" style={{position: 'absolute', left: '546px', top: '337px', width: '19px', height: '19px', zIndex: 39}}>
                <input type="checkbox" id="Checkbox8" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox8" /></div>
              <div id="wb_Checkbox9" style={{position: 'absolute', left: '545px', top: '367px', width: '19px', height: '19px', zIndex: 40}}>
                <input type="checkbox" id="Checkbox9" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox9" /></div>
              <div id="wb_Checkbox10" style={{position: 'absolute', left: '545px', top: '397px', width: '19px', height: '19px', zIndex: 41}}>
                <input type="checkbox" id="Checkbox10" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox10" /></div>
              <div id="wb_Checkbox11" style={{position: 'absolute', left: '545px', top: '426px', width: '19px', height: '19px', zIndex: 42}}>
                <input type="checkbox" id="Checkbox11" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox11" /></div>
              <div id="wb_Checkbox12" style={{position: 'absolute', left: '545px', top: '455px', width: '19px', height: '19px', zIndex: 43}}>
                <input type="checkbox" id="Checkbox12" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox12" /></div>
              <div id="wb_Checkbox7" style={{position: 'absolute', left: '545px', top: '308px', width: '19px', height: '19px', zIndex: 44}}>
                <input type="checkbox" id="Checkbox7" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox7" /></div>
              <label htmlFor id="Label61" style={{position: 'absolute', left: '341px', top: '88px', width: '151px', height: '20px', lineHeight: '20px', zIndex: 45}}>Resultado</label>
              <label htmlFor id="Label62" style={{position: 'absolute', left: '537px', top: '88px', width: '32px', height: '20px', lineHeight: '20px', zIndex: 46}}>FN</label>
              <label htmlFor id="Label63" style={{position: 'absolute', left: '598px', top: '88px', width: '151px', height: '20px', lineHeight: '20px', zIndex: 47}}>Determinacion</label>
              <label htmlFor id="Label64" style={{position: 'absolute', left: '834px', top: '88px', width: '151px', height: '20px', lineHeight: '20px', zIndex: 48}}>Resultado</label>
              <label htmlFor id="Label66" style={{position: 'absolute', left: '612px', top: '115px', width: '122px', height: '20px', lineHeight: '20px', zIndex: 49}}>E.coli NMP/g o ml</label>
              <label htmlFor id="Label67" style={{position: 'absolute', left: '612px', top: '148px', width: '131px', height: '20px', lineHeight: '20px', zIndex: 50}}>E. coli NMP 100/ ml</label>
              <label htmlFor id="Label68" style={{position: 'absolute', left: '612px', top: '181px', width: '182px', height: '20px', lineHeight: '20px', zIndex: 51}}>Salmonela spp en X g o ml</label>
              <label htmlFor id="Label69" style={{position: 'absolute', left: '612px', top: '213px', width: '182px', height: '20px', lineHeight: '20px', zIndex: 52}}>Salmolella soo en 25g o ml</label>
              <label htmlFor id="Label70" style={{position: 'absolute', left: '612px', top: '244px', width: '170px', height: '20px', lineHeight: '20px', zIndex: 53}}>Salmolella soo eb 1000 ml</label>
              <label htmlFor id="Label71" style={{position: 'absolute', left: '612px', top: '273px', width: '142px', height: '20px', lineHeight: '20px', zIndex: 54}}>S. aureus UFC/g o ml</label>
              <label htmlFor id="Label72" style={{position: 'absolute', left: '612px', top: '303px', width: '123px', height: '20px', lineHeight: '20px', zIndex: 55}}>Vibrio cholerae O1</label>
              <label htmlFor id="Label73" style={{position: 'absolute', left: '612px', top: '332px', width: '142px', height: '20px', lineHeight: '20px', zIndex: 56}}>Vibio holrtsr NO O1</label>
              <label htmlFor id="Label74" style={{position: 'absolute', left: '612px', top: '362px', width: '157px', height: '20px', lineHeight: '20px', zIndex: 57}}>Vibrio parahaemolyticus</label>
              <label htmlFor id="Label75" style={{position: 'absolute', left: '612px', top: '392px', width: '189px', height: '20px', lineHeight: '20px', zIndex: 58}}>Vibtrio parahaemolyticus NMP</label>
              <input type="text" id="Editbox45" style={{position: 'absolute', left: '831px', top: '116px', width: '180px', height: '16px', zIndex: 59}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox46" style={{position: 'absolute', left: '831px', top: '149px', width: '50px', height: '16px', zIndex: 60}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox47" style={{position: 'absolute', left: '831px', top: '182px', width: '180px', height: '16px', zIndex: 61}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox49" style={{position: 'absolute', left: '831px', top: '245px', width: '180px', height: '16px', zIndex: 62}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox53" style={{position: 'absolute', left: '831px', top: '363px', width: '180px', height: '16px', zIndex: 63}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox54" style={{position: 'absolute', left: '831px', top: '393px', width: '180px', height: '16px', zIndex: 64}} name="Editbox1" defaultValue spellCheck="false" />
              <label htmlFor id="Label76" style={{position: 'absolute', left: '612px', top: '421px', width: '189px', height: '20px', lineHeight: '20px', zIndex: 65}}>Enterotoxina estafilococcica</label>
              <input type="text" id="Editbox55" style={{position: 'absolute', left: '831px', top: '422px', width: '180px', height: '16px', zIndex: 66}} name="Editbox1" defaultValue spellCheck="false" />
              <div id="wb_Checkbox16" style={{position: 'absolute', left: '1062px', top: '218px', width: '19px', height: '19px', zIndex: 67}}>
                <input type="checkbox" id="Checkbox16" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox16" /></div>
              <div id="wb_Checkbox17" style={{position: 'absolute', left: '1062px', top: '249px', width: '19px', height: '19px', zIndex: 68}}>
                <input type="checkbox" id="Checkbox17" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox17" /></div>
              <div id="wb_Checkbox18" style={{position: 'absolute', left: '1061px', top: '278px', width: '19px', height: '19px', zIndex: 69}}>
                <input type="checkbox" id="Checkbox18" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox18" /></div>
              <div id="wb_Checkbox19" style={{position: 'absolute', left: '1062px', top: '308px', width: '19px', height: '19px', zIndex: 70}}>
                <input type="checkbox" id="Checkbox19" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox19" /></div>
              <div id="wb_Checkbox20" style={{position: 'absolute', left: '1063px', top: '337px', width: '19px', height: '19px', zIndex: 71}}>
                <input type="checkbox" id="Checkbox20" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox20" /></div>
              <div id="wb_Checkbox21" style={{position: 'absolute', left: '1062px', top: '367px', width: '19px', height: '19px', zIndex: 72}}>
                <input type="checkbox" id="Checkbox21" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox21" /></div>
              <div id="wb_Checkbox22" style={{position: 'absolute', left: '1062px', top: '397px', width: '19px', height: '19px', zIndex: 73}}>
                <input type="checkbox" id="Checkbox22" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox22" /></div>
              <div id="wb_Checkbox23" style={{position: 'absolute', left: '1062px', top: '426px', width: '19px', height: '19px', zIndex: 74}}>
                <input type="checkbox" id="Checkbox23" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox23" /></div>
              <div id="wb_Checkbox13" style={{position: 'absolute', left: '1063px', top: '120px', width: '19px', height: '19px', zIndex: 75}}>
                <input type="checkbox" id="Checkbox13" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox13" /></div>
              <div id="wb_Checkbox14" style={{position: 'absolute', left: '1062px', top: '153px', width: '19px', height: '19px', zIndex: 76}}>
                <input type="checkbox" id="Checkbox14" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox14" /></div>
              <div id="wb_Checkbox15" style={{position: 'absolute', left: '1063px', top: '186px', width: '19px', height: '19px', zIndex: 77}}>
                <input type="checkbox" id="Checkbox15" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox15" /></div>
              <label htmlFor id="Label65" style={{position: 'absolute', left: '1057px', top: '88px', width: '32px', height: '20px', lineHeight: '20px', zIndex: 78}}>FN</label>
              <select name="Combobox1" size={1} id="Combobox1" style={{position: 'absolute', left: '902px', top: '148px', width: '119px', height: '28px', zIndex: 79}}>
                <option value />
                <option value="AUCENCIA">AUSENCIA</option>
                <option value="PRESENCIA">PRESENCIA</option>
              </select>
              <input type="text" id="Editbox48" style={{position: 'absolute', left: '831px', top: '214px', width: '50px', height: '16px', zIndex: 80}} name="Editbox1" defaultValue spellCheck="false" />
              <select name="Combobox1" size={1} id="Combobox2" style={{position: 'absolute', left: '902px', top: '213px', width: '119px', height: '28px', zIndex: 81}}>
                <option value />
                <option value="AUCENCIA">AUSENCIA</option>
                <option value="PRESENCIA">PRESENCIA</option>
              </select>
              <input type="text" id="Editbox50" style={{position: 'absolute', left: '831px', top: '274px', width: '50px', height: '16px', zIndex: 82}} name="Editbox1" defaultValue spellCheck="false" />
              <select name="Combobox1" size={1} id="Combobox3" style={{position: 'absolute', left: '902px', top: '273px', width: '119px', height: '28px', zIndex: 83}}>
                <option value />
                <option value="AUCENCIA">AUSENCIA</option>
                <option value="PRESENCIA">PRESENCIA</option>
              </select>
              <input type="text" id="Editbox51" style={{position: 'absolute', left: '831px', top: '304px', width: '50px', height: '16px', zIndex: 84}} name="Editbox1" defaultValue spellCheck="false" />
              <select name="Combobox1" size={1} id="Combobox4" style={{position: 'absolute', left: '902px', top: '303px', width: '119px', height: '28px', zIndex: 85}}>
                <option value />
                <option value="AUCENCIA">AUSENCIA</option>
                <option value="PRESENCIA">PRESENCIA</option>
              </select>
              <input type="text" id="Editbox52" style={{position: 'absolute', left: '831px', top: '333px', width: '50px', height: '16px', zIndex: 86}} name="Editbox1" defaultValue spellCheck="false" />
              <select name="Combobox1" size={1} id="Combobox5" style={{position: 'absolute', left: '902px', top: '332px', width: '119px', height: '28px', zIndex: 87}}>
                <option value />
                <option value="AUCENCIA">AUSENCIA</option>
                <option value="PRESENCIA">PRESENCIA</option>
              </select>
            </div>
            <div style={{height: '528px'}} id="tabs1-page-1">
              <label htmlFor id="Label60" style={{position: 'absolute', left: '26px', top: '19px', width: '81px', height: '20px', lineHeight: '20px', zIndex: 88}}>Muestra No.</label>
              <label htmlFor id="Label77" style={{position: 'absolute', left: '131px', top: '19px', width: '81px', height: '20px', lineHeight: '20px', zIndex: 89}}>Muestra No.</label>
              <label htmlFor id="Label78" style={{position: 'absolute', left: '440px', top: '19px', width: '81px', height: '20px', lineHeight: '20px', zIndex: 90}}>tmuest</label>
              <input type="text" id="Editbox56" style={{position: 'absolute', left: '369px', top: '48px', width: '109px', height: '16px', zIndex: 91}} name="Editbox1" defaultValue spellCheck="false" />
              <label htmlFor id="Label79" style={{position: 'absolute', left: '333px', top: '47px', width: '18px', height: '20px', lineHeight: '20px', zIndex: 92}}>Al</label>
              <input type="text" id="Editbox57" style={{position: 'absolute', left: '196px', top: '48px', width: '109px', height: '16px', zIndex: 93}} name="Editbox1" defaultValue spellCheck="false" />
              <label htmlFor id="Label80" style={{position: 'absolute', left: '22px', top: '46px', width: '151px', height: '20px', lineHeight: '20px', zIndex: 94}}>Fechas de Ensayo  Del</label>
              <div id="wb_Line12" style={{position: 'absolute', left: '15px', top: '84px', width: '1062px', height: '2px', zIndex: 95}}>
                <img src="images/img0007.png" id="Line12" alt="" /></div>
              <label htmlFor id="Label81" style={{position: 'absolute', left: '309px', top: '18px', width: '81px', height: '20px', lineHeight: '20px', zIndex: 96}}>tmuest</label>
              <label htmlFor id="Label82" style={{position: 'absolute', left: '23px', top: '88px', width: '151px', height: '20px', lineHeight: '20px', zIndex: 97}}>Determinacion</label>
              <label htmlFor id="Label83" style={{position: 'absolute', left: '24px', top: '114px', width: '269px', height: '20px', lineHeight: '20px', zIndex: 98}}>Humedad %</label>
              <label htmlFor id="Label84" style={{position: 'absolute', left: '24px', top: '147px', width: '269px', height: '20px', lineHeight: '20px', zIndex: 99}}>Fluor (F-) mg/kg</label>
              <label htmlFor id="Label85" style={{position: 'absolute', left: '24px', top: '180px', width: '269px', height: '20px', lineHeight: '20px', zIndex: 100}}>Nitritos ppm (NaNO2)</label>
              <label htmlFor id="Label86" style={{position: 'absolute', left: '24px', top: '212px', width: '269px', height: '20px', lineHeight: '20px', zIndex: 101}}>Fecula % (almidon) Cualitativa</label>
              <label htmlFor id="Label87" style={{position: 'absolute', left: '23px', top: '243px', width: '269px', height: '20px', lineHeight: '20px', zIndex: 102}}>Derivados clorados (cualitativo)</label>
              <label htmlFor id="Label88" style={{position: 'absolute', left: '23px', top: '272px', width: '269px', height: '20px', lineHeight: '20px', zIndex: 103}}>Yodato de Potasio (KIO3) mg/kg</label>
              <label htmlFor id="Label89" style={{position: 'absolute', left: '23px', top: '302px', width: '269px', height: '20px', lineHeight: '20px', zIndex: 104}}>PH/t C (en unidades de pH)</label>
              <label htmlFor id="Label90" style={{position: 'absolute', left: '23px', top: '331px', width: '35px', height: '20px', lineHeight: '20px', zIndex: 105}}>Olor</label>
              <label htmlFor id="Label91" style={{position: 'absolute', left: '23px', top: '361px', width: '269px', height: '20px', lineHeight: '20px', zIndex: 106}}>Color unidades de color verdadero</label>
              <label htmlFor id="Label92" style={{position: 'absolute', left: '23px', top: '391px', width: '269px', height: '20px', lineHeight: '20px', zIndex: 107}}>Cloro residual libre Semicuant. DPD</label>
              <label htmlFor id="Label93" style={{position: 'absolute', left: '23px', top: '419px', width: '269px', height: '20px', lineHeight: '20px', zIndex: 108}}>Cloruros mg/I (CI")</label>
              <label htmlFor id="Label94" style={{position: 'absolute', left: '23px', top: '449px', width: '212px', height: '20px', lineHeight: '20px', zIndex: 109}}>Oxidantes (cualitativo)</label>
              <input type="text" id="Editbox58" style={{position: 'absolute', left: '334px', top: '116px', width: '180px', height: '16px', zIndex: 110}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox59" style={{position: 'absolute', left: '334px', top: '147px', width: '180px', height: '16px', zIndex: 111}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox60" style={{position: 'absolute', left: '334px', top: '180px', width: '180px', height: '16px', zIndex: 112}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox61" style={{position: 'absolute', left: '334px', top: '212px', width: '180px', height: '16px', zIndex: 113}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox62" style={{position: 'absolute', left: '333px', top: '243px', width: '180px', height: '16px', zIndex: 114}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox63" style={{position: 'absolute', left: '333px', top: '272px', width: '180px', height: '16px', zIndex: 115}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox64" style={{position: 'absolute', left: '333px', top: '302px', width: '180px', height: '16px', zIndex: 116}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox65" style={{position: 'absolute', left: '333px', top: '331px', width: '180px', height: '16px', zIndex: 117}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox66" style={{position: 'absolute', left: '333px', top: '361px', width: '180px', height: '16px', zIndex: 118}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox67" style={{position: 'absolute', left: '333px', top: '391px', width: '180px', height: '16px', zIndex: 119}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox68" style={{position: 'absolute', left: '333px', top: '420px', width: '180px', height: '16px', zIndex: 120}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox69" style={{position: 'absolute', left: '333px', top: '449px', width: '180px', height: '16px', zIndex: 121}} name="Editbox1" defaultValue spellCheck="false" />
              <label htmlFor id="Label95" style={{position: 'absolute', left: '340px', top: '88px', width: '151px', height: '20px', lineHeight: '20px', zIndex: 122}}>Resultado</label>
              <label htmlFor id="Label96" style={{position: 'absolute', left: '534px', top: '88px', width: '32px', height: '20px', lineHeight: '20px', zIndex: 123}}>FN</label>
              <div id="wb_Checkbox24" style={{position: 'absolute', left: '542px', top: '116px', width: '19px', height: '19px', zIndex: 124}}>
                <input type="checkbox" id="Checkbox24" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox24" /></div>
              <div id="wb_Checkbox25" style={{position: 'absolute', left: '542px', top: '149px', width: '19px', height: '19px', zIndex: 125}}>
                <input type="checkbox" id="Checkbox25" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox25" /></div>
              <div id="wb_Checkbox26" style={{position: 'absolute', left: '542px', top: '182px', width: '19px', height: '19px', zIndex: 126}}>
                <input type="checkbox" id="Checkbox26" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox26" /></div>
              <div id="wb_Checkbox27" style={{position: 'absolute', left: '541px', top: '214px', width: '19px', height: '19px', zIndex: 127}}>
                <input type="checkbox" id="Checkbox27" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox27" /></div>
              <div id="wb_Checkbox28" style={{position: 'absolute', left: '541px', top: '245px', width: '19px', height: '19px', zIndex: 128}}>
                <input type="checkbox" id="Checkbox28" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox28" /></div>
              <div id="wb_Checkbox29" style={{position: 'absolute', left: '541px', top: '274px', width: '19px', height: '19px', zIndex: 129}}>
                <input type="checkbox" id="Checkbox29" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox29" /></div>
              <div id="wb_Checkbox30" style={{position: 'absolute', left: '541px', top: '304px', width: '19px', height: '19px', zIndex: 130}}>
                <input type="checkbox" id="Checkbox30" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox30" /></div>
              <div id="wb_Checkbox31" style={{position: 'absolute', left: '542px', top: '333px', width: '19px', height: '19px', zIndex: 131}}>
                <input type="checkbox" id="Checkbox31" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox31" /></div>
              <div id="wb_Checkbox32" style={{position: 'absolute', left: '541px', top: '363px', width: '19px', height: '19px', zIndex: 132}}>
                <input type="checkbox" id="Checkbox32" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox32" /></div>
              <div id="wb_Checkbox33" style={{position: 'absolute', left: '541px', top: '393px', width: '19px', height: '19px', zIndex: 133}}>
                <input type="checkbox" id="Checkbox33" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox33" /></div>
              <div id="wb_Checkbox34" style={{position: 'absolute', left: '541px', top: '422px', width: '19px', height: '19px', zIndex: 134}}>
                <input type="checkbox" id="Checkbox34" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox34" /></div>
              <div id="wb_Checkbox35" style={{position: 'absolute', left: '541px', top: '453px', width: '19px', height: '19px', zIndex: 135}}>
                <input type="checkbox" id="Checkbox35" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox35" /></div>
              <label htmlFor id="Label97" style={{position: 'absolute', left: '608px', top: '88px', width: '151px', height: '20px', lineHeight: '20px', zIndex: 136}}>Determinacion</label>
              <label htmlFor id="Label98" style={{position: 'absolute', left: '622px', top: '115px', width: '122px', height: '20px', lineHeight: '20px', zIndex: 137}}>E.coli NMP/g o ml</label>
              <label htmlFor id="Label99" style={{position: 'absolute', left: '622px', top: '148px', width: '131px', height: '20px', lineHeight: '20px', zIndex: 138}}>E. coli NMP 100/ ml</label>
              <label htmlFor id="Label100" style={{position: 'absolute', left: '622px', top: '181px', width: '182px', height: '20px', lineHeight: '20px', zIndex: 139}}>Salmonela spp en X g o ml</label>
              <label htmlFor id="Label101" style={{position: 'absolute', left: '622px', top: '213px', width: '182px', height: '20px', lineHeight: '20px', zIndex: 140}}>Salmolella soo en 25g o ml</label>
              <label htmlFor id="Label102" style={{position: 'absolute', left: '622px', top: '244px', width: '170px', height: '20px', lineHeight: '20px', zIndex: 141}}>Salmolella soo eb 1000 ml</label>
              <label htmlFor id="Label103" style={{position: 'absolute', left: '622px', top: '273px', width: '142px', height: '20px', lineHeight: '20px', zIndex: 142}}>S. aureus UFC/g o ml</label>
              <label htmlFor id="Label104" style={{position: 'absolute', left: '622px', top: '303px', width: '123px', height: '20px', lineHeight: '20px', zIndex: 143}}>Vibrio cholerae O1</label>
              <label htmlFor id="Label105" style={{position: 'absolute', left: '622px', top: '332px', width: '142px', height: '20px', lineHeight: '20px', zIndex: 144}}>Vibio holrtsr NO O1</label>
              <label htmlFor id="Label106" style={{position: 'absolute', left: '622px', top: '362px', width: '157px', height: '20px', lineHeight: '20px', zIndex: 145}}>Vibrio parahaemolyticus</label>
              <label htmlFor id="Label107" style={{position: 'absolute', left: '622px', top: '392px', width: '189px', height: '20px', lineHeight: '20px', zIndex: 146}}>Vibtrio parahaemolyticus NMP</label>
              <label htmlFor id="Label108" style={{position: 'absolute', left: '1041px', top: '91px', width: '32px', height: '20px', lineHeight: '20px', zIndex: 147}}>FN</label>
              <div id="wb_Checkbox36" style={{position: 'absolute', left: '1047px', top: '123px', width: '19px', height: '19px', zIndex: 148}}>
                <input type="checkbox" id="Checkbox36" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox36" /></div>
              <div id="wb_Checkbox37" style={{position: 'absolute', left: '1046px', top: '156px', width: '19px', height: '19px', zIndex: 149}}>
                <input type="checkbox" id="Checkbox37" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox37" /></div>
              <div id="wb_Checkbox38" style={{position: 'absolute', left: '1047px', top: '189px', width: '19px', height: '19px', zIndex: 150}}>
                <input type="checkbox" id="Checkbox38" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox38" /></div>
              <div id="wb_Checkbox39" style={{position: 'absolute', left: '1046px', top: '221px', width: '19px', height: '19px', zIndex: 151}}>
                <input type="checkbox" id="Checkbox39" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox39" /></div>
              <div id="wb_Checkbox40" style={{position: 'absolute', left: '1046px', top: '252px', width: '19px', height: '19px', zIndex: 152}}>
                <input type="checkbox" id="Checkbox40" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox40" /></div>
              <div id="wb_Checkbox41" style={{position: 'absolute', left: '1045px', top: '281px', width: '19px', height: '19px', zIndex: 153}}>
                <input type="checkbox" id="Checkbox41" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox41" /></div>
              <div id="wb_Checkbox42" style={{position: 'absolute', left: '1046px', top: '311px', width: '19px', height: '19px', zIndex: 154}}>
                <input type="checkbox" id="Checkbox42" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox42" /></div>
              <div id="wb_Checkbox43" style={{position: 'absolute', left: '1047px', top: '340px', width: '19px', height: '19px', zIndex: 155}}>
                <input type="checkbox" id="Checkbox43" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox43" /></div>
              <div id="wb_Checkbox44" style={{position: 'absolute', left: '1046px', top: '370px', width: '19px', height: '19px', zIndex: 156}}>
                <input type="checkbox" id="Checkbox44" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox44" /></div>
              <div id="wb_Checkbox45" style={{position: 'absolute', left: '1046px', top: '400px', width: '19px', height: '19px', zIndex: 157}}>
                <input type="checkbox" id="Checkbox45" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox45" /></div>
              <input type="text" id="Editbox73" style={{position: 'absolute', left: '839px', top: '338px', width: '180px', height: '16px', zIndex: 158}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox74" style={{position: 'absolute', left: '839px', top: '309px', width: '180px', height: '16px', zIndex: 159}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox75" style={{position: 'absolute', left: '839px', top: '279px', width: '180px', height: '16px', zIndex: 160}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox77" style={{position: 'absolute', left: '839px', top: '219px', width: '180px', height: '16px', zIndex: 161}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox79" style={{position: 'absolute', left: '839px', top: '154px', width: '180px', height: '16px', zIndex: 162}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox71" style={{position: 'absolute', left: '839px', top: '398px', width: '180px', height: '16px', zIndex: 163}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox76" style={{position: 'absolute', left: '839px', top: '250px', width: '180px', height: '16px', zIndex: 164}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox78" style={{position: 'absolute', left: '839px', top: '187px', width: '180px', height: '16px', zIndex: 165}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox80" style={{position: 'absolute', left: '839px', top: '121px', width: '180px', height: '16px', zIndex: 166}} name="Editbox1" defaultValue spellCheck="false" />
              <select name="Combobox1" size={1} id="Combobox6" style={{position: 'absolute', left: '839px', top: '365px', width: '190px', height: '28px', zIndex: 167}}>
                <option value />
                <option value="NO DETECTADO">NO DETECTADO</option>
                <option value="DETECTADO">DETECTADO</option>
                <option value="REACHAZADO">RECHAZADO</option>
              </select>
            </div>
            <div style={{height: '528px'}} id="tabs1-page-2">
              <label htmlFor id="Label109" style={{position: 'absolute', left: '22px', top: '20px', width: '103px', height: '16px', lineHeight: '16px', zIndex: 168}}>No. de Muestra</label>
              <label htmlFor id="Label110" style={{position: 'absolute', left: '22px', top: '44px', width: '90px', height: '16px', lineHeight: '16px', zIndex: 169}}>Tipo Muestra</label>
              <label htmlFor id="Label111" style={{position: 'absolute', left: '142px', top: '20px', width: '103px', height: '16px', lineHeight: '16px', zIndex: 170}}>VariableMuestra</label>
              <label htmlFor id="Label112" style={{position: 'absolute', left: '142px', top: '44px', width: '138px', height: '16px', lineHeight: '16px', zIndex: 171}}>VariableTIpoMuestra</label>
              <label htmlFor id="Label113" style={{position: 'absolute', left: '22px', top: '74px', width: '59px', height: '16px', lineHeight: '16px', zIndex: 172}}>Vidriado</label>
              <select name="Combobox1" size={1} id="Combobox7" style={{position: 'absolute', left: '138px', top: '72px', width: '119px', height: '28px', zIndex: 173}}>
                <option value />
                <option value="INTERNO">INTERNO</option>
                <option value="EXTERNO">EXTERNO</option>
                <option value="AMBOS">AMBOS</option>
              </select>
              <label htmlFor id="Label114" style={{position: 'absolute', left: '326px', top: '74px', width: '122px', height: '16px', lineHeight: '16px', zIndex: 174}}>Decorado Interno</label>
              <select name="Combobox1" size={1} id="Combobox8" style={{position: 'absolute', left: '458px', top: '72px', width: '119px', height: '28px', zIndex: 175}}>
                <option value />
                <option value="SI">SI</option>
                <option value="NO">NO</option>
              </select>
              <label htmlFor id="Label115" style={{position: 'absolute', left: '630px', top: '74px', width: '43px', height: '16px', lineHeight: '16px', zIndex: 176}}>Color</label>
              <input type="text" id="Editbox70" style={{position: 'absolute', left: '682px', top: '73px', width: '180px', height: '16px', zIndex: 177}} name="Editbox1" defaultValue spellCheck="false" />
              <label htmlFor id="Label116" style={{position: 'absolute', left: '22px', top: '106px', width: '189px', height: '16px', lineHeight: '16px', zIndex: 178}}>Numero de piezas analizadas</label>
              <input type="text" id="Editbox72" style={{position: 'absolute', left: '243px', top: '106px', width: '95px', height: '16px', zIndex: 179}} name="Editbox1" defaultValue spellCheck="false" />
              <label htmlFor id="Label117" style={{position: 'absolute', left: '370px', top: '106px', width: '269px', height: '16px', lineHeight: '16px', zIndex: 180}}>Volumen Interno de la pieza en milimetros</label>
              <input type="text" id="Editbox81" style={{position: 'absolute', left: '651px', top: '106px', width: '95px', height: '16px', zIndex: 181}} name="Editbox1" defaultValue spellCheck="false" />
              <label htmlFor id="Label118" style={{position: 'absolute', left: '22px', top: '138px', width: '278px', height: '16px', lineHeight: '16px', zIndex: 182}}>Volumen de la solucion usada en milimetros</label>
              <input type="text" id="Editbox82" style={{position: 'absolute', left: '162px', top: '168px', width: '95px', height: '16px', zIndex: 183}} name="Editbox1" defaultValue spellCheck="false" />
              <select name="Combobox1" size={1} id="Combobox9" style={{position: 'absolute', left: '441px', top: '136px', width: '119px', height: '28px', zIndex: 184}}>
                <option value />
                <option value="INTERNO">INTERNO</option>
                <option value="EXTERNO">EXTERNO</option>
                <option value="AMBOS">AMBOS</option>
              </select>
              <label htmlFor id="Label119" style={{position: 'absolute', left: '21px', top: '169px', width: '130px', height: '16px', lineHeight: '16px', zIndex: 185}}>Fechas del Ensayo</label>
              <label htmlFor id="Label120" style={{position: 'absolute', left: '279px', top: '169px', width: '21px', height: '16px', lineHeight: '16px', zIndex: 186}}>Al</label>
              <input type="text" id="Editbox83" style={{position: 'absolute', left: '313px', top: '168px', width: '99px', height: '16px', zIndex: 187}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox85" style={{position: 'absolute', left: '170px', top: '421px', width: '180px', height: '16px', zIndex: 188}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox86" style={{position: 'absolute', left: '170px', top: '392px', width: '180px', height: '16px', zIndex: 189}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox87" style={{position: 'absolute', left: '170px', top: '362px', width: '180px', height: '16px', zIndex: 190}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox88" style={{position: 'absolute', left: '170px', top: '332px', width: '180px', height: '16px', zIndex: 191}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox89" style={{position: 'absolute', left: '170px', top: '303px', width: '180px', height: '16px', zIndex: 192}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox90" style={{position: 'absolute', left: '170px', top: '273px', width: '180px', height: '16px', zIndex: 193}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox91" style={{position: 'absolute', left: '170px', top: '244px', width: '180px', height: '16px', zIndex: 194}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox84" style={{position: 'absolute', left: '171px', top: '451px', width: '180px', height: '16px', zIndex: 195}} name="Editbox1" defaultValue spellCheck="false" />
              <label htmlFor id="Label122" style={{position: 'absolute', left: '21px', top: '419px', width: '112px', height: '20px', lineHeight: '20px', zIndex: 196}}>CROMO (Cr) mg/l</label>
              <label htmlFor id="Label123" style={{position: 'absolute', left: '21px', top: '390px', width: '126px', height: '20px', lineHeight: '20px', zIndex: 197}}>CADMIO (Cd) mg/l</label>
              <label htmlFor id="Label124" style={{position: 'absolute', left: '21px', top: '360px', width: '112px', height: '20px', lineHeight: '20px', zIndex: 198}}>BARIO (Ba) mg/l</label>
              <label htmlFor id="Label125" style={{position: 'absolute', left: '21px', top: '330px', width: '95px', height: '20px', lineHeight: '20px', zIndex: 199}}>BORO (B) mg/l</label>
              <label htmlFor id="Label126" style={{position: 'absolute', left: '21px', top: '301px', width: '135px', height: '20px', lineHeight: '20px', zIndex: 200}}>ARSENICO (As) mg/l</label>
              <label htmlFor id="Label127" style={{position: 'absolute', left: '21px', top: '271px', width: '126px', height: '20px', lineHeight: '20px', zIndex: 201}}>ALUMINIO (Ai) mg/l</label>
              <label htmlFor id="Label128" style={{position: 'absolute', left: '21px', top: '242px', width: '103px', height: '20px', lineHeight: '20px', zIndex: 202}}>PLATA (ag) mg/l</label>
              <label htmlFor id="Label121" style={{position: 'absolute', left: '22px', top: '449px', width: '117px', height: '20px', lineHeight: '20px', zIndex: 203}}>COBRE (Cu) mg/l</label>
              <div id="wb_Checkbox47" style={{position: 'absolute', left: '380px', top: '425px', width: '19px', height: '19px', zIndex: 204}}>
                <input type="checkbox" id="Checkbox47" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox47" /></div>
              <div id="wb_Checkbox48" style={{position: 'absolute', left: '380px', top: '396px', width: '19px', height: '19px', zIndex: 205}}>
                <input type="checkbox" id="Checkbox48" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox48" /></div>
              <div id="wb_Checkbox49" style={{position: 'absolute', left: '380px', top: '366px', width: '19px', height: '19px', zIndex: 206}}>
                <input type="checkbox" id="Checkbox49" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox49" /></div>
              <div id="wb_Checkbox50" style={{position: 'absolute', left: '381px', top: '336px', width: '19px', height: '19px', zIndex: 207}}>
                <input type="checkbox" id="Checkbox50" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox50" /></div>
              <div id="wb_Checkbox51" style={{position: 'absolute', left: '380px', top: '307px', width: '19px', height: '19px', zIndex: 208}}>
                <input type="checkbox" id="Checkbox51" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox51" /></div>
              <div id="wb_Checkbox52" style={{position: 'absolute', left: '380px', top: '277px', width: '19px', height: '19px', zIndex: 209}}>
                <input type="checkbox" id="Checkbox52" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox52" /></div>
              <div id="wb_Checkbox53" style={{position: 'absolute', left: '380px', top: '248px', width: '19px', height: '19px', zIndex: 210}}>
                <input type="checkbox" id="Checkbox53" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox53" /></div>
              <div id="wb_Checkbox46" style={{position: 'absolute', left: '381px', top: '455px', width: '19px', height: '19px', zIndex: 211}}>
                <input type="checkbox" id="Checkbox46" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox46" /></div>
              <select name="Combobox1" size={1} id="Combobox10" style={{position: 'absolute', left: '421px', top: '391px', width: '119px', height: '28px', zIndex: 212}}>
                <option value />
                <option value="NO CUMPLE">CUMPLE</option>
                <option value="NO">NO</option>
              </select>
              <label htmlFor id="Label129" style={{position: 'absolute', left: '21px', top: '216px', width: '103px', height: '20px', lineHeight: '20px', zIndex: 213}}>Determinación</label>
              <label htmlFor id="Label130" style={{position: 'absolute', left: '373px', top: '216px', width: '24px', height: '20px', lineHeight: '20px', zIndex: 214}}>FN</label>
              <label htmlFor id="Label132" style={{position: 'absolute', left: '429px', top: '216px', width: '95px', height: '20px', lineHeight: '20px', zIndex: 215}}>Cumplimiento</label>
              <label htmlFor id="Label131" style={{position: 'absolute', left: '210px', top: '216px', width: '103px', height: '20px', lineHeight: '20px', zIndex: 216}}>Resultado</label>
              <label htmlFor id="Label133" style={{position: 'absolute', left: '562px', top: '213px', width: '103px', height: '20px', lineHeight: '20px', zIndex: 217}}>Determinación</label>
              <label htmlFor id="Label134" style={{position: 'absolute', left: '562px', top: '239px', width: '124px', height: '20px', lineHeight: '20px', zIndex: 218}}>FIERRO(Fe) mg/l</label>
              <label htmlFor id="Label135" style={{position: 'absolute', left: '562px', top: '268px', width: '154px', height: '20px', lineHeight: '20px', zIndex: 219}}>MANGANESO (Mn) mg/l</label>
              <label htmlFor id="Label136" style={{position: 'absolute', left: '562px', top: '298px', width: '135px', height: '20px', lineHeight: '20px', zIndex: 220}}>SODIO (na) mg/l</label>
              <label htmlFor id="Label137" style={{position: 'absolute', left: '562px', top: '327px', width: '95px', height: '20px', lineHeight: '20px', zIndex: 221}}>NIQUEL (Ni) mg/l</label>
              <label htmlFor id="Label138" style={{position: 'absolute', left: '562px', top: '357px', width: '112px', height: '20px', lineHeight: '20px', zIndex: 222}}>PLOMO (Pb) mg/l</label>
              <label htmlFor id="Label139" style={{position: 'absolute', left: '562px', top: '387px', width: '126px', height: '20px', lineHeight: '20px', zIndex: 223}}>SELENIO(Se) mg/l</label>
              <label htmlFor id="Label140" style={{position: 'absolute', left: '562px', top: '416px', width: '112px', height: '20px', lineHeight: '20px', zIndex: 224}}>ZINC (Zn) mg/l</label>
              <label htmlFor id="Label141" style={{position: 'absolute', left: '766px', top: '213px', width: '103px', height: '20px', lineHeight: '20px', zIndex: 225}}>Resultado</label>
              <input type="text" id="Editbox92" style={{position: 'absolute', left: '726px', top: '241px', width: '180px', height: '16px', zIndex: 226}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox93" style={{position: 'absolute', left: '726px', top: '270px', width: '180px', height: '16px', zIndex: 227}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox94" style={{position: 'absolute', left: '726px', top: '300px', width: '180px', height: '16px', zIndex: 228}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox95" style={{position: 'absolute', left: '726px', top: '329px', width: '180px', height: '16px', zIndex: 229}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox96" style={{position: 'absolute', left: '726px', top: '359px', width: '180px', height: '16px', zIndex: 230}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox97" style={{position: 'absolute', left: '726px', top: '389px', width: '180px', height: '16px', zIndex: 231}} name="Editbox1" defaultValue spellCheck="false" />
              <input type="text" id="Editbox98" style={{position: 'absolute', left: '726px', top: '418px', width: '180px', height: '16px', zIndex: 232}} name="Editbox1" defaultValue spellCheck="false" />
              <label htmlFor id="Label142" style={{position: 'absolute', left: '929px', top: '213px', width: '24px', height: '20px', lineHeight: '20px', zIndex: 233}}>FN</label>
              <div id="wb_Checkbox54" style={{position: 'absolute', left: '936px', top: '245px', width: '19px', height: '19px', zIndex: 234}}>
                <input type="checkbox" id="Checkbox54" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox54" /></div>
              <div id="wb_Checkbox55" style={{position: 'absolute', left: '936px', top: '274px', width: '19px', height: '19px', zIndex: 235}}>
                <input type="checkbox" id="Checkbox55" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox55" /></div>
              <div id="wb_Checkbox56" style={{position: 'absolute', left: '936px', top: '304px', width: '19px', height: '19px', zIndex: 236}}>
                <input type="checkbox" id="Checkbox56" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox56" /></div>
              <div id="wb_Checkbox57" style={{position: 'absolute', left: '937px', top: '333px', width: '19px', height: '19px', zIndex: 237}}>
                <input type="checkbox" id="Checkbox57" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox57" /></div>
              <div id="wb_Checkbox58" style={{position: 'absolute', left: '936px', top: '363px', width: '19px', height: '19px', zIndex: 238}}>
                <input type="checkbox" id="Checkbox58" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox58" /></div>
              <div id="wb_Checkbox59" style={{position: 'absolute', left: '936px', top: '393px', width: '19px', height: '19px', zIndex: 239}}>
                <input type="checkbox" id="Checkbox59" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox59" /></div>
              <div id="wb_Checkbox60" style={{position: 'absolute', left: '936px', top: '422px', width: '19px', height: '19px', zIndex: 240}}>
                <input type="checkbox" id="Checkbox60" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox60" /></div>
              <label htmlFor id="Label143" style={{position: 'absolute', left: '985px', top: '213px', width: '95px', height: '20px', lineHeight: '20px', zIndex: 241}}>Cumplimiento</label>
              <select name="Combobox1" size={1} id="Combobox11" style={{position: 'absolute', left: '977px', top: '388px', width: '119px', height: '28px', zIndex: 242}}>
                <option value />
                <option value="NO CUMPLE">CUMPLE</option>
                <option value="NO">NO</option>
              </select>
              <input type="submit" id="Button5" name defaultValue="Imprimir" style={{position: 'absolute', left: '486px', top: '477px', width: '144px', height: '18px', zIndex: 243}} />
            </div>
          </div>
        </div>
      );
    }
  }

  export default Ambiental;