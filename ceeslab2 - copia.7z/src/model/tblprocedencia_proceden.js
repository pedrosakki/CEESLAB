const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tblprocedencia_proceden')
var nametable = 'tblprocedencia_proceden';
var tblprocedencia_proceden = sequelize.define(nametable,{
idtblprocedencia_proceden:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


CLAPRO:  Sequelize.DECIMAL,
PROCEDEN:  Sequelize.STRING,
ABREVIA:  Sequelize.STRING,
GRUPO:  Sequelize.INTEGER,
DOMICILIO:  Sequelize.STRING,
MUNICIPIO:  Sequelize.STRING,
ESTADO:  Sequelize.STRING,
ATENCION:  Sequelize.STRING,
CARGO:  Sequelize.STRING,
ENVIO:  Sequelize.STRING,
ENV_ELEC:  Sequelize.INTEGER,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tblprocedencia_proceden;
