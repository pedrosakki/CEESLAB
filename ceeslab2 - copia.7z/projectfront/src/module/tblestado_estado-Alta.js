import React from 'react';import 'bootstrap/dist/css/bootstrap.min.css';import 'bootstrap/dist/js/bootstrap.bundle.min';import axios from 'axios';class EditComponent extends React.Component{constructor(props){super(props);this.state = {CLAEDO:"",
ESTADO:""
NOM_ABR:""
}}  return (div> <div class="form-row justify-content-center"><div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAEDO </label><input type="text" class="form-control" placeholder="CLAEDO" value={this.state.CLAEDO} onChange={(value)=> this.setState({CLAEDO:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">ESTADO </label><input type="text" class="form-control" placeholder="ESTADO" value={this.state.ESTADO} onChange={(value)=> this.setState({ESTADO:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">NOM_ABR </label><input type="text" class="form-control" placeholder="NOM_ABR" value={this.state.NOM_ABR} onChange={(value)=> this.setState({NOM_ABR:value.target.value})}/></div><button type="submit" class="btn btn-primary" onClick={()=>this.sendSave()}>Save</button></div></div>);}  sendSave(){const baseUrl = "http: //localhost:3000/R"tblestado_estado/create"const datapost = {CLAEDO: this.state.CLAEDO,
ESTADO: this.state.ESTADO
NOM_ABR: this.state.NOM_ABR
}axios.post(baseUrl,datapost)      .then(response=>{ if (response.data.success===true) {  alert(response.data.message)}else {alert(response.data.message)}}).catch(error=>{   alert("Error 34 "+error) }) }}export default EditComponent;