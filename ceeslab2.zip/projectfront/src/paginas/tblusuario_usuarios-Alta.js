import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios';
class EditComponent extends React.Component{
constructor(props){
super(props);
this.state = {
USUARIO:"",
PASSWORD:"",
ACCESO:"",
SECCION:"",
TIPO:"",
NIVEL:"",
SESION:"",
CODIGO:"",
NOMBRE:""
}
}
render(){
  return (
<div>
 <div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">USUARIO </label>
<input type="text" class="form-control" placeholder="USUARIO" value={this.state.USUARIO} onChange={(value)=> this.setState({USUARIO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">PASSWORD </label>
<input type="text" class="form-control" placeholder="PASSWORD" value={this.state.PASSWORD} onChange={(value)=> this.setState({PASSWORD:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ACCESO </label>
<input type="text" class="form-control" placeholder="ACCESO" value={this.state.ACCESO} onChange={(value)=> this.setState({ACCESO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SECCION </label>
<input type="text" class="form-control" placeholder="SECCION" value={this.state.SECCION} onChange={(value)=> this.setState({SECCION:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TIPO </label>
<input type="text" class="form-control" placeholder="TIPO" value={this.state.TIPO} onChange={(value)=> this.setState({TIPO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">NIVEL </label>
<input type="text" class="form-control" placeholder="NIVEL" value={this.state.NIVEL} onChange={(value)=> this.setState({NIVEL:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SESION </label>
<input type="text" class="form-control" placeholder="SESION" value={this.state.SESION} onChange={(value)=> this.setState({SESION:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CODIGO </label>
<input type="text" class="form-control" placeholder="CODIGO" value={this.state.CODIGO} onChange={(value)=> this.setState({CODIGO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">NOMBRE </label>
<input type="text" class="form-control" placeholder="NOMBRE" value={this.state.NOMBRE} onChange={(value)=> this.setState({NOMBRE:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendSave()}>Save</button>
</div>
</div>
);
}
  sendSave(){
const baseUrl = "http://localhost:3000/Rtblusuario_usuarios/create"
const datapost = {
USUARIO: this.state.USUARIO,
PASSWORD: this.state.PASSWORD,
ACCESO: this.state.ACCESO,
SECCION: this.state.SECCION,
TIPO: this.state.TIPO,
NIVEL: this.state.NIVEL,
SESION: this.state.SESION,
CODIGO: this.state.CODIGO,
NOMBRE: this.state.NOMBRE
}
axios.post(baseUrl,datapost)
      .then(response=>{
 if (response.data.success===true) {
  alert(response.data.message)
}
else {
alert(response.data.message)
}
}).catch(error=>{
   alert("Error 34 "+error)
 })
 }
}
export default EditComponent;
