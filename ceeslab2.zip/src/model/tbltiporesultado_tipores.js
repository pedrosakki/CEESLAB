const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tbltiporesultado_tipores')
var nametable = 'tbltiporesultado_tipores';
var tbltiporesultado_tipores = sequelize.define(nametable,{
idtbltiporesultado_tipores:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


CLARES:  Sequelize.DECIMAL,
RESULTADO:  Sequelize.STRING,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tbltiporesultado_tipores;
