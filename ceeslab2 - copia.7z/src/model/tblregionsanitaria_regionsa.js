const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tblregionsanitaria_regionsa')
var nametable = 'tblregionsanitaria_regionsa';
var tblregionsanitaria_regionsa = sequelize.define(nametable,{
idtblregionsanitaria_regionsa:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


CLAPRO:  Sequelize.DECIMAL,
CLAEDO:  Sequelize.INTEGER,
CLAREG:  Sequelize.INTEGER,
REGION:  Sequelize.STRING,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tblregionsanitaria_regionsa;
