const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tblcalidad8')
var nametable = 'tblcalidad8';
var tblcalidad8 = sequelize.define(nametable,{
idtblcalidad8:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


MUESTRA:  Sequelize.INTEGER,
CLAPRO:  Sequelize.DECIMAL,
CLAMUE:  Sequelize.DECIMAL,
RECOBODAS:  Sequelize.INTEGER,
RECHAZADAS:  Sequelize.INTEGER,
TMI:  Sequelize.INTEGER,
CRN:  Sequelize.INTEGER,
CRP:  Sequelize.INTEGER,
IPP:  Sequelize.INTEGER,
ENPROCESO:  Sequelize.INTEGER,
OBSERVA:  Sequelize.STRING,
FEC_REP:  Sequelize.DATE,
FEC_CAP:  Sequelize.DATE,
FEC_IMP:  Sequelize.DATE,
FEC_VAL:  Sequelize.DATE,
VALIDADO:  Sequelize.INTEGER,
CLACAU:  Sequelize.INTEGER,
SUPLEMENTO:  Sequelize.INTEGER,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tblcalidad8;
