const express = require('express');
const router = express.Router();
const tblcalidad9Controller = require('../Controllers/tblcalidad9Controller')


router.post('/update/:id',tblcalidad9Controller.update)
router.get('/get/:id', tblcalidad9Controller.get)
router.get('/list', tblcalidad9Controller.list);
router.post('/create', tblcalidad9Controller.create);


module.exports = router;
