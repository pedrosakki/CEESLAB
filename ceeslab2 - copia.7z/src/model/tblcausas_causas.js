const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tblcausas_causas')
var nametable = 'tblcausas_causas';
var tblcausas_causas = sequelize.define(nametable,{
idtblcausas_causas:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


CLACAU:  Sequelize.INTEGER,
CAUSA:  Sequelize.STRING,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tblcausas_causas;
