import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { Link } from "react-router-dom";
import axios from 'axios';
const url= 'http://localhost:3000/Rtbllaboratorio_institu/list';
class listComponent extends React.Component  {
constructor(props){
super(props);
this.state ={
listtbllaboratorio_institu:[]
}
}
componentDidMount(){
axios.get(url)
.then(res=>{
if(res.data.sucess){
const data = res.data.data
this.setState({listtbllaboratorio_institu:data})
}
else{
alert("Error web service")
}
})
.catch(error=>{
alert("Error Server"+error)
})
}
render()
{
    return (
      <table class="table table-hover table-striped">

        <thead class="thead-dark">

<tr>
<th scope = "col" >#</th>
<th scope ="col" >LOGO1</th>
<th scope ="col" >LOGO2</th>
<th scope ="col" >ENCAB1</th>
<th scope ="col" >ENCAB2</th>
<th scope ="col" >ENCAB3</th>
<th scope ="col" >PIE1</th>
<th scope ="col" >DIRECC</th>
<th scope ="col" >DNOMBRE</th>
<th scope ="col" >MCPUESTO</th>
<th scope ="col" >MCNOMBRE1</th>
<th scope ="col" >AMPUESTO</th>
<th scope ="col" >AMNOMBRE</th>
<th scope ="col" >CCPUESTO</th>
<th scope ="col" >CCNOMBRE</th>
<th colspan="2" >Acciones</th>
</tr>
        </thead>
<tbody>
        {this.loadFilData()}
        </tbody>
      </table>
    );
  }
loadFilData(){
return this.state.listtbllaboratorio_institu.map((data)=>{
return(
  <tr>
  <th>{data.idtbllaboratorio_institu}</th>

<td>{data.LOGO1}</td>
<td>{data.LOGO2}</td>
<td>{data.ENCAB1}</td>
<td>{data.ENCAB2}</td>
<td>{data.ENCAB3}</td>
<td>{data.PIE1}</td>
<td>{data.DIRECC}</td>
<td>{data.DNOMBRE}</td>
<td>{data.MCPUESTO}</td>
<td>{data.MCNOMBRE1}</td>
<td>{data.AMPUESTO}</td>
<td>{data.AMNOMBRE}</td>
<td>{data.CCPUESTO}</td>
<td>{data.CCNOMBRE}</td>
<td>
<Link class="btn btn-outline-info "  to={"/tbllaboratorio_instituEdit/"+data.idtbllaboratorio_institu} >Edit</Link>
</td>
<td>
  <button class="btn btn-outline-danger "> Delete </button>
</td>
</tr>
)
}
)
}
}
export default listComponent;
