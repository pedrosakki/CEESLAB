 const controllers = {}
var sequelize = require('../model/database');
var tblenvioenca_envios = require('../model/tblenvioenca_envios');

//METODO GET//

controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tblenvioenca_envios.findAll({
where: {idtblenvioenca_envios: id }  })
.then(function(data){
    return data;})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}


//METODO LIST//

controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tblenvioenca_envios.findAll();
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}



//METODO CREATE//
controllers.create = async (req, res)=>{
const  {FOL_ENV,FEC_ENV,FEC_ARC}=req.body;
const data = await tblenvioenca_envios.create({
FOL_ENV: FOL_ENV,
FEC_ENV: FEC_ENV,
FEC_ARC: FEC_ARC
}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data
})
}


//METODO UPDATE//
controllers.update = async (req, res)=>{
  const { id } = req.params;
const  {FOL_ENV,FEC_ENV,FEC_ARC}=req.body;

 const data = await tblenvioenca_envios.update({
FOL_ENV: FOL_ENV,
FEC_ENV: FEC_ENV,
FEC_ARC: FEC_ARC
   },{
          where: { idtblenvioenca_envios: id}
     })
  .then( function(data){
    return data;
      })
       .catch(error => {
        return error;
   }) 
   res.json({success:true, data:data, message:"Updated successful"});
 }



 module.exports = controllers;
