import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { Link } from "react-router-dom";
import axios from 'axios';
const url= 'http://localhost:3000/Rtblmuestra_recep/list';
class listComponent extends React.Component  {
constructor(props){
super(props);
this.state ={
listtblmuestra_recep:[]
}
}
componentDidMount(){
axios.get(url)
.then(res=>{
if(res.data.sucess){
const data = res.data.data
this.setState({listtblmuestra_recep:data})
}
else{
alert("Error web service")
}
})
.catch(error=>{
alert("Error Server"+error)
})
}
render()
{
    return (
      <table class="table table-hover table-striped">

        <thead class="thead-dark">

<tr>
<th scope = "col" >#</th>
<th scope ="col" >MUESTRA</th>
<th scope ="col" >MUESTRA2</th>
<th scope ="col" >FEC_REC</th>
<th scope ="col" >HOR_REC</th>
<th scope ="col" >CLAPRO</th>
<th scope ="col" >CLAMUE</th>
<th scope ="col" >AMPLIAR_TM</th>
<th scope ="col" >TEM_REC</th>
<th scope ="col" >CONFIRMAR</th>
<th scope ="col" >OBSERVA</th>
<th scope ="col" >AM</th>
<th scope ="col" >AF</th>
<th scope ="col" >AMP</th>
<th scope ="col" >HT</th>
<th scope ="col" >VALIDADO</th>
<th scope ="col" >MOTIVO</th>
<th scope ="col" >PRIORIDAD</th>
<th scope ="col" >E1</th>
<th scope ="col" >EXAM1</th>
<th scope ="col" >E2</th>
<th scope ="col" >EXAM2</th>
<th scope ="col" >E3</th>
<th scope ="col" >EXAM3</th>
<th scope ="col" >E4</th>
<th scope ="col" >EXAM4</th>
<th scope ="col" >E5</th>
<th scope ="col" >EXAM5</th>
<th scope ="col" >E6</th>
<th scope ="col" >EXAM6</th>
<th scope ="col" >E7</th>
<th scope ="col" >EXAM7</th>
<th scope ="col" >E8</th>
<th scope ="col" >EXAM8</th>
<th scope ="col" >E9</th>
<th scope ="col" >EXAM9</th>
<th scope ="col" >E10</th>
<th scope ="col" >EXAM10</th>
<th scope ="col" >MODIFICADO</th>
<th scope ="col" >FEC_LAB</th>
<th scope ="col" >HOR_LAB</th>
<th scope ="col" >CLAREC</th>
<th colspan="2" >Acciones</th>
</tr>
        </thead>
<tbody>
        {this.loadFilData()}
        </tbody>
      </table>
    );
  }
loadFilData(){
return this.state.listtblmuestra_recep.map((data)=>{
return(
  <tr>
  <th>{data.idtblmuestra_recep}</th>

<td>{data.MUESTRA}</td>
<td>{data.MUESTRA2}</td>
<td>{data.FEC_REC}</td>
<td>{data.HOR_REC}</td>
<td>{data.CLAPRO}</td>
<td>{data.CLAMUE}</td>
<td>{data.AMPLIAR_TM}</td>
<td>{data.TEM_REC}</td>
<td>{data.CONFIRMAR}</td>
<td>{data.OBSERVA}</td>
<td>{data.AM}</td>
<td>{data.AF}</td>
<td>{data.AMP}</td>
<td>{data.HT}</td>
<td>{data.VALIDADO}</td>
<td>{data.MOTIVO}</td>
<td>{data.PRIORIDAD}</td>
<td>{data.E1}</td>
<td>{data.EXAM1}</td>
<td>{data.E2}</td>
<td>{data.EXAM2}</td>
<td>{data.E3}</td>
<td>{data.EXAM3}</td>
<td>{data.E4}</td>
<td>{data.EXAM4}</td>
<td>{data.E5}</td>
<td>{data.EXAM5}</td>
<td>{data.E6}</td>
<td>{data.EXAM6}</td>
<td>{data.E7}</td>
<td>{data.EXAM7}</td>
<td>{data.E8}</td>
<td>{data.EXAM8}</td>
<td>{data.E9}</td>
<td>{data.EXAM9}</td>
<td>{data.E10}</td>
<td>{data.EXAM10}</td>
<td>{data.MODIFICADO}</td>
<td>{data.FEC_LAB}</td>
<td>{data.HOR_LAB}</td>
<td>{data.CLAREC}</td>
<td>
<Link class="btn btn-outline-info "  to={"/tblmuestra_recepEdit/"+data.idtblmuestra_recep} >Edit</Link>
</td>
<td>
  <button class="btn btn-outline-danger "> Delete </button>
</td>
</tr>
)
}
)
}
}
export default listComponent;
