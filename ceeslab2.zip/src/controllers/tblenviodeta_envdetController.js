 const controllers = {}
var sequelize = require('../model/database');
var tblenviodeta_envdet = require('../model/tblenviodeta_envdet');

//METODO GET//

controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tblenviodeta_envdet.findAll({
where: {idtblenviodeta_envdet: id }  })
.then(function(data){
    return data;})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}


//METODO LIST//

controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tblenviodeta_envdet.findAll();
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}



//METODO CREATE//
controllers.create = async (req, res)=>{
const  {FOL_ENV,MUESTRA,CLAPRO,USUARIO}=req.body;
const data = await tblenviodeta_envdet.create({
FOL_ENV: FOL_ENV,
MUESTRA: MUESTRA,
CLAPRO: CLAPRO,
USUARIO: USUARIO
}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data
})
}


//METODO UPDATE//
controllers.update = async (req, res)=>{
  const { id } = req.params;
const  {FOL_ENV,MUESTRA,CLAPRO,USUARIO}=req.body;

 const data = await tblenviodeta_envdet.update({
FOL_ENV: FOL_ENV,
MUESTRA: MUESTRA,
CLAPRO: CLAPRO,
USUARIO: USUARIO
   },{
          where: { idtblenviodeta_envdet: id}
     })
  .then( function(data){
    return data;
      })
       .catch(error => {
        return error;
   }) 
   res.json({success:true, data:data, message:"Updated successful"});
 }



 module.exports = controllers;
