 const controllers = {}
var sequelize = require('../model/database');
var tblmotivomuestra_motmues = require('../model/tblmotivomuestra_motmues');

//METODO GET//

controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tblmotivomuestra_motmues.findAll({
where: {idtblmotivomuestra_motmues: id }  })
.then(function(data){
    return data;})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}


//METODO LIST//

controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tblmotivomuestra_motmues.findAll();
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}



//METODO CREATE//
controllers.create = async (req, res)=>{
const  {CLAMOT,MOTIVO}=req.body;
const data = await tblmotivomuestra_motmues.create({
CLAMOT: CLAMOT,
MOTIVO: MOTIVO
}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data
})
}


//METODO UPDATE//
controllers.update = async (req, res)=>{
  const { id } = req.params;
const  {CLAMOT,MOTIVO}=req.body;

 const data = await tblmotivomuestra_motmues.update({
CLAMOT: CLAMOT,
MOTIVO: MOTIVO
   },{
          where: { idtblmotivomuestra_motmues: id}
     })
  .then( function(data){
    return data;
      })
       .catch(error => {
        return error;
   }) 
   res.json({success:true, data:data, message:"Updated successful"});
 }



 module.exports = controllers;
