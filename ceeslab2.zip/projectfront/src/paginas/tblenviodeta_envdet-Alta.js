import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios';
class EditComponent extends React.Component{
constructor(props){
super(props);
this.state = {
FOL_ENV:"",
MUESTRA:"",
CLAPRO:"",
USUARIO:""
}
}
render(){
  return (
<div>
 <div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FOL_ENV </label>
<input type="text" class="form-control" placeholder="FOL_ENV" value={this.state.FOL_ENV} onChange={(value)=> this.setState({FOL_ENV:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MUESTRA </label>
<input type="text" class="form-control" placeholder="MUESTRA" value={this.state.MUESTRA} onChange={(value)=> this.setState({MUESTRA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAPRO </label>
<input type="text" class="form-control" placeholder="CLAPRO" value={this.state.CLAPRO} onChange={(value)=> this.setState({CLAPRO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">USUARIO </label>
<input type="text" class="form-control" placeholder="USUARIO" value={this.state.USUARIO} onChange={(value)=> this.setState({USUARIO:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendSave()}>Save</button>
</div>
</div>
);
}
  sendSave(){
const baseUrl = "http://localhost:3000/Rtblenviodeta_envdet/create"
const datapost = {
FOL_ENV: this.state.FOL_ENV,
MUESTRA: this.state.MUESTRA,
CLAPRO: this.state.CLAPRO,
USUARIO: this.state.USUARIO
}
axios.post(baseUrl,datapost)
      .then(response=>{
 if (response.data.success===true) {
  alert(response.data.message)
}
else {
alert(response.data.message)
}
}).catch(error=>{
   alert("Error 34 "+error)
 })
 }
}
export default EditComponent;
