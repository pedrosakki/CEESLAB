import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios';
class EditComponent extends React.Component{
constructor(props){
super(props);
this.state = {
LOGO1:"",
LOGO2:"",
ENCAB1:"",
ENCAB2:"",
ENCAB3:"",
PIE1:"",
DIRECC:"",
DNOMBRE:"",
MCPUESTO:"",
MCNOMBRE1:"",
AMPUESTO:"",
AMNOMBRE:"",
CCPUESTO:"",
CCNOMBRE:""
}
}
render(){
  return (
<div>
 <div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">LOGO1 </label>
<input type="text" class="form-control" placeholder="LOGO1" value={this.state.LOGO1} onChange={(value)=> this.setState({LOGO1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">LOGO2 </label>
<input type="text" class="form-control" placeholder="LOGO2" value={this.state.LOGO2} onChange={(value)=> this.setState({LOGO2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ENCAB1 </label>
<input type="text" class="form-control" placeholder="ENCAB1" value={this.state.ENCAB1} onChange={(value)=> this.setState({ENCAB1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ENCAB2 </label>
<input type="text" class="form-control" placeholder="ENCAB2" value={this.state.ENCAB2} onChange={(value)=> this.setState({ENCAB2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ENCAB3 </label>
<input type="text" class="form-control" placeholder="ENCAB3" value={this.state.ENCAB3} onChange={(value)=> this.setState({ENCAB3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">PIE1 </label>
<input type="text" class="form-control" placeholder="PIE1" value={this.state.PIE1} onChange={(value)=> this.setState({PIE1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DIRECC </label>
<input type="text" class="form-control" placeholder="DIRECC" value={this.state.DIRECC} onChange={(value)=> this.setState({DIRECC:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DNOMBRE </label>
<input type="text" class="form-control" placeholder="DNOMBRE" value={this.state.DNOMBRE} onChange={(value)=> this.setState({DNOMBRE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MCPUESTO </label>
<input type="text" class="form-control" placeholder="MCPUESTO" value={this.state.MCPUESTO} onChange={(value)=> this.setState({MCPUESTO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MCNOMBRE1 </label>
<input type="text" class="form-control" placeholder="MCNOMBRE1" value={this.state.MCNOMBRE1} onChange={(value)=> this.setState({MCNOMBRE1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">AMPUESTO </label>
<input type="text" class="form-control" placeholder="AMPUESTO" value={this.state.AMPUESTO} onChange={(value)=> this.setState({AMPUESTO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">AMNOMBRE </label>
<input type="text" class="form-control" placeholder="AMNOMBRE" value={this.state.AMNOMBRE} onChange={(value)=> this.setState({AMNOMBRE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CCPUESTO </label>
<input type="text" class="form-control" placeholder="CCPUESTO" value={this.state.CCPUESTO} onChange={(value)=> this.setState({CCPUESTO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CCNOMBRE </label>
<input type="text" class="form-control" placeholder="CCNOMBRE" value={this.state.CCNOMBRE} onChange={(value)=> this.setState({CCNOMBRE:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendSave()}>Save</button>
</div>
</div>
);
}
  sendSave(){
const baseUrl = "http://localhost:3000/Rtbllaboratorio_institu/create"
const datapost = {
LOGO1: this.state.LOGO1,
LOGO2: this.state.LOGO2,
ENCAB1: this.state.ENCAB1,
ENCAB2: this.state.ENCAB2,
ENCAB3: this.state.ENCAB3,
PIE1: this.state.PIE1,
DIRECC: this.state.DIRECC,
DNOMBRE: this.state.DNOMBRE,
MCPUESTO: this.state.MCPUESTO,
MCNOMBRE1: this.state.MCNOMBRE1,
AMPUESTO: this.state.AMPUESTO,
AMNOMBRE: this.state.AMNOMBRE,
CCPUESTO: this.state.CCPUESTO,
CCNOMBRE: this.state.CCNOMBRE
}
axios.post(baseUrl,datapost)
      .then(response=>{
 if (response.data.success===true) {
  alert(response.data.message)
}
else {
alert(response.data.message)
}
}).catch(error=>{
   alert("Error 34 "+error)
 })
 }
}
export default EditComponent;
