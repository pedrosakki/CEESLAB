 const controllers = {}
var sequelize = require('../model/database');
var tblcalidad9 = require('../model/tblcalidad9');

//METODO GET//

controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tblcalidad9.findAll({
where: {idtblcalidad9: id }  })
.then(function(data){
    return data;})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}


//METODO LIST//

controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tblcalidad9.findAll();
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}



//METODO CREATE//
controllers.create = async (req, res)=>{
const  {MUESTRA,FOLIO,AFILIACION,CLAPRO,CLAEDO,CLAREG,CLADIR,CLAUNI,NOMBRES,APELLIDO_P,APELLIDO_M,FEC_NAC,EDAD,FEC_REP,RESULTADO,OBSERVA,SUPLEMENTO,FEC_TOM,ESTUDIO}=req.body;
const data = await tblcalidad9.create({
MUESTRA: MUESTRA,
FOLIO: FOLIO,
AFILIACION: AFILIACION,
CLAPRO: CLAPRO,
CLAEDO: CLAEDO,
CLAREG: CLAREG,
CLADIR: CLADIR,
CLAUNI: CLAUNI,
NOMBRES: NOMBRES,
APELLIDO_P: APELLIDO_P,
APELLIDO_M: APELLIDO_M,
FEC_NAC: FEC_NAC,
EDAD: EDAD,
FEC_REP: FEC_REP,
RESULTADO: RESULTADO,
OBSERVA: OBSERVA,
SUPLEMENTO: SUPLEMENTO,
FEC_TOM: FEC_TOM,
ESTUDIO: ESTUDIO
}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data
})
}


//METODO UPDATE//
controllers.update = async (req, res)=>{
  const { id } = req.params;
const  {MUESTRA,FOLIO,AFILIACION,CLAPRO,CLAEDO,CLAREG,CLADIR,CLAUNI,NOMBRES,APELLIDO_P,APELLIDO_M,FEC_NAC,EDAD,FEC_REP,RESULTADO,OBSERVA,SUPLEMENTO,FEC_TOM,ESTUDIO}=req.body;

 const data = await tblcalidad9.update({
MUESTRA: MUESTRA,
FOLIO: FOLIO,
AFILIACION: AFILIACION,
CLAPRO: CLAPRO,
CLAEDO: CLAEDO,
CLAREG: CLAREG,
CLADIR: CLADIR,
CLAUNI: CLAUNI,
NOMBRES: NOMBRES,
APELLIDO_P: APELLIDO_P,
APELLIDO_M: APELLIDO_M,
FEC_NAC: FEC_NAC,
EDAD: EDAD,
FEC_REP: FEC_REP,
RESULTADO: RESULTADO,
OBSERVA: OBSERVA,
SUPLEMENTO: SUPLEMENTO,
FEC_TOM: FEC_TOM,
ESTUDIO: ESTUDIO
   },{
          where: { idtblcalidad9: id}
     })
  .then( function(data){
    return data;
      })
       .catch(error => {
        return error;
   }) 
   res.json({success:true, data:data, message:"Updated successful"});
 }



 module.exports = controllers;
