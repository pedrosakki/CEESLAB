import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios';
class EditComponent extends React.Component{
constructor(props){
super(props);
this.state = {
apellidopaterno:"",
apellidomaterno:"",
idpuesto:0
}
}
 render(){
  return (
    <div>
      <div class="form-row justify-content-center">
        
        <div class="form-group col-md-6">
          <label for="inputApellidoPaterno">Apellido Paterno </label>
          <input type="text" class="form-control"  placeholder="Apellido Paterno" value={this.state.apellidopaterno} onChange={(value)=> this.setState({apellidopaterno:value.target.value})}/>
        </div>
        <div class="form-group col-md-6">
          <label for="inputApellido Materno">Apellido Materno</label>
          <input type="text" class="form-control"  placeholder="Apellido Materno" value={this.state.apellidomaterno} onChange={(value)=> this.setState({apellidomaterno:value.target.value})}/>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group col-md-6">
          <label for="inputState">Puesto</label>
          <select id="Puesto" class="form-control" onChange={(value)=> this.setState({idpuesto:value.target.value})}>
            <option selected>Choose...</option>
            <option value="1">Sistemas</option>
            <option value="2">Operaciones</option>
          </select>
        </div>
  <button type="submit" class="btn btn-primary" onClick={()=>this.sendSave()}>Save</button>
    </div>
    </div>
  );
  }
  // AQUI ME QUEDEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
  //EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
  //EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
  sendSave(){
    if (this.state.txselectidpuesto==0) {
      alert("Seleccione el puesto")
    }
    else if (this.state.txapellidopaterno=="") {
       alert("Digite el campo Apellido Paterno")
    }
    else if (this.state.txapellidomaterno=="") {
       alert("Digite el Apellido Materno")
    }
    else {
     const baseUrl = "http://localhost:3000/Empleados/create"
      const datapost = {
        apellidopaterno : this.state.apellidopaterno,
        apellidomaterno : this.state.apellidomaterno,
        idpuesto : this.state.idpuesto,
      }
      axios.post(baseUrl,datapost)
      .then(response=>{
        if (response.data.success===true) {
          alert("1"+response.data.message)
        }
        else {
          alert("2"+response.data.message)
        
        alert(JSON.stringify(response))
        }
      }).catch(error=>{
        alert("Error 34 "+error)
      })
    }
  }
}
export default EditComponent;