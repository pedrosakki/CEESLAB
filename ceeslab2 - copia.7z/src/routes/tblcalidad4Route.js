const express = require('express');
const router = express.Router();
const tblcalidad4Controller = require('../Controllers/tblcalidad4Controller')


router.post('/update/:id',tblcalidad4Controller.update)
router.get('/get/:id', tblcalidad4Controller.get)
router.get('/list', tblcalidad4Controller.list);
router.post('/create', tblcalidad4Controller.create);


module.exports = router;
