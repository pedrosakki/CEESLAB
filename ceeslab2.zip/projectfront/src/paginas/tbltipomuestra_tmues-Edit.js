import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios'
const baseUrl= "http: //localhost:3000"
class EditComponent extends React.Component{

constructor(props){

super(props);
this.state={
edittbltipomuestra_tmuess:[],
datatbltipomuestra_tmues:{},
CLAMUE: "",
T_MUES: "",
GRUPO: ""
}
}


componentDidMount(){
let userId = this.props.match.params.tbltipomuestra_tmuesid;
  const url = baseUrl+"/Rtbltipomuestra_tmues/get/"+userId

  axios.get(url)
 .then(res=>{
  if(res.data.sucess){
  const data = res.data.data[0] 
this.setState({
edittbltipomuestra_tmuess:data,
CLAMUE: data.CLAMUE,
T_MUES: data.T_MUES,
GRUPO: data.GRUPO
} ) }
else{
alert("Error web service")
} } )
  .catch(error=>{
  })
}


  render(){
   let userId = 0;
 return (
<div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAMUE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAMUE} onChange={(value)=> this.setState({CLAMUE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">T_MUES </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.T_MUES} onChange={(value)=> this.setState({T_MUES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">GRUPO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.GRUPO} onChange={(value)=> this.setState({GRUPO:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendUpdate()}>Update</button>  
</div>
); }
sendUpdate(){
let userId = this.props.match.params.tbltipomuestra_tmuesid;
const baseUrl = "http://localhost:3000/Rtbltipomuestra_tmues/Update/"+ userId
const datapost = {
CLAMUE: this.state.CLAMUE,
T_MUES: this.state.T_MUES,
GRUPO: this.state.GRUPO
}
axios.post(baseUrl,datapost)
.then(response=>{
if (response.data.success===true) {
alert(response.data.message)
}
else {
alert(response.data.message)
alert(JSON.stringify(response))
}
}).catch(error=>{
alert("Error 34 "+error)
})
}
}
export default EditComponent;
