const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tblmuestra_recep')
var nametable = 'tblmuestra_recep';

var tblmuestra_recep = sequelize.define(nametable,{
idtblmuestra_recep:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


MUESTRA:  Sequelize.INTEGER,
MUESTRA2:  Sequelize.INTEGER,
FEC_REC:  Sequelize.DATE,
HOR_REC:  Sequelize.DATE,
CLAPRO:  Sequelize.DECIMAL,
CLAMUE:  Sequelize.DECIMAL,
AMPLIAR_TM:  Sequelize.STRING,
TEM_REC:  Sequelize.STRING,
CONFIRMAR:  Sequelize.STRING,
OBSERVA:  Sequelize.STRING,
AM:  Sequelize.INTEGER,
AF:  Sequelize.INTEGER,
AMP:  Sequelize.INTEGER,
HT:  Sequelize.STRING,
VALIDADO:  Sequelize.INTEGER,
MOTIVO:  Sequelize.STRING,
PRIORIDAD:  Sequelize.STRING,
E1:  Sequelize.DECIMAL,
EXAM1:  Sequelize.STRING,
E2:  Sequelize.DECIMAL,
EXAM2:  Sequelize.STRING,
E3:  Sequelize.DECIMAL,
EXAM3:  Sequelize.STRING,
E4:  Sequelize.DECIMAL,
EXAM4:  Sequelize.STRING,
E5:  Sequelize.DECIMAL,
EXAM5:  Sequelize.STRING,
E6:  Sequelize.DECIMAL,
EXAM6:  Sequelize.STRING,
E7:  Sequelize.DECIMAL,
EXAM7:  Sequelize.STRING,
E8:  Sequelize.DECIMAL,
EXAM8:  Sequelize.STRING,
E9:  Sequelize.DECIMAL,
EXAM9:  Sequelize.STRING,
E10:  Sequelize.DECIMAL,
EXAM10:  Sequelize.STRING,
MODIFICADO:  Sequelize.INTEGER,
FEC_LAB:  Sequelize.DATE,
HOR_LAB:  Sequelize.DATE,
CLAREC:  Sequelize.STRING,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tblmuestra_recep;
