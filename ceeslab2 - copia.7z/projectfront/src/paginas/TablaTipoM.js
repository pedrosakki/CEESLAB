import React from 'react';
import MaterialTable from 'material-table';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import NotificationsIcon from '@material-ui/icons/Notifications';
import SearchIcon from '@material-ui/icons/Search';
import FirstPageIcon from '@material-ui/icons/FirstPage';
import LastPageIcon from '@material-ui/icons/LastPage';
import NavigateNextIcon from '@material-ui/icons/NavigateNext';
import NavigateBeforeIcon from '@material-ui/icons/NavigateBefore';
import ArrowDownwardIcon from '@material-ui/icons/ArrowDownward';
import ArrowUpwardIcon from '@material-ui/icons/ArrowUpward';
import Button from '@material-ui/core/Button';
import { todasReg } from './UserFunctions'
import Link from '@material-ui/core/Link';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import Typography from "@material-ui/core/Typography";
import purple from '@material-ui/core/colors/purple';
import green from '@material-ui/core/colors/green';

let direction = 'ltr';
//const column1FilterList = this.state.column1FilterList;
class TablaTipoM extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedRow: null,
      data:null
    }
  }

    render() {
    return (
        <div style={{ maxWidth: '100%', direction }}>
      <MaterialTable
      title={
          <Typography variant='h6' color='primary'>PROCEDENCIA</Typography>
      }
        columns={[

      /*    { title: 'Name',
                            field: 'location_name',
                            render: rowData =>{
                                    return(<Link to = {`/${rowData.firstname}`}>
                                    {rowData.firstname}
                                    </Link>)
                            },
                            type: 'html'
                          }*/

          { title: 'id', field: 'id',
        /* render: rowData =>{
                  return(<Link to = {'/${rowData.id}'}>
                  {rowData.id}
                  </Link>)
          },*/

          type: 'numeric',search:true},
          { title: 'nombre', field: 'nombre',search:true},
          { title: 'subregion', field: 'subregion',search:true},
          { title: 'estado', field: 'estado',search:true },
        //  { title: 'createdAt', field: 'createdAt'  },
        //  { title: 'updatedAt', field: 'updatedAt'  },
        ]}
        data={query => new Promise((resolve, reject) => {
          let url = 'http://localhost:5000/regiones/TodasReg2?'
          url += 'per_page=' + query.pageSize
          url += '&page=' + (query.page + 1)
          console.log("TipoM....");
          console.log(query);
          fetch(url)
            .then(response => response.json())
            .then(result => {
             resolve({
                data: result.data,
                search:result.search,
                page: result.page - 1,
                totalCount: result.total,
              })
            })
        })}

       onRowClick={((evt, selectedRow) => this.setState({ selectedRow }))}
        options={{
          search:true,
          headerStyle: {
           backgroundColor: '#01579b',
           color: '#FFF'
         },
         searchFieldStyle: {
            placeholder:'',
            //backgroundColor: '#EEE',
            color: '#737372'
        },
        //  exportButton: true

      //   filtering: true,

          /*rowStyle:  rowData => ({
            backgroundColor: (this.state.selectedRow && this.state.selectedRow.tableData.id === rowData.tableData.id) ? '#EEE' : '#FFF000'
          }),*/

      //  pageSize: 10,
      //  pageSizeOptions: [5, 10, 20, 30 ,50, 75, 100 ],
      //  toolbar: true,
      //  paging: true

    }}
       /*
        detailPanel={[
           {
           icon: ChevronRightIcon,
           openIcon: ChevronLeftIcon,
           tooltip: 'Ver',
           render: rowData => {
             return (
               <div
                 style={{
                   fontSize: 50,
                   textAlign: 'left',
                   color: 'white',
                   backgroundColor: '#43A047',
                 }}
               >
                 {rowData.id} {rowData.nombre} {rowData.subregion}{rowData.estado}
               </div>
             )
           }
         },
       ]} */
      /*  actions={[
         {
           icon: 'save',
           tooltip: 'Save User',
           onClick: (event, rowData) => alert("You saved " + rowData.nombre),
           hidden:'true'
         },
         {
           icon: 'delete',
           tooltip: 'Delete User',
           onClick: (event, rowData) => window.confirm("You want to delete " + rowData.id),
           //this.state.selectedRow:rowData.id;
            hidden:'true'
         },
         {
           icon: 'edit',
            hidden:'true',
           tooltip: 'a login',
           onClick: () =>
           <List>
               <ListItem button component={Link} to="/login"> </ListItem>
           </List>
          }
       ]}*/
      /*  components={{
         Action: props => (
           <Button
             onClick={(event) => props.action.onClick(event, props.data)}
             color="primary"
             variant="contained"
             style={{textTransform: 'none'}}
             size="small"
           >
             My Button
           </Button>
         ),
       }}*/
       localization={{
    /*   pagination: {
          labelRowsSelect:"Registros",
          labelRowsPerPage:"Filas por pagina"
          //labelDisplayedRows: '{from}-{to} of {count}'
        },*/
        toolbar: {
            searchPlaceholder:'buscar',
          //  nRowsSelected: '{0} row(s) selected'
        },
    /*    header: {
            actions: 'Actions'
        },*/
    /*    body: {
            emptyDataSourceMessage: 'Sin registros para cargar',
            filterRow: {
                filterTooltip: 'Filter'
            }
        }*/
    }}
      />
       </div>

    )
  }
}
export default TablaTipoM
