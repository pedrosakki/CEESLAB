import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { Link } from "react-router-dom";
import axios from 'axios';
const url= 'http://localhost:3000/Rtbltaxono/list';
class listComponent extends React.Component  {
constructor(props){
super(props);
this.state ={
listtbltaxono:[]
}
}
componentDidMount(){
axios.get(url)
.then(res=>{
if(res.data.sucess){
const data = res.data.data
this.setState({listtbltaxono:data})
}
else{
alert("Error web service")
}
})
.catch(error=>{
alert("Error Server"+error)
})
}
render()
{
    return (
      <table class="table table-hover table-striped">

        <thead class="thead-dark">

<tr>
<th scope = "col" >#</th>
<th scope ="col" >MUESTRA</th>
<th scope ="col" >C_ENVASE</th>
<th scope ="col" >ENVASE</th>
<th scope ="col" >C_ESPECIME</th>
<th scope ="col" >GENERO</th>
<th scope ="col" >ESPECIE</th>
<th scope ="col" >TOXICIDAD</th>
<th scope ="col" >VECTOR</th>
<th scope ="col" >C_VISITADA</th>
<th scope ="col" >C_POSITIVA</th>
<th scope ="col" >ICP</th>
<th scope ="col" >IIC</th>
<th scope ="col" >FEC_REP</th>
<th scope ="col" >FEC_COL</th>
<th scope ="col" >SITIO</th>
<th scope ="col" >COLECTOR</th>
<th scope ="col" >SUPLEMENTO</th>
<th scope ="col" >CLAPRO</th>
<th scope ="col" >CLAMUN</th>
<th scope ="col" >CLAEDO</th>
<th scope ="col" >OBSERV</th>
<th colspan="2" >Acciones</th>
</tr>
        </thead>
<tbody>
        {this.loadFilData()}
        </tbody>
      </table>
    );
  }
loadFilData(){
return this.state.listtbltaxono.map((data)=>{
return(
  <tr>
  <th>{data.idtbltaxono}</th>

<td>{data.MUESTRA}</td>
<td>{data.C_ENVASE}</td>
<td>{data.ENVASE}</td>
<td>{data.C_ESPECIME}</td>
<td>{data.GENERO}</td>
<td>{data.ESPECIE}</td>
<td>{data.TOXICIDAD}</td>
<td>{data.VECTOR}</td>
<td>{data.C_VISITADA}</td>
<td>{data.C_POSITIVA}</td>
<td>{data.ICP}</td>
<td>{data.IIC}</td>
<td>{data.FEC_REP}</td>
<td>{data.FEC_COL}</td>
<td>{data.SITIO}</td>
<td>{data.COLECTOR}</td>
<td>{data.SUPLEMENTO}</td>
<td>{data.CLAPRO}</td>
<td>{data.CLAMUN}</td>
<td>{data.CLAEDO}</td>
<td>{data.OBSERV}</td>
<td>
<Link class="btn btn-outline-info "  to={"/tbltaxonoEdit/"+data.idtbltaxono} >Edit</Link>
</td>
<td>
  <button class="btn btn-outline-danger "> Delete </button>
</td>
</tr>
)
}
)
}
}
export default listComponent;
