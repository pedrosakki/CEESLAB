const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tblcalidad4')
var nametable = 'tblcalidad4';
var tblcalidad4 = sequelize.define(nametable,{
idtblcalidad4:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


MUESTRA:  Sequelize.INTEGER,
CLAPRO:  Sequelize.DECIMAL,
CLAMUE:  Sequelize.DECIMAL,
OFICIO:  Sequelize.STRING,
FEC_REP:  Sequelize.DATE,
OBSERVA:  Sequelize.STRING,
CITOTECNO:  Sequelize.STRING,
TLI:  Sequelize.INTEGER,
CRN:  Sequelize.INTEGER,
CRP:  Sequelize.INTEGER,
IPD:  Sequelize.INTEGER,
EL_LPRNE:  Sequelize.INTEGER,
EL_LPRNS:  Sequelize.INTEGER,
EL_LPRT:  Sequelize.INTEGER,
EL_LPRP:  Sequelize.INTEGER,
EL_LNRNE:  Sequelize.INTEGER,
EL_LNRNS:  Sequelize.INTEGER,
EL_LNRT:  Sequelize.INTEGER,
EL_LNRP:  Sequelize.INTEGER,
EL_LIRNE:  Sequelize.INTEGER,
EL_LIRT:  Sequelize.INTEGER,
EL_LIRP:  Sequelize.INTEGER,
CD_PDN:  Sequelize.INTEGER,
CD_PDP:  Sequelize.INTEGER,
CD_PD_FPN:  Sequelize.INTEGER,
CD_PD_IN:  Sequelize.INTEGER,
CD_NDN:  Sequelize.INTEGER,
CD_NDP:  Sequelize.INTEGER,
CD_ND_FNN:  Sequelize.INTEGER,
CD_ND_IN:  Sequelize.INTEGER,
CD_FIN:  Sequelize.INTEGER,
CD_FIP:  Sequelize.INTEGER,
CD_FI_PN:  Sequelize.INTEGER,
CF_FI_PP:  Sequelize.INTEGER,
CD_FI_NN:  Sequelize.INTEGER,
CD_FI_NP:  Sequelize.INTEGER,
TOT_IN:  Sequelize.INTEGER,
TOT_IP:  Sequelize.INTEGER,
FEC_CAP:  Sequelize.DATE,
FEC_IMP:  Sequelize.DATE,
FEC_VAL:  Sequelize.DATE,
VALIDADO:  Sequelize.INTEGER,
VLAVAU:  Sequelize.INTEGER,
SUPLEMENTO:  Sequelize.INTEGER,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tblcalidad4;
