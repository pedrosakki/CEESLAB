const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tblunidad_unidad')
var nametable = 'tblunidad_unidad';
var tblunidad_unidad = sequelize.define(nametable,{
idtblunidad_unidad:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


CLAPRO:  Sequelize.DECIMAL,
CLAEDO:  Sequelize.DECIMAL,
CLAREG:  Sequelize.STRING,
CLADIR:  Sequelize.STRING,
CLAUNI:  Sequelize.STRING,
UNIDAD:  Sequelize.STRING,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tblunidad_unidad;
