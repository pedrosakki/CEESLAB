import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { Link } from "react-router-dom";
import axios from 'axios';
const url= 'http://localhost:3000/Rtblcargaviral_carvir/list';
class listComponent extends React.Component  {
constructor(props){
super(props);
this.state ={
listtblcargaviral_carvir:[]
}
}
componentDidMount(){
axios.get(url)
.then(res=>{
if(res.data.sucess){
const data = res.data.data
this.setState({listtblcargaviral_carvir:data})
}
else{
alert("Error web service")
}
})
.catch(error=>{
alert("Error Server"+error)
})
}
render()
{
    return (
      <table class="table table-hover table-striped">

        <thead class="thead-dark">

<tr>
<th scope = "col" >#</th>
<th scope ="col" >MUESTRA</th>
<th scope ="col" >ID_SALVAR</th>
<th scope ="col" >FEC_PRO</th>
<th scope ="col" >CLARES</th>
<th scope ="col" >COPIAS_ML</th>
<th scope ="col" >LOG</th>
<th scope ="col" >CD3</th>
<th scope ="col" >P_CD3</th>
<th scope ="col" >CD3_CD4</th>
<th scope ="col" >P_CD3_CD4</th>
<th scope ="col" >CD3_CD8</th>
<th scope ="col" >P_CD3_CD8</th>
<th scope ="col" >CD4_CD8</th>
<th scope ="col" >FEC_REP</th>
<th colspan="2" >Acciones</th>
</tr>
        </thead>
<tbody>
        {this.loadFilData()}
        </tbody>
      </table>
    );
  }
loadFilData(){
return this.state.listtblcargaviral_carvir.map((data)=>{
return(
  <tr>
  <th>{data.idtblcargaviral_carvir}</th>

<td>{data.MUESTRA}</td>
<td>{data.ID_SALVAR}</td>
<td>{data.FEC_PRO}</td>
<td>{data.CLARES}</td>
<td>{data.COPIAS_ML}</td>
<td>{data.LOG}</td>
<td>{data.CD3}</td>
<td>{data.P_CD3}</td>
<td>{data.CD3_CD4}</td>
<td>{data.P_CD3_CD4}</td>
<td>{data.CD3_CD8}</td>
<td>{data.P_CD3_CD8}</td>
<td>{data.CD4_CD8}</td>
<td>{data.FEC_REP}</td>
<td>
<Link class="btn btn-outline-info "  to={"/tblcargaviral_carvirEdit/"+data.idtblcargaviral_carvir} >Edit</Link>
</td>
<td>
  <button class="btn btn-outline-danger "> Delete </button>
</td>
</tr>
)
}
)
}
}
export default listComponent;
