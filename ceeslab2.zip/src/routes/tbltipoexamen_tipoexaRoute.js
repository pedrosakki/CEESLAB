const express = require('express');
const router = express.Router();
const tbltipoexamen_tipoexaController = require('../Controllers/tbltipoexamen_tipoexaController')


router.post('/update/:id',tbltipoexamen_tipoexaController.update)
router.get('/get/:id', tbltipoexamen_tipoexaController.get)
router.get('/examen/:id', tbltipoexamen_tipoexaController.examen)
router.get('/list', tbltipoexamen_tipoexaController.list);
router.post('/create', tbltipoexamen_tipoexaController.create);

router.get('/complemento/:id', tbltipoexamen_tipoexaController.complemento)


module.exports = router;
