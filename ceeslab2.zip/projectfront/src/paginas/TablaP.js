import React, { Component } from 'react'
import MaterialTable from 'material-table';

class TablaP extends Component {
  constructor() {
    super()
    this.state = {
    data:null
    }
  }

  componentWillMount() {
    this.getData();
  }
  /*
$.get("http://localhost:5000/regiones/TodasReg",function(data){
   if(this.isMounted()){
     this.setState({
           items.data
           console.console.log("esta es la data:" + data);
     });
}.bind(this));
*/
getData(){
let data=fetch('http://localhost:5000/regiones/TodasReg')
.then((res)=>{
  res.json().then((resp)=>{
    console.log("TablaP>>Datos...."+res)
    this.setState({data:resp})
  })
})
}

  render() {
    return (

       <React.Fragment>
       {
       this.state.data ?
       this.state.data.map((item)=>
             <tr>
               <td>{item.id}</td>
               <td>{item.nombre}</td>
               <td>{item.subregion}</td>
               <td>{item.estado}</td>
             </tr>
     ):
     <h3>cargando datos....</h3>
   }
    </React.Fragment>
 )
}
}
export default TablaP
