const express = require('express');
const router = express.Router();
const tblregionsanitaria_regionsaController = require('../Controllers/tblregionsanitaria_regionsaController')


router.post('/update/:id',tblregionsanitaria_regionsaController.update)
router.get('/get/:id', tblregionsanitaria_regionsaController.get)
router.get('/list', tblregionsanitaria_regionsaController.list);
router.post('/create', tblregionsanitaria_regionsaController.create);


module.exports = router;
