import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { Link } from "react-router-dom";
import axios from 'axios';
const url= 'http://localhost:3000/Rtblmotivomuestra_motmues/list';
class listComponent extends React.Component  {
constructor(props){
super(props);
this.state ={
listtblmotivomuestra_motmues:[]
}
}
componentDidMount(){
axios.get(url)
.then(res=>{
if(res.data.sucess){
const data = res.data.data
this.setState({listtblmotivomuestra_motmues:data})
}
else{
alert("Error web service")
}
})
.catch(error=>{
alert("Error Server"+error)
})
}
render()
{
    return (
      <table class="table table-hover table-striped">

        <thead class="thead-dark">

<tr>
<th scope = "col" >#</th>
<th scope ="col" >CLAMOT</th>
<th scope ="col" >MOTIVO</th>
<th colspan="2" >Acciones</th>
</tr>
        </thead>
<tbody>
        {this.loadFilData()}
        </tbody>
      </table>
    );
  }
loadFilData(){
return this.state.listtblmotivomuestra_motmues.map((data)=>{
return(
  <tr>
  <th>{data.idtblmotivomuestra_motmues}</th>

<td>{data.CLAMOT}</td>
<td>{data.MOTIVO}</td>
<td>
<Link class="btn btn-outline-info "  to={"/tblmotivomuestra_motmuesEdit/"+data.idtblmotivomuestra_motmues} >Edit</Link>
</td>
<td>
  <button class="btn btn-outline-danger "> Delete </button>
</td>
</tr>
)
}
)
}
}
export default listComponent;
