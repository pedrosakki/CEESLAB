const express = require('express');
const router = express.Router();
const tbllaboratorio_instituController = require('../Controllers/tbllaboratorio_instituController')


router.post('/update/:id',tbllaboratorio_instituController.update)
router.get('/get/:id', tbllaboratorio_instituController.get)
router.get('/list', tbllaboratorio_instituController.list);
router.post('/create', tbllaboratorio_instituController.create);


module.exports = router;
