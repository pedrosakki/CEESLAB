import React from 'react';

import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';

import axios from 'axios'

const baseUrl= "http://localhost:3000"

class EditComponent extends React.Component{
 
 constructor(props){

super(props);
this.state={

edittblempleados:[],
datatblempleado:{},
apellidopaterno:"",
apellidomaterno:"",
idpuesto:0


}
 }
 
 componentDidMount(){
  let userId = this.props.match.params.empleadoid;

  alert(JSON.stringify(userId));


  const url = baseUrl+"/Empleados/get/"+userId
  
  alert(url);
  axios.get(url)
  .then(res=>{
    if(res.data.sucess){
      const data = res.data.data[0] 
      alert(JSON.stringify(data));
      this.setState({

        edittblempleados:data,

        apellidopaterno: data.apellidopaterno,
        apellidomaterno:data.apellidomaterno,
        idpuesto:data.idpuesto
        } ) }
    else{
    alert("Error web service")
        } } )
  .catch(error=>{
    alert("Error server "+error)
  })
}
 
  render(){
   let userId = 0;
   return (

<div class="form-row justify-content-center">
    
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">Apellido Paterno </label>
<input type="text" class="form-control"  placeholder="Apellido Paterno" value={this.state.apellidopaterno} onChange={(value)=> this.setState({apellidopaterno:value.target.value})}/>
</div>

<div class="form-group col-md-6">
<label for="inputApellido Materno">Apellido Materno</label>
<input type="text" class="form-control"  placeholder="Apellido Materno" value={this.state.apellidomaterno} onChange={(value)=> this.setState({apellidomaterno:value.target.value})}/>
</div>

<div class="form-group col-md-6">
<label for="inputApellido Materno">Apellido Materno</label>
<input type="date" class="form-control"/>
</div>





<button type="submit" class="btn btn-primary" onClick={()=>this.sendUpdate()}>Update</button>  
   
</div>
);
 }
sendUpdate(){
alert("UPDATE");
let userId = this.props.match.params.empleadoid;
const baseUrl = "http://localhost:3000/Empleados/update/"+userId
const datapost = {
  apellidopaterno : this.state.apellidopaterno,
  apellidomaterno : this.state.apellidomaterno,
  idpuesto : this.state.idpuesto,
}
axios.post(baseUrl,datapost)
.then(response=>{
if (response.data.success===true) {
alert("1"+response.data.message)
}
else {
alert("2"+response.data.message)
alert(JSON.stringify(response))
}
}).catch(error=>{
alert("Error 34 "+error)
})
}
}
export default EditComponent;