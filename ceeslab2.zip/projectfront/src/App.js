import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { BrowserRouter as Router, Route, Switch, Redirect, Link, withRouter} from 'react-router-dom';

//import NavBarr2 from './paginas/navbar2';
import NavBarr from './paginas/menulateral';
import Form from './module/form';
import Edit from './module/edit';
import List from './module/list';

import permisosAlta from './paginas/permisos-Alta';
import permisosEdit from './paginas/permisos-Edit';
import permisosList from './paginas/permisos-List';
import tblcalidad1Alta from './paginas/tblcalidad1-Alta';
import tblcalidad1Edit from './paginas/tblcalidad1-Edit';
import tblcalidad1List from './paginas/tblcalidad1-List';
import tblestado_estadoAlta from './paginas/tblestado_estado-Alta';
import tblestado_estadoEdit from './paginas/tblestado_estado-Edit';
import tblestado_estadoList from './paginas/tblestado_estado-List';
import Login from './paginas/Login';
import PageError from './paginas/PageError';
import Recep2 from './paginas/Recep2';
import Recepcion from './paginas/Recepcion3';

import tblambiente_ambientAlta from './paginas/tblambiente_ambient-Alta';
import tblambiente_ambientEdit from './paginas/tblambiente_ambient-Edit';
import tblambiente_ambientList from './paginas/tblambiente_ambient-List';
import tblbmolecuAlta from './paginas/tblbmolecu-Alta';
import tblbmolecuEdit from './paginas/tblbmolecu-Edit';
import tblbmolecuList from './paginas/tblbmolecu-List';

import tblcalidad10Alta from './paginas/tblcalidad10-Alta';
import tblcalidad10Edit from './paginas/tblcalidad10-Edit';
import tblcalidad10List from './paginas/tblcalidad10-List';
import tblcalidad11Alta from './paginas/tblcalidad11-Alta';
import tblcalidad11Edit from './paginas/tblcalidad11-Edit';
import tblcalidad11List from './paginas/tblcalidad11-List';
import tblcalidad2Alta from './paginas/tblcalidad2-Alta';
import tblcalidad2Edit from './paginas/tblcalidad2-Edit';
import tblcalidad2List from './paginas/tblcalidad2-List';
import tblcalidad3Alta from './paginas/tblcalidad3-Alta';
import tblcalidad3Edit from './paginas/tblcalidad3-Edit';
import tblcalidad3List from './paginas/tblcalidad3-List';
import tblcalidad4Alta from './paginas/tblcalidad4-Alta';
import tblcalidad4Edit from './paginas/tblcalidad4-Edit';
import tblcalidad4List from './paginas/tblcalidad4-List';
import tblcalidad5Alta from './paginas/tblcalidad5-Alta';
import tblcalidad5Edit from './paginas/tblcalidad5-Edit';
import tblcalidad5List from './paginas/tblcalidad5-List';
import tblcalidad6Alta from './paginas/tblcalidad6-Alta';
import tblcalidad6Edit from './paginas/tblcalidad6-Edit';
import tblcalidad6List from './paginas/tblcalidad6-List';
import tblcalidad7Alta from './paginas/tblcalidad7-Alta';
import tblcalidad7Edit from './paginas/tblcalidad7-Edit';
import tblcalidad7List from './paginas/tblcalidad7-List';
import tblcalidad8Alta from './paginas/tblcalidad8-Alta';
import tblcalidad8Edit from './paginas/tblcalidad8-Edit';
import tblcalidad8List from './paginas/tblcalidad8-List';
import tblcalidad9Alta from './paginas/tblcalidad9-Alta';
import tblcalidad9Edit from './paginas/tblcalidad9-Edit';
import tblcalidad9List from './paginas/tblcalidad9-List';
import tblcargaviral_carvirAlta from './paginas/tblcargaviral_carvir-Alta';
import tblcargaviral_carvirEdit from './paginas/tblcargaviral_carvir-Edit';
import tblcargaviral_carvirList from './paginas/tblcargaviral_carvir-List';
import tblcausas_causasAlta from './paginas/tblcausas_causas-Alta';
import tblcausas_causasEdit from './paginas/tblcausas_causas-Edit';
import tblcausas_causasList from './paginas/tblcausas_causas-List';
import tbldireccion_direccAlta from './paginas/tbldireccion_direcc-Alta';
import tbldireccion_direccEdit from './paginas/tbldireccion_direcc-Edit';
import tbldireccion_direccList from './paginas/tbldireccion_direcc-List';
import tblenviodeta_envdetAlta from './paginas/tblenviodeta_envdet-Alta';
import tblenviodeta_envdetEdit from './paginas/tblenviodeta_envdet-Edit';
import tblenviodeta_envdetList from './paginas/tblenviodeta_envdet-List';
import tblenvioenca_enviosAlta from './paginas/tblenvioenca_envios-Alta';
import tblenvioenca_enviosEdit from './paginas/tblenvioenca_envios-Edit';
import tblenvioenca_enviosList from './paginas/tblenvioenca_envios-List';

import tbllaboratorio_instituAlta from './paginas/tbllaboratorio_institu-Alta';
import tbllaboratorio_instituEdit from './paginas/tbllaboratorio_institu-Edit';
import tbllaboratorio_instituList from './paginas/tbllaboratorio_institu-List';
import tblmicrobiologiaAlta from './paginas/tblmicrobiologia-Alta';
import tblmicrobiologiaEdit from './paginas/tblmicrobiologia-Edit';
import tblmicrobiologiaList from './paginas/tblmicrobiologia-List';
import tblmotivomuestra_motmuesAlta from './paginas/tblmotivomuestra_motmues-Alta';
import tblmotivomuestra_motmuesEdit from './paginas/tblmotivomuestra_motmues-Edit';
import tblmotivomuestra_motmuesList from './paginas/tblmotivomuestra_motmues-List';
import tblmuestra_recepAlta from './paginas/tblmuestra_recep-Alta';
import tblmuestra_recepEdit from './paginas/tblmuestra_recep-Edit';
import tblmuestra_recepList from './paginas/tblmuestra_recep-List';
import tblmunicipio_municipAlta from './paginas/tblmunicipio_municip-Alta';
import tblmunicipio_municipEdit from './paginas/tblmunicipio_municip-Edit';
import tblmunicipio_municipList from './paginas/tblmunicipio_municip-List';
import tblpermisosAlta from './paginas/tblpermisos-Alta';
import tblpermisosEdit from './paginas/tblpermisos-Edit';
import tblpermisosList from './paginas/tblpermisos-List';
import tblprocedencia_procedenAlta from './paginas/tblprocedencia_proceden-Alta';
import tblprocedencia_procedenEdit from './paginas/tblprocedencia_proceden-Edit';
import tblprocedencia_procedenList from './paginas/tblprocedencia_proceden-List';
import tblregionsanitaria_regionsaAlta from './paginas/tblregionsanitaria_regionsa-Alta';
import tblregionsanitaria_regionsaEdit from './paginas/tblregionsanitaria_regionsa-Edit';
import tblregionsanitaria_regionsaList from './paginas/tblregionsanitaria_regionsa-List';
import tbltaxonoAlta from './paginas/tbltaxono-Alta';
import tbltaxonoEdit from './paginas/tbltaxono-Edit';
import tbltaxonoList from './paginas/tbltaxono-List';
import tbltipoexamen_tipoexaAlta from './paginas/tbltipoexamen_tipoexa-Alta';
import tbltipoexamen_tipoexaEdit from './paginas/tbltipoexamen_tipoexa-Edit';
import tbltipoexamen_tipoexaList from './paginas/tbltipoexamen_tipoexa-List';
import tbltipomuestra_tmuesAlta from './paginas/tbltipomuestra_tmues-Alta';
import tbltipomuestra_tmuesEdit from './paginas/tbltipomuestra_tmues-Edit';
import tbltipomuestra_tmuesList from './paginas/tbltipomuestra_tmues-List';
import tbltiporesultado_tiporesAlta from './paginas/tbltiporesultado_tipores-Alta';
import tbltiporesultado_tiporesEdit from './paginas/tbltiporesultado_tipores-Edit';
import tbltiporesultado_tiporesList from './paginas/tbltiporesultado_tipores-List';
import tblunidad_unidadAlta from './paginas/tblunidad_unidad-Alta';
import tblunidad_unidadEdit from './paginas/tblunidad_unidad-Edit';
import tblunidad_unidadList from './paginas/tblunidad_unidad-List';
import tblusuario_usuariosAlta from './paginas/tblusuario_usuarios-Alta';
import tblusuario_usuariosEdit from './paginas/tblusuario_usuarios-Edit';
import tblusuario_usuariosList from './paginas/tblusuario_usuarios-List';
//COMPLEMENTO FRONT2

function App() {
  return (
  <Router>
    <NavBarr/>     

    <Switch>
        <Route exact path="/"  component={Login} />  
        <Route path="/list" exact component={List} />
        <Route path="/form" component={Form} />
        <Route path="/edit/:empleadoid" component={Edit} />        
        <Route path = "/permisosAlta" component={permisosAlta} />    
        <Route path = "/permisosEdit/:permisosid" component={permisosEdit} />
        <Route path = "/permisosList" exact component={permisosList}  />

        <Route path = "/tblcalidad1Alta" component={tblcalidad1Alta} />    
        <Route path = "/tblcalidad1Edit/:tblcadidad1id" component={tblcalidad1Edit} />
        <Route path = "/tblcalidad1List" exact component={tblcalidad1List}  />
        
        <Route path = "/tblestado_estadoAlta" component={tblestado_estadoAlta} />    
        <Route path = "/tblestado_estadoEdit/:tblestado_estadoid" component={tblestado_estadoEdit} />
        <Route path = "/tblestado_estadoList" exact component={tblestado_estadoList}  />

        <Route path = "/Recep2" exact component={Recep2}  />
        <Route path = "/Login" exact component={Login}  />
        <Route path = "/Recepcion" exact component={Recepcion}  />
        <Route path = "/tblambiente_ambientAlta" component={tblambiente_ambientAlta} />    
        <Route path = "/tblambiente_ambientEdit/:tblambiente_ambientid" component={tblambiente_ambientEdit} />
        <Route path = "/tblambiente_ambientList" exact component={tblambiente_ambientList}  />
        <Route path = "/tblbmolecuAlta" component={tblbmolecuAlta} />    
        <Route path = "/tblbmolecuEdit/:tblbmolecuid" component={tblbmolecuEdit} />
        <Route path = "/tblbmolecuList" exact component={tblbmolecuList}  />
        <Route path = "/tblcalidad10Alta" component={tblcalidad10Alta} />    
        <Route path = "/tblcalidad10Edit/:tblcalidad10id" component={tblcalidad10Edit} />
        <Route path = "/tblcalidad10List" exact component={tblcalidad10List}  />
        <Route path = "/tblcalidad11Alta" component={tblcalidad11Alta} />    
        <Route path = "/tblcalidad11Edit/:tblcalidad11id" component={tblcalidad11Edit} />
        <Route path = "/tblcalidad11List" exact component={tblcalidad11List}  />
        <Route path = "/tblcalidad2Alta" component={tblcalidad2Alta} />    
        <Route path = "/tblcalidad2Edit/:tblcalidad2id" component={tblcalidad2Edit} />
        <Route path = "/tblcalidad2List" exact component={tblcalidad2List}  />
        <Route path = "/tblcalidad3Alta" component={tblcalidad3Alta} />    
        <Route path = "/tblcalidad3Edit/:tblcalidad3id" component={tblcalidad3Edit} />
        <Route path = "/tblcalidad3List" exact component={tblcalidad3List}  />
        <Route path = "/tblcalidad4Alta" component={tblcalidad4Alta} />    
        <Route path = "/tblcalidad4Edit/:tblcalidad4id" component={tblcalidad4Edit} />
        <Route path = "/tblcalidad4List" exact component={tblcalidad4List}  />
        <Route path = "/tblcalidad5Alta" component={tblcalidad5Alta} />    
        <Route path = "/tblcalidad5Edit/:tblcalidad5id" component={tblcalidad5Edit} />
        <Route path = "/tblcalidad5List" exact component={tblcalidad5List}  />
        <Route path = "/tblcalidad6Alta" component={tblcalidad6Alta} />    
        <Route path = "/tblcalidad6Edit/:tblcalidad6id" component={tblcalidad6Edit} />
        <Route path = "/tblcalidad6List" exact component={tblcalidad6List}  />
        <Route path = "/tblcalidad7Alta" component={tblcalidad7Alta} />    
        <Route path = "/tblcalidad7Edit/:tblcalidad7id" component={tblcalidad7Edit} />
        <Route path = "/tblcalidad7List" exact component={tblcalidad7List}  />
        <Route path = "/tblcalidad8Alta" component={tblcalidad8Alta} />    
        <Route path = "/tblcalidad8Edit/:tblcalidad8id" component={tblcalidad8Edit} />
        <Route path = "/tblcalidad8List" exact component={tblcalidad8List}  />
        <Route path = "/tblcalidad9Alta" component={tblcalidad9Alta} />    
        <Route path = "/tblcalidad9Edit/:tblcalidad9id" component={tblcalidad9Edit} />
        <Route path = "/tblcalidad9List" exact component={tblcalidad9List}  />
        <Route path = "/tblcargaviral_carvirAlta" component={tblcargaviral_carvirAlta} />    
        <Route path = "/tblcargaviral_carvirEdit/:tblcargaviral_carvirid" component={tblcargaviral_carvirEdit} />
        <Route path = "/tblcargaviral_carvirList" exact component={tblcargaviral_carvirList}  />
        <Route path = "/tblcausas_causasAlta" component={tblcausas_causasAlta} />    
        <Route path = "/tblcausas_causasEdit/:tblcausas_causasid" component={tblcausas_causasEdit} />
        <Route path = "/tblcausas_causasList" exact component={tblcausas_causasList}  />
        <Route path = "/tbldireccion_direccAlta" component={tbldireccion_direccAlta} />    
        <Route path = "/tbldireccion_direccEdit/:tbldireccion_direccid" component={tbldireccion_direccEdit} />
        <Route path = "/tbldireccion_direccList" exact component={tbldireccion_direccList}  />
        <Route path = "/tblenviodeta_envdetAlta" component={tblenviodeta_envdetAlta} />    
        <Route path = "/tblenviodeta_envdetEdit/:tblenviodeta_envdetid" component={tblenviodeta_envdetEdit} />
        <Route path = "/tblenviodeta_envdetList" exact component={tblenviodeta_envdetList}  />
        <Route path = "/tblenvioenca_enviosAlta" component={tblenvioenca_enviosAlta} />    
        <Route path = "/tblenvioenca_enviosEdit/:tblenvioenca_enviosid" component={tblenvioenca_enviosEdit} />
        <Route path = "/tblenvioenca_enviosList" exact component={tblenvioenca_enviosList}  />
        <Route path = "/tbllaboratorio_instituAlta" component={tbllaboratorio_instituAlta} />    
        <Route path = "/tbllaboratorio_instituEdit/:tbllaboratorio_instituid" component={tbllaboratorio_instituEdit} />
        <Route path = "/tbllaboratorio_instituList" exact component={tbllaboratorio_instituList}  />
        <Route path = "/tblmicrobiologiaAlta" component={tblmicrobiologiaAlta} />    
        <Route path = "/tblmicrobiologiaEdit/:tblmicrobiologiaid" component={tblmicrobiologiaEdit} />
        <Route path = "/tblmicrobiologiaList" exact component={tblmicrobiologiaList}  />
        <Route path = "/tblmotivomuestra_motmuesAlta" component={tblmotivomuestra_motmuesAlta} />    
        <Route path = "/tblmotivomuestra_motmuesEdit/:tblmotivomuestra_motmuesid" component={tblmotivomuestra_motmuesEdit} />
        <Route path = "/tblmotivomuestra_motmuesList" exact component={tblmotivomuestra_motmuesList}  />
        <Route path = "/tblmuestra_recepAlta" component={tblmuestra_recepAlta} />    
        <Route path = "/tblmuestra_recepEdit/:tblmuestra_recepid" component={tblmuestra_recepEdit} />
        <Route path = "/tblmuestra_recepList" exact component={tblmuestra_recepList}  />
        <Route path = "/tblmunicipio_municipAlta" component={tblmunicipio_municipAlta} />    
        <Route path = "/tblmunicipio_municipEdit/:tblmunicipio_municipid" component={tblmunicipio_municipEdit} />
        <Route path = "/tblmunicipio_municipList" exact component={tblmunicipio_municipList}  />
        <Route path = "/tblpermisosAlta" component={tblpermisosAlta} />    
        <Route path = "/tblpermisosEdit/:tblpermisosid" component={tblpermisosEdit} />
        <Route path = "/tblpermisosList" exact component={tblpermisosList}  />
        <Route path = "/tblprocedencia_procedenAlta" component={tblprocedencia_procedenAlta} />    
        <Route path = "/tblprocedencia_procedenEdit/:tblprocedencia_procedenid" component={tblprocedencia_procedenEdit} />
        <Route path = "/tblprocedencia_procedenList" exact component={tblprocedencia_procedenList}  />
        <Route path = "/tblregionsanitaria_regionsaAlta" component={tblregionsanitaria_regionsaAlta} />    
        <Route path = "/tblregionsanitaria_regionsaEdit/:tblregionsanitaria_regionsaid" component={tblregionsanitaria_regionsaEdit} />
        <Route path = "/tblregionsanitaria_regionsaList" exact component={tblregionsanitaria_regionsaList}  />
        <Route path = "/tbltaxonoAlta" component={tbltaxonoAlta} />    
        <Route path = "/tbltaxonoEdit/:tbltaxonoid" component={tbltaxonoEdit} />
        <Route path = "/tbltaxonoList" exact component={tbltaxonoList}  />
        <Route path = "/tbltipoexamen_tipoexaAlta" component={tbltipoexamen_tipoexaAlta} />    
        <Route path = "/tbltipoexamen_tipoexaEdit/:tbltipoexamen_tipoexaid" component={tbltipoexamen_tipoexaEdit} />
        <Route path = "/tbltipoexamen_tipoexaList" exact component={tbltipoexamen_tipoexaList}  />
        <Route path = "/tbltipomuestra_tmuesAlta" component={tbltipomuestra_tmuesAlta} />    
        <Route path = "/tbltipomuestra_tmuesEdit/:tbltipomuestra_tmuesid" component={tbltipomuestra_tmuesEdit} />
        <Route path = "/tbltipomuestra_tmuesList" exact component={tbltipomuestra_tmuesList}  />
        <Route path = "/tbltiporesultado_tiporesAlta" component={tbltiporesultado_tiporesAlta} />    
        <Route path = "/tbltiporesultado_tiporesEdit/:tbltiporesultado_tiporesid" component={tbltiporesultado_tiporesEdit} />
        <Route path = "/tbltiporesultado_tiporesList" exact component={tbltiporesultado_tiporesList}  />
        <Route path = "/tblunidad_unidadAlta" component={tblunidad_unidadAlta} />    
        <Route path = "/tblunidad_unidadEdit/:tblunidad_unidadid" component={tblunidad_unidadEdit} />
        <Route path = "/tblunidad_unidadList" exact component={tblunidad_unidadList}  />
        <Route path = "/tblusuario_usuariosAlta" component={tblusuario_usuariosAlta} />    
        <Route path = "/tblusuario_usuariosEdit/:tblusuario_usuariosid" component={tblusuario_usuariosEdit} />
        <Route path = "/tblusuario_usuariosList" exact component={tblusuario_usuariosList}  />
        <Route component={PageError} />       

      </Switch>     
  </Router>

  );
}

export default App;

