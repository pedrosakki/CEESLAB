 const controllers = {}
var sequelize = require('../model/database');
var tblcalidad7 = require('../model/tblcalidad7');

//METODO GET//

controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tblcalidad7.findAll({
where: {idtblcalidad7: id }  })
.then(function(data){
    return data;})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}


//METODO LIST//

controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tblcalidad7.findAll();
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}



//METODO CREATE//
controllers.create = async (req, res)=>{
const  {MUESTRA,CLAPRO,CLAMUE,OFICIO,FEC_REP,OBSERVA,CITOTECNO,LR,TLI,CRN,CRP,IPD,EL_LPRNE,EL_LPRMS,EL_LPRT,EL_LPRP,EL_LNRNE,EL_LNRNS,EL_LNRT,EL_LNRP,CD_PDN,CD_PDP,CD_PD_FPN,CD_NDN,CD_NDP,CD_ND_FNN,CD_ND_IN,TOT_IN,TOT_IP,FEC_CAP,FEC_IMP,FEC_VAL,VALIDADO,CLACAU,SUPLEMENTO}=req.body;
const data = await tblcalidad7.create({
MUESTRA: MUESTRA,
CLAPRO: CLAPRO,
CLAMUE: CLAMUE,
OFICIO: OFICIO,
FEC_REP: FEC_REP,
OBSERVA: OBSERVA,
CITOTECNO: CITOTECNO,
LR: LR,
TLI: TLI,
CRN: CRN,
CRP: CRP,
IPD: IPD,
EL_LPRNE: EL_LPRNE,
EL_LPRMS: EL_LPRMS,
EL_LPRT: EL_LPRT,
EL_LPRP: EL_LPRP,
EL_LNRNE: EL_LNRNE,
EL_LNRNS: EL_LNRNS,
EL_LNRT: EL_LNRT,
EL_LNRP: EL_LNRP,
CD_PDN: CD_PDN,
CD_PDP: CD_PDP,
CD_PD_FPN: CD_PD_FPN,
CD_NDN: CD_NDN,
CD_NDP: CD_NDP,
CD_ND_FNN: CD_ND_FNN,
CD_ND_IN: CD_ND_IN,
TOT_IN: TOT_IN,
TOT_IP: TOT_IP,
FEC_CAP: FEC_CAP,
FEC_IMP: FEC_IMP,
FEC_VAL: FEC_VAL,
VALIDADO: VALIDADO,
CLACAU: CLACAU,
SUPLEMENTO: SUPLEMENTO
}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data
})
}


//METODO UPDATE//
controllers.update = async (req, res)=>{
  const { id } = req.params;
const  {MUESTRA,CLAPRO,CLAMUE,OFICIO,FEC_REP,OBSERVA,CITOTECNO,LR,TLI,CRN,CRP,IPD,EL_LPRNE,EL_LPRMS,EL_LPRT,EL_LPRP,EL_LNRNE,EL_LNRNS,EL_LNRT,EL_LNRP,CD_PDN,CD_PDP,CD_PD_FPN,CD_NDN,CD_NDP,CD_ND_FNN,CD_ND_IN,TOT_IN,TOT_IP,FEC_CAP,FEC_IMP,FEC_VAL,VALIDADO,CLACAU,SUPLEMENTO}=req.body;

 const data = await tblcalidad7.update({
MUESTRA: MUESTRA,
CLAPRO: CLAPRO,
CLAMUE: CLAMUE,
OFICIO: OFICIO,
FEC_REP: FEC_REP,
OBSERVA: OBSERVA,
CITOTECNO: CITOTECNO,
LR: LR,
TLI: TLI,
CRN: CRN,
CRP: CRP,
IPD: IPD,
EL_LPRNE: EL_LPRNE,
EL_LPRMS: EL_LPRMS,
EL_LPRT: EL_LPRT,
EL_LPRP: EL_LPRP,
EL_LNRNE: EL_LNRNE,
EL_LNRNS: EL_LNRNS,
EL_LNRT: EL_LNRT,
EL_LNRP: EL_LNRP,
CD_PDN: CD_PDN,
CD_PDP: CD_PDP,
CD_PD_FPN: CD_PD_FPN,
CD_NDN: CD_NDN,
CD_NDP: CD_NDP,
CD_ND_FNN: CD_ND_FNN,
CD_ND_IN: CD_ND_IN,
TOT_IN: TOT_IN,
TOT_IP: TOT_IP,
FEC_CAP: FEC_CAP,
FEC_IMP: FEC_IMP,
FEC_VAL: FEC_VAL,
VALIDADO: VALIDADO,
CLACAU: CLACAU,
SUPLEMENTO: SUPLEMENTO
   },{
          where: { idtblcalidad7: id}
     })
  .then( function(data){
    return data;
      })
       .catch(error => {
        return error;
   }) 
   res.json({success:true, data:data, message:"Updated successful"});
 }



 module.exports = controllers;
