const express = require('express');
const router = express.Router();
const tblcalidad10Controller = require('../Controllers/tblcalidad10Controller')


router.post('/update/:id',tblcalidad10Controller.update)
router.get('/get/:id', tblcalidad10Controller.get)
router.get('/list', tblcalidad10Controller.list);
router.post('/create', tblcalidad10Controller.create);


module.exports = router;
