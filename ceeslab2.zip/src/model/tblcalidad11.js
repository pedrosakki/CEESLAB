const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tblcalidad11')
var nametable = 'tblcalidad11';
var tblcalidad11 = sequelize.define(nametable,{
idtblcalidad11:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},


MUESTRA:  Sequelize.INTEGER,
PAQUETEVPH:  Sequelize.INTEGER,
FOLIO:  Sequelize.STRING,
AFILIACION:  Sequelize.STRING,
CLAPRO:  Sequelize.DECIMAL,
CLAEDO:  Sequelize.INTEGER,
CLAREG:  Sequelize.STRING,
CLADIR:  Sequelize.STRING,
CLAUNI:  Sequelize.STRING,
NOMBRES:  Sequelize.STRING,
APELLIDO_P:  Sequelize.STRING,
APELLIDO_M:  Sequelize.STRING,
FEC_NAC:  Sequelize.DATE,
EDAD:  Sequelize.INTEGER,
FEC_TOM:  Sequelize.DATE,
FEC_REP:  Sequelize.DATE,
NUM_LAM:  Sequelize.STRING,
FORMATO:  Sequelize.STRING,
DX_CITO:  Sequelize.STRING,
HALL_CITO:  Sequelize.STRING,
DX_PATO:  Sequelize.STRING,
HALL_PATO:  Sequelize.STRING,
RFC_CITO:  Sequelize.STRING,
RFC_PATO:  Sequelize.STRING,
REV:  Sequelize.STRING,
TUMORAL:  Sequelize.STRING,
FEC_REP_MT:  Sequelize.DATE,
RFC_PATO_M:  Sequelize.STRING,
OBSERVA:  Sequelize.STRING,
SUPLEMENTO:  Sequelize.INTEGER,
RESULTADO:  Sequelize.STRING,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tblcalidad11;
