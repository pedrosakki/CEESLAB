const express = require('express');
const router = express.Router();
const tblcalidad3Controller = require('../Controllers/tblcalidad3Controller')


router.post('/update/:id',tblcalidad3Controller.update)
router.get('/get/:id', tblcalidad3Controller.get)
router.get('/list', tblcalidad3Controller.list);
router.post('/create', tblcalidad3Controller.create);


module.exports = router;
