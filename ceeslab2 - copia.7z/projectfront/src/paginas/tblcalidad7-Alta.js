import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios';
class EditComponent extends React.Component{
constructor(props){
super(props);
this.state = {
MUESTRA:"",
CLAPRO:"",
CLAMUE:"",
OFICIO:"",
FEC_REP:"",
OBSERVA:"",
CITOTECNO:"",
LR:"",
TLI:"",
CRN:"",
CRP:"",
IPD:"",
EL_LPRNE:"",
EL_LPRMS:"",
EL_LPRT:"",
EL_LPRP:"",
EL_LNRNE:"",
EL_LNRNS:"",
EL_LNRT:"",
EL_LNRP:"",
CD_PDN:"",
CD_PDP:"",
CD_PD_FPN:"",
CD_NDN:"",
CD_NDP:"",
CD_ND_FNN:"",
CD_ND_IN:"",
TOT_IN:"",
TOT_IP:"",
FEC_CAP:"",
FEC_IMP:"",
FEC_VAL:"",
VALIDADO:"",
CLACAU:"",
SUPLEMENTO:""
}
}
render(){
  return (
<div>
 <div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MUESTRA </label>
<input type="text" class="form-control" placeholder="MUESTRA" value={this.state.MUESTRA} onChange={(value)=> this.setState({MUESTRA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAPRO </label>
<input type="text" class="form-control" placeholder="CLAPRO" value={this.state.CLAPRO} onChange={(value)=> this.setState({CLAPRO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAMUE </label>
<input type="text" class="form-control" placeholder="CLAMUE" value={this.state.CLAMUE} onChange={(value)=> this.setState({CLAMUE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OFICIO </label>
<input type="text" class="form-control" placeholder="OFICIO" value={this.state.OFICIO} onChange={(value)=> this.setState({OFICIO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_REP </label>
<input type="text" class="form-control" placeholder="FEC_REP" value={this.state.FEC_REP} onChange={(value)=> this.setState({FEC_REP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OBSERVA </label>
<input type="text" class="form-control" placeholder="OBSERVA" value={this.state.OBSERVA} onChange={(value)=> this.setState({OBSERVA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CITOTECNO </label>
<input type="text" class="form-control" placeholder="CITOTECNO" value={this.state.CITOTECNO} onChange={(value)=> this.setState({CITOTECNO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">LR </label>
<input type="text" class="form-control" placeholder="LR" value={this.state.LR} onChange={(value)=> this.setState({LR:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TLI </label>
<input type="text" class="form-control" placeholder="TLI" value={this.state.TLI} onChange={(value)=> this.setState({TLI:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CRN </label>
<input type="text" class="form-control" placeholder="CRN" value={this.state.CRN} onChange={(value)=> this.setState({CRN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CRP </label>
<input type="text" class="form-control" placeholder="CRP" value={this.state.CRP} onChange={(value)=> this.setState({CRP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">IPD </label>
<input type="text" class="form-control" placeholder="IPD" value={this.state.IPD} onChange={(value)=> this.setState({IPD:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EL_LPRNE </label>
<input type="text" class="form-control" placeholder="EL_LPRNE" value={this.state.EL_LPRNE} onChange={(value)=> this.setState({EL_LPRNE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EL_LPRMS </label>
<input type="text" class="form-control" placeholder="EL_LPRMS" value={this.state.EL_LPRMS} onChange={(value)=> this.setState({EL_LPRMS:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EL_LPRT </label>
<input type="text" class="form-control" placeholder="EL_LPRT" value={this.state.EL_LPRT} onChange={(value)=> this.setState({EL_LPRT:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EL_LPRP </label>
<input type="text" class="form-control" placeholder="EL_LPRP" value={this.state.EL_LPRP} onChange={(value)=> this.setState({EL_LPRP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EL_LNRNE </label>
<input type="text" class="form-control" placeholder="EL_LNRNE" value={this.state.EL_LNRNE} onChange={(value)=> this.setState({EL_LNRNE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EL_LNRNS </label>
<input type="text" class="form-control" placeholder="EL_LNRNS" value={this.state.EL_LNRNS} onChange={(value)=> this.setState({EL_LNRNS:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EL_LNRT </label>
<input type="text" class="form-control" placeholder="EL_LNRT" value={this.state.EL_LNRT} onChange={(value)=> this.setState({EL_LNRT:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EL_LNRP </label>
<input type="text" class="form-control" placeholder="EL_LNRP" value={this.state.EL_LNRP} onChange={(value)=> this.setState({EL_LNRP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD_PDN </label>
<input type="text" class="form-control" placeholder="CD_PDN" value={this.state.CD_PDN} onChange={(value)=> this.setState({CD_PDN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD_PDP </label>
<input type="text" class="form-control" placeholder="CD_PDP" value={this.state.CD_PDP} onChange={(value)=> this.setState({CD_PDP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD_PD_FPN </label>
<input type="text" class="form-control" placeholder="CD_PD_FPN" value={this.state.CD_PD_FPN} onChange={(value)=> this.setState({CD_PD_FPN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD_NDN </label>
<input type="text" class="form-control" placeholder="CD_NDN" value={this.state.CD_NDN} onChange={(value)=> this.setState({CD_NDN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD_NDP </label>
<input type="text" class="form-control" placeholder="CD_NDP" value={this.state.CD_NDP} onChange={(value)=> this.setState({CD_NDP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD_ND_FNN </label>
<input type="text" class="form-control" placeholder="CD_ND_FNN" value={this.state.CD_ND_FNN} onChange={(value)=> this.setState({CD_ND_FNN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD_ND_IN </label>
<input type="text" class="form-control" placeholder="CD_ND_IN" value={this.state.CD_ND_IN} onChange={(value)=> this.setState({CD_ND_IN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TOT_IN </label>
<input type="text" class="form-control" placeholder="TOT_IN" value={this.state.TOT_IN} onChange={(value)=> this.setState({TOT_IN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TOT_IP </label>
<input type="text" class="form-control" placeholder="TOT_IP" value={this.state.TOT_IP} onChange={(value)=> this.setState({TOT_IP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_CAP </label>
<input type="text" class="form-control" placeholder="FEC_CAP" value={this.state.FEC_CAP} onChange={(value)=> this.setState({FEC_CAP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_IMP </label>
<input type="text" class="form-control" placeholder="FEC_IMP" value={this.state.FEC_IMP} onChange={(value)=> this.setState({FEC_IMP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_VAL </label>
<input type="text" class="form-control" placeholder="FEC_VAL" value={this.state.FEC_VAL} onChange={(value)=> this.setState({FEC_VAL:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">VALIDADO </label>
<input type="text" class="form-control" placeholder="VALIDADO" value={this.state.VALIDADO} onChange={(value)=> this.setState({VALIDADO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLACAU </label>
<input type="text" class="form-control" placeholder="CLACAU" value={this.state.CLACAU} onChange={(value)=> this.setState({CLACAU:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SUPLEMENTO </label>
<input type="text" class="form-control" placeholder="SUPLEMENTO" value={this.state.SUPLEMENTO} onChange={(value)=> this.setState({SUPLEMENTO:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendSave()}>Save</button>
</div>
</div>
);
}
  sendSave(){
const baseUrl = "http://localhost:3000/Rtblcalidad7/create"
const datapost = {
MUESTRA: this.state.MUESTRA,
CLAPRO: this.state.CLAPRO,
CLAMUE: this.state.CLAMUE,
OFICIO: this.state.OFICIO,
FEC_REP: this.state.FEC_REP,
OBSERVA: this.state.OBSERVA,
CITOTECNO: this.state.CITOTECNO,
LR: this.state.LR,
TLI: this.state.TLI,
CRN: this.state.CRN,
CRP: this.state.CRP,
IPD: this.state.IPD,
EL_LPRNE: this.state.EL_LPRNE,
EL_LPRMS: this.state.EL_LPRMS,
EL_LPRT: this.state.EL_LPRT,
EL_LPRP: this.state.EL_LPRP,
EL_LNRNE: this.state.EL_LNRNE,
EL_LNRNS: this.state.EL_LNRNS,
EL_LNRT: this.state.EL_LNRT,
EL_LNRP: this.state.EL_LNRP,
CD_PDN: this.state.CD_PDN,
CD_PDP: this.state.CD_PDP,
CD_PD_FPN: this.state.CD_PD_FPN,
CD_NDN: this.state.CD_NDN,
CD_NDP: this.state.CD_NDP,
CD_ND_FNN: this.state.CD_ND_FNN,
CD_ND_IN: this.state.CD_ND_IN,
TOT_IN: this.state.TOT_IN,
TOT_IP: this.state.TOT_IP,
FEC_CAP: this.state.FEC_CAP,
FEC_IMP: this.state.FEC_IMP,
FEC_VAL: this.state.FEC_VAL,
VALIDADO: this.state.VALIDADO,
CLACAU: this.state.CLACAU,
SUPLEMENTO: this.state.SUPLEMENTO
}
axios.post(baseUrl,datapost)
      .then(response=>{
 if (response.data.success===true) {
  alert(response.data.message)
}
else {
alert(response.data.message)
}
}).catch(error=>{
   alert("Error 34 "+error)
 })
 }
}
export default EditComponent;
