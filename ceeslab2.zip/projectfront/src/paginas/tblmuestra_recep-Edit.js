import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios'
const baseUrl= "http: //localhost:3000"
class EditComponent extends React.Component{

constructor(props){

super(props);
this.state={
edittblmuestra_receps:[],
datatblmuestra_recep:{},
MUESTRA: "",
MUESTRA2: "",
FEC_REC: "",
HOR_REC: "",
CLAPRO: "",
CLAMUE: "",
AMPLIAR_TM: "",
TEM_REC: "",
CONFIRMAR: "",
OBSERVA: "",
AM: "",
AF: "",
AMP: "",
HT: "",
VALIDADO: "",
MOTIVO: "",
PRIORIDAD: "",
E1: "",
EXAM1: "",
E2: "",
EXAM2: "",
E3: "",
EXAM3: "",
E4: "",
EXAM4: "",
E5: "",
EXAM5: "",
E6: "",
EXAM6: "",
E7: "",
EXAM7: "",
E8: "",
EXAM8: "",
E9: "",
EXAM9: "",
E10: "",
EXAM10: "",
MODIFICADO: "",
FEC_LAB: "",
HOR_LAB: "",
CLAREC: ""
}
}


componentDidMount(){
let userId = this.props.match.params.tblmuestra_recepid;
  const url = baseUrl+"/Rtblmuestra_recep/get/"+userId

  axios.get(url)
 .then(res=>{
  if(res.data.sucess){
  const data = res.data.data[0] 
this.setState({
edittblmuestra_receps:data,
MUESTRA: data.MUESTRA,
MUESTRA2: data.MUESTRA2,
FEC_REC: data.FEC_REC,
HOR_REC: data.HOR_REC,
CLAPRO: data.CLAPRO,
CLAMUE: data.CLAMUE,
AMPLIAR_TM: data.AMPLIAR_TM,
TEM_REC: data.TEM_REC,
CONFIRMAR: data.CONFIRMAR,
OBSERVA: data.OBSERVA,
AM: data.AM,
AF: data.AF,
AMP: data.AMP,
HT: data.HT,
VALIDADO: data.VALIDADO,
MOTIVO: data.MOTIVO,
PRIORIDAD: data.PRIORIDAD,
E1: data.E1,
EXAM1: data.EXAM1,
E2: data.E2,
EXAM2: data.EXAM2,
E3: data.E3,
EXAM3: data.EXAM3,
E4: data.E4,
EXAM4: data.EXAM4,
E5: data.E5,
EXAM5: data.EXAM5,
E6: data.E6,
EXAM6: data.EXAM6,
E7: data.E7,
EXAM7: data.EXAM7,
E8: data.E8,
EXAM8: data.EXAM8,
E9: data.E9,
EXAM9: data.EXAM9,
E10: data.E10,
EXAM10: data.EXAM10,
MODIFICADO: data.MODIFICADO,
FEC_LAB: data.FEC_LAB,
HOR_LAB: data.HOR_LAB,
CLAREC: data.CLAREC
} ) }
else{
alert("Error web service")
} } )
  .catch(error=>{
  })
}


  render(){
   let userId = 0;
 return (
<div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MUESTRA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.MUESTRA} onChange={(value)=> this.setState({MUESTRA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MUESTRA2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.MUESTRA2} onChange={(value)=> this.setState({MUESTRA2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_REC </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_REC} onChange={(value)=> this.setState({FEC_REC:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">HOR_REC </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.HOR_REC} onChange={(value)=> this.setState({HOR_REC:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAPRO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAPRO} onChange={(value)=> this.setState({CLAPRO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAMUE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAMUE} onChange={(value)=> this.setState({CLAMUE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">AMPLIAR_TM </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.AMPLIAR_TM} onChange={(value)=> this.setState({AMPLIAR_TM:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TEM_REC </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.TEM_REC} onChange={(value)=> this.setState({TEM_REC:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CONFIRMAR </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CONFIRMAR} onChange={(value)=> this.setState({CONFIRMAR:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OBSERVA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.OBSERVA} onChange={(value)=> this.setState({OBSERVA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">AM </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.AM} onChange={(value)=> this.setState({AM:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">AF </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.AF} onChange={(value)=> this.setState({AF:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">AMP </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.AMP} onChange={(value)=> this.setState({AMP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">HT </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.HT} onChange={(value)=> this.setState({HT:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">VALIDADO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.VALIDADO} onChange={(value)=> this.setState({VALIDADO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MOTIVO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.MOTIVO} onChange={(value)=> this.setState({MOTIVO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">PRIORIDAD </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.PRIORIDAD} onChange={(value)=> this.setState({PRIORIDAD:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E1} onChange={(value)=> this.setState({E1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM1} onChange={(value)=> this.setState({EXAM1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E2} onChange={(value)=> this.setState({E2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM2} onChange={(value)=> this.setState({EXAM2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E3 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E3} onChange={(value)=> this.setState({E3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM3 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM3} onChange={(value)=> this.setState({EXAM3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E4 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E4} onChange={(value)=> this.setState({E4:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM4 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM4} onChange={(value)=> this.setState({EXAM4:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E5 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E5} onChange={(value)=> this.setState({E5:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM5 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM5} onChange={(value)=> this.setState({EXAM5:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E6 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E6} onChange={(value)=> this.setState({E6:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM6 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM6} onChange={(value)=> this.setState({EXAM6:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E7 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E7} onChange={(value)=> this.setState({E7:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM7 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM7} onChange={(value)=> this.setState({EXAM7:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E8 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E8} onChange={(value)=> this.setState({E8:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM8 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM8} onChange={(value)=> this.setState({EXAM8:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E9 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E9} onChange={(value)=> this.setState({E9:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM9 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM9} onChange={(value)=> this.setState({EXAM9:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E10 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.E10} onChange={(value)=> this.setState({E10:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAM10 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAM10} onChange={(value)=> this.setState({EXAM10:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MODIFICADO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.MODIFICADO} onChange={(value)=> this.setState({MODIFICADO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_LAB </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.FEC_LAB} onChange={(value)=> this.setState({FEC_LAB:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">HOR_LAB </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.HOR_LAB} onChange={(value)=> this.setState({HOR_LAB:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAREC </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAREC} onChange={(value)=> this.setState({CLAREC:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendUpdate()}>Update</button>  
</div>
); }
sendUpdate(){
let userId = this.props.match.params.tblmuestra_recepid;
const baseUrl = "http://localhost:3000/Rtblmuestra_recep/Update/"+ userId
const datapost = {
MUESTRA: this.state.MUESTRA,
MUESTRA2: this.state.MUESTRA2,
FEC_REC: this.state.FEC_REC,
HOR_REC: this.state.HOR_REC,
CLAPRO: this.state.CLAPRO,
CLAMUE: this.state.CLAMUE,
AMPLIAR_TM: this.state.AMPLIAR_TM,
TEM_REC: this.state.TEM_REC,
CONFIRMAR: this.state.CONFIRMAR,
OBSERVA: this.state.OBSERVA,
AM: this.state.AM,
AF: this.state.AF,
AMP: this.state.AMP,
HT: this.state.HT,
VALIDADO: this.state.VALIDADO,
MOTIVO: this.state.MOTIVO,
PRIORIDAD: this.state.PRIORIDAD,
E1: this.state.E1,
EXAM1: this.state.EXAM1,
E2: this.state.E2,
EXAM2: this.state.EXAM2,
E3: this.state.E3,
EXAM3: this.state.EXAM3,
E4: this.state.E4,
EXAM4: this.state.EXAM4,
E5: this.state.E5,
EXAM5: this.state.EXAM5,
E6: this.state.E6,
EXAM6: this.state.EXAM6,
E7: this.state.E7,
EXAM7: this.state.EXAM7,
E8: this.state.E8,
EXAM8: this.state.EXAM8,
E9: this.state.E9,
EXAM9: this.state.EXAM9,
E10: this.state.E10,
EXAM10: this.state.EXAM10,
MODIFICADO: this.state.MODIFICADO,
FEC_LAB: this.state.FEC_LAB,
HOR_LAB: this.state.HOR_LAB,
CLAREC: this.state.CLAREC
}
axios.post(baseUrl,datapost)
.then(response=>{
if (response.data.success===true) {
alert(response.data.message)
}
else {
alert(response.data.message)
alert(JSON.stringify(response))
}
}).catch(error=>{
alert("Error 34 "+error)
})
}
}
export default EditComponent;
