//import '../css/dataTables.bootstrap4.min.css'
//import './css/font-awesome.min.css'
import React, { Component } from 'react'
import { BrowserRouter as Router, Route } from 'react-router-dom'

const $=require('jquery')
$.Datatable=require('datatables.net')

  var obtenerDatos=function(tbody,table){
  $(tbody).on("click","button.selecc",function(){
  var data=table.row($(this).parents("tr")).data();
  console.log(data);
  })
  }
  
  var obtenerDatos2=function(tbody,table){
  $(tbody).on('click','tr',function(){
  var data=table.row($(this).parents("tr")).data();
  console.log(data);
  })
  }

  var obtenerDatos3=function(tbody,table){
     // $(tbody).on('click','btn-edit',function(e){
       var datos=''
       var num=2000
    $(tbody).on('click','tr',function(e){

      e.preventDefault();
  var data=table.row($(this)).data();
     // var data=table.row($(this).parent().parent().children.first().text())  // da solo el indice
  console.log(data);
 //$("#formRecep #inProced").on("focus", function(){    alert("The innput was focus.");  });
 var num=2000;
  var idprocedencia=$("#formRecep #inProced").val(data.id+" "+data.nombre)
   // datos={idprocedencia}
   // var lang = this.refs.dropdown.value;
  //this.props.onSelectLanguage(idprocedencia); 
  //this.setState({ procedencia: data.id });
  calc();
  // $("#formRecep #inProced").trigger("focus");
  // idprocedencia=$("#formRecep #inProced").val(function(n, c){return c + "A"; });
  //var idprocedencia=$("#formRecep #inProced").val(function(n, c){return c + data.nombre; });
  //*************var idprocedencia;
  //**********************$("#formRecep #inProced").prop('disabled', false);
 //************** idprocedencia=$("#formRecep #inProced").val(data.id)
  //$("#formRecep #inProced").prop('disabled', false);
 // $("#formRecep #inProced").trigger("change");
  //$("#formRecep #inProced").on("change", function(){    alert("The innput was changed.");  });
  //idprocedencia=$("#formRecep #inProced").val(data.id+" "+data.nombre)
  //$("#formRecep #inProced").on("cambio", function(event){$("#formRecep #inProced").val(function(n, c){return c +data.nombre; });
   // });  
   //********  $("#formRecep #inProced").trigger("onChangeProced");  
   // $("#formRecep #inProced").trigger("handleProcedenciaChange");
  // $("#formRecep #inProced").on("change", {msg: "You just clicked me!"}, handlerName)
 // idprocedencia=$("#formRecep #inProced").val(function(n, c){return c +data.nombre; });
 //*********  $("#formRecep #inProced").prop('disabled', true); 
   //this.state.procedencia
 //{this.props.onChangeProced}
  // this.setState({ procedencia: idprocedencia });    
 //$('#inProced').trigger(this.onChange());
// clicke(data)
   $("#mProcedencia .close").click();  
   //return data;
  })
  }

  var obtenerDatos4=(tbody,table)=>{
    //var num=2000
    //this.props.callback(this.props.num * 2)
   $(tbody).on('click','tr',(e)=>{
    console.log(e);
     e.preventDefault();
   var data=table.row($(this)).data();
  console.log(data);
 var idprocedencia=$("#formRecep #inProced").val(data.id+" "+data.nombre);
 var idprocedenciaH=$("#formRecep #inProcedH").val(data.id);
 //() => this.calc();
 
  $("#mProcedencia .close").click();  
  })
    }

 var obtenerDatos5=function(tbody,table){
    //  var num=2000
     $(tbody).on('click','tr',function(e){
       e.preventDefault();
     var data=table.row($(this)).data();
    console.log(data);
   var idprocedencia=$("#formRecep #inProced").val(data.id+" "+data.nombre);
   var idprocedenciaH=$("#formRecep #inProcedH").val(data.id);
   //() => this.calc();
   //this.props.callback(this.props.num * 2)
 
    $("#mProcedencia .close").click();  
    })
      }

  var obtenerDatos6=function(tbody,table){
        $(tbody).on("click","button.selecc",function() {          
        var data=table.row($(this).parents("tr")).data();
        console.log(data);
        var idprocedencia=$("#inProced").val(data.id+" "+data.nombre);
        var idprocedenciaH=$("#inProcedH").val(data.id);
        $("#mProcedencia .close").click();
        })
        }

  var calc=function(){
    console.log("en funcion calc")
    var num=2000;
    {this.props.callback(num * 2)};
  };

  var clicke=() => {this.props.callback(2 * 2)  }
   // console.log("onClick en el tbl");
   // console.log(data);
   // this.setState({ procedencia: data.id });
    //this.props.onChangeProced(e);
    //  }
  var espanol={
    "sProcessing":     "Procesando...",
    "sLengthMenu":     "Mostrar _MENU_ registros",
    "sZeroRecords":    "No se encontraron resultados",
    "sEmptyTable":     "Ningún dato disponible en esta tabla =(",
    "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
    "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
    "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
    "sInfoPostFix":    "",
    "sSearch":         "Buscar:",
    "sUrl":            "",
    "sInfoThousands":  ",",
    "sLoadingRecords": "Cargando...",
    "oPaginate": {
        "sFirst":    "Primero",
        "sLast":     "Último",
        "sNext":     "Siguiente",
        "sPrevious": "Anterior"
    },
    "oAria": {
        "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
        "sSortDescending": ": Activar para ordenar la columna de manera descendente"
    },
    "buttons": {
        "copy": "Copiar",
        "colvis": "Visibilidad"
    }
  
  }

  var listar2=()=>{
    var table=$("#dt1").DataTable({
        destroy: true,
        empty: true,
      language:espanol,
     //data:this.props.callback(this.props.num * 2),
      ajax:{
            method:'GET',
            url:'http://localhost:5000/regiones/TodasReg3'
            },
            columns:[
              {data:'id'},
              {data:'nombre'},
              {data:'subregion'},
              {data:'estado'},
              {"defaultContent":"<button  type='button' class='btn btn-primary selecc'><i class='far fa-check-circle'></i></button>"}
              ],
      select: true,
      colReorder: true
    });
    obtenerDatos6("#dt1 tbody",table);
    
  
  }  


  var listar=function(){
    var table=$("#dt1").DataTable({
        destroy: true,
        empty: true,
      language:espanol,
    //data:this.props.data,
      ajax:{
            method:'GET',
            url:'http://localhost:5000/regiones/TodasReg3'
            },
            columns:[
              {data:'id'},
              {data:'nombre'},
              {data:'subregion'},
              {data:'estado'}
              ],
      select: true,
      colReorder: true
    });
    obtenerDatos4("#dt1 tbody",table);
  
  }  
 
  class Tbl extends Component{ 
    constructor() {
      super()
      this.state = {
      //  data:[0],
     //   procedenciaT:''   
        }
    //  this.handleLangChange = this.handleLangChange.bind(this);    
    }
/*
    handleLangChange = () => {
      var lang = this.data;
      this.props.onSelectLanguage(lang);            
  }  */
  //this.onChangeProced = this.onChangeProced.bind(this)
componentDidMount(){
  listar2();
}
//componentWillUnmount(){  //this.$el.DataTable.destroy(true)}

render(){
  return(
    <div>
    <table id="dt1" className="display table table-bordered table-hover"
    width="100%" ref={el=>this.el=el}>
      <thead className="bg-success text-center text-white">
<tr className="sortable">
<th>ID</th>
<th>NOMBRE</th>
<th>SUBREGION</th>
<th>ESTADO</th>
<th>ACCIÓN</th>
</tr>
</thead>
    </table>
    </div>
    
  )

}
}
export default Tbl