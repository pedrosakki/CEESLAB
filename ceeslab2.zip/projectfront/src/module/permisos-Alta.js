import React, { Component } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios';

class EditComponent extends Component{
    constructor(props){
        super(props);
        this.state = {
            id:"",
            accion:""
}
}  
render(){
    return(


<div > 
    <div class="form-row justify-content-center">
    <div class="form-group col-md-6">
<label for="inputApellidoPaterno">id </label>
<input type="text" class="form-control" placeholder="id" 
value={this.state.id} onChange={(value)=> this.setState({id:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">accion </label>
<input type="text" class="form-control" placeholder="accion" 
value={this.state.accion} onChange={(value)=> this.setState({accion:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendSave()}>Save</button>
</div>
</div>

);
} ;

sendSave(){
    const baseUrl = "http: //localhost:3000/Rpermisos/create"
    const datapost = {
        id: this.state.id,
        accion: this.state.accion
}
axios.post(baseUrl,datapost)      
.then(response=>{ 
    if (response.data.success===true) {  
        alert(response.data.message)
    }else {alert(response.data.message)}
})
.catch(error=>{   
        alert("Error 34 "+error) 
    }) 
}


export default EditComponent;