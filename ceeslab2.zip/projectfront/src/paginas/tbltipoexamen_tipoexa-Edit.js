import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios'
const baseUrl= "http: //localhost:3000"
class EditComponent extends React.Component{

constructor(props){

super(props);
this.state={
edittbltipoexamen_tipoexas:[],
datatbltipoexamen_tipoexa:{},
CLAEXA: "",
EXAMEN: "",
UNIDAD: "",
METODO: "",
TECNICA: "",
REFERENCIA: "",
GRUPO: ""
}
}


componentDidMount(){
let userId = this.props.match.params.tbltipoexamen_tipoexaid;
  const url = baseUrl+"/Rtbltipoexamen_tipoexa/get/"+userId

  axios.get(url)
 .then(res=>{
  if(res.data.sucess){
  const data = res.data.data[0] 
this.setState({
edittbltipoexamen_tipoexas:data,
CLAEXA: data.CLAEXA,
EXAMEN: data.EXAMEN,
UNIDAD: data.UNIDAD,
METODO: data.METODO,
TECNICA: data.TECNICA,
REFERENCIA: data.REFERENCIA,
GRUPO: data.GRUPO
} ) }
else{
alert("Error web service")
} } )
  .catch(error=>{
  })
}


  render(){
   let userId = 0;
 return (
<div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAEXA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CLAEXA} onChange={(value)=> this.setState({CLAEXA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAMEN </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.EXAMEN} onChange={(value)=> this.setState({EXAMEN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">UNIDAD </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.UNIDAD} onChange={(value)=> this.setState({UNIDAD:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">METODO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.METODO} onChange={(value)=> this.setState({METODO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TECNICA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.TECNICA} onChange={(value)=> this.setState({TECNICA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">REFERENCIA </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.REFERENCIA} onChange={(value)=> this.setState({REFERENCIA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">GRUPO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.GRUPO} onChange={(value)=> this.setState({GRUPO:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendUpdate()}>Update</button>  
</div>
); }
sendUpdate(){
let userId = this.props.match.params.tbltipoexamen_tipoexaid;
const baseUrl = "http://localhost:3000/Rtbltipoexamen_tipoexa/Update/"+ userId
const datapost = {
CLAEXA: this.state.CLAEXA,
EXAMEN: this.state.EXAMEN,
UNIDAD: this.state.UNIDAD,
METODO: this.state.METODO,
TECNICA: this.state.TECNICA,
REFERENCIA: this.state.REFERENCIA,
GRUPO: this.state.GRUPO
}
axios.post(baseUrl,datapost)
.then(response=>{
if (response.data.success===true) {
alert(response.data.message)
}
else {
alert(response.data.message)
alert(JSON.stringify(response))
}
}).catch(error=>{
alert("Error 34 "+error)
})
}
}
export default EditComponent;
