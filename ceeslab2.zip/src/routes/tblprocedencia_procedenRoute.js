const express = require('express');
const router = express.Router();
const tblprocedencia_procedenController = require('../Controllers/tblprocedencia_procedenController')


router.post('/update/:id',tblprocedencia_procedenController.update)
router.get('/get/:id', tblprocedencia_procedenController.get)
router.get('/list', tblprocedencia_procedenController.list);
router.post('/create', tblprocedencia_procedenController.create);


module.exports = router;
