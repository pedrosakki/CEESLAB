import axios from 'axios'

export const register = newUser => {
  return axios
    .post('users/register', {
      id:newUser.id,
      first_name: newUser.first_name,
      last_name: newUser.last_name,
      email: newUser.email,
      password: newUser.password,
      rol: newUser.rol
    })
    .then(response => {
      console.log(newUser);
      console.log('Se Registró (userFunctions)');
    })
}

export const login = user => {
  return axios
    .post('users/login', {
      id: user.id,
      password: user.password
    })
    .then(response => {
      localStorage.setItem('usertoken', response.data)
      return response.data
    })
    .catch(err => {
      console.log(err)
    })
}

export const todasReg = () => {
  return axios
    .get('regiones/TodasReg', {
    })
    .then(response => {
      console.log('en Userfunctions')
      //localStorage.setItem('usertoken', response.data)
      return response.data
    })
    .catch(err => {
      console.log(err)
    })
}

export const todasReg2 = () => {
  return axios
    .get('regiones/TodasReg2?', {
    })
    .then(response => {
      console.log('en Userfunctions')
      //localStorage.setItem('usertoken', response.data)
      return response.data
    })
    .catch(err => {
      console.log(err)
    })
}

export const recepcion = newRecep => {
  return axios
    .post('users/recepcion', {
      id:newRecep.id
    })
    .then(response => {
      console.log(newRecep);
      console.log('Se Registró (userFunctions)');
    })
}

export const ultimaMuestra = () => {
  return axios
    .get('tipoMuestras/ultima', {  })
    .then(response => {
      //localStorage.setItem('usertoken', response.data)
      return response.data
    })
    .catch(err => {
      console.log(err)
    })
}

export const altaRecepcion = newRecep => {
  return axios
    .post('tipoMuestras/altaRecepcion', {
        idTipo: newRecep.idTipo,
        fecha: newRecep.fecha,
        procedencia: newRecep.procedencia,
        tipo: newRecep.tipo,
        ctrlCalidad: newRecep.ctrlCalidad,
        ampliarAmbiental: newRecep.ampliarAmbiental,
        confirmarCepa: newRecep.confirmarCepa,
        temp: newRecep.temp,
        observaciones: newRecep.observaciones,
        analisisSolicitado: newRecep.analisisSolicitado,
        motivo: newRecep.motivo,
        prioridad: newRecep.prioridad,
        claveExa1:newRecep.claveExa1,    
        microbiolog:newRecep.microbiolog,
        fisicoQ:newRecep.fisicoQ,
        toxicolog:newRecep.toxicolog,
        metalesPe:newRecep.metalesPe
    })
    .then(response => {
      console.log(newRecep);
      console.log('Se Registró la muestra(userFunctions)');
    })
}

export const updateMuestra = newRecep => {
  return axios
    .post('tipoMuestras/updateMuestra/:idTipo', {
        idTipo: newRecep.idTipo,
        fecha: newRecep.fecha,
        procedencia: newRecep.procedencia,
        tipo: newRecep.tipo,
        ctrlCalidad: newRecep.ctrlCalidad,
        ampliarAmbiental: newRecep.ampliarAmbiental,
        confirmarCepa: newRecep.confirmarCepa,
        temp: newRecep.temp,
        observaciones: newRecep.observaciones,
        analisisSolicitado: newRecep.analisisSolicitado,
        motivo: newRecep.motivo,
        prioridad: newRecep.prioridad,
        claveExa1:newRecep.claveExa1,    
        microbiolog:newRecep.microbiolog,
        fisicoQ:newRecep.fisicoQ,
        toxicolog:newRecep.toxicolog,
        metalesPe:newRecep.metalesPe
    })
    .then(response => {
      console.log(newRecep);
      console.log('Se Actualizó la muestra(userFunctions)');
    })
}

