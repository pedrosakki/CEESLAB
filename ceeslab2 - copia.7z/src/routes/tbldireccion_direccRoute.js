const express = require('express');
const router = express.Router();
const tbldireccion_direccController = require('../Controllers/tbldireccion_direccController')


router.post('/update/:id',tbldireccion_direccController.update)
router.get('/get/:id', tbldireccion_direccController.get)
router.get('/list', tbldireccion_direccController.list);
router.post('/create', tbldireccion_direccController.create);


module.exports = router;
