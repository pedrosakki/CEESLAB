import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import TblProcedencia from './tblprocedencia_proceden-tbl';
import Tbltipomuestra from './tbltipomuestra_tmues-tbl';
import axios from 'axios';


const urlultima = "http://localhost:3000/Rtblmuestra_recep/ultima"


class EditComponent extends React.Component{
  constructor(props){
    super(props);
    this.state = {
    resultados:[],
    MUESTRA:"",
    MUESTRA2:"",
    FEC_REC:"",
    HOR_REC:"",
    CLAPRO:"",
    TXCLAPROD:"",
    CLAMUE:"",
    TXCLAMUED:"",
    AMPLIAR_TM:"",
    TEM_REC:"",
    CONFIRMAR:"",
    OBSERVA:"",
    AM:false,
    AF:false,
    AMP:false,
    HT:false,
    VALIDADO:"",
    MOTIVO:"",
    PRIORIDAD:"",
    E1:"",
    EXAM1:"",
    E2:"",
    EXAM2:"",
    E3:"",
    EXAM3:"",
    E4:"",
    EXAM4:"",
    E5:"",
    EXAM5:"",
    E6:"",
    EXAM6:"",
    E7:"",
    EXAM7:"",
    E8:"",
    EXAM8:"",
    E9:"",
    EXAM9:"",
    E10:"",
    EXAM10:"",
    MODIFICADO:"",
    FEC_LAB:"",
    HOR_LAB:"",
    CLAREC:"",
    TXE1:"",
    COMPLEMENTO:""
    }
       this.twoCalls = this.twoCalls.bind(this)
       this.pedirexamen = this.pedirexamen.bind(this);
       this.pedirComplemento = this.pedirComplemento.bind(this);
       this.onChange = this.onChange.bind(this);
       this.twoCalls = this.twoCalls.bind(this);    
       this.ultimaMuestraRecibida = this.ultimaMuestraRecibida.bind(this);
       this.sendSave = this.sendSave.bind(this);
       this.getResponse = this.getResponse.bind(this)    
       this.getResponseH = this.getResponseH.bind(this) 
       this.getResponseTipo = this.getResponseTipo.bind(this)   
       this.getResponseTipoH = this.getResponseTipoH.bind(this)
    }

    getResponse(TXCLAPROD){this.setState({TXCLAPROD}); }
    getResponseH(CLAPRO){this.setState({CLAPRO}); }
    getResponseTipo(TXCLAMUED){this.setState({TXCLAMUED}); }
    getResponseTipoH(CLAMUE){this.setState({CLAMUE}); }


  componentDidMount(){
    var datee = Date.now()
    var valor 
    //console.log(datee)
    //ultimaMuestraRecibida()
   this.setState({FEC_REC: datee});   
   axios.get(urlultima,{})
   .then(res => {
     //console.log(res.data);
     if (res.data) {       //si hubo datos de la ultima muestra
            this.setState({MUESTRA:res.data})             
           // console.log('this.state de id....'+ this.state.MUESTRA)
   }else { 
     alert("no hay datos de la ULTIMA muestra");} //lanzar alerta de que le user no existe
   }) 
  }

  validarexamenes(){
   console.log("CAMBIO")
   console.log(this.state.MUESTRA)
   console.log(this.state.AM)
   console.log(this.state.AF)
   console.log(this.state.MOTIVO)
   console.log(this.state.PRIORIDAD)

  }  

  twoCalls = e => {
  this.setState({E1:e.target.value})    
  var valor=e.target.value
  // alert(valor)
  this.pedirexamen(valor) 
  }

 ultimaMuestraRecibida(){
 axios.get(urlultima,{})
  .then(res => {
    //console.log(res.data);
    if (res.data) {       //si hubo datos de la ultima muestra
           this.setState({MUESTRA:res.data})             
          // console.log('this.state de id....'+ this.state.MUESTRA)
  }else { 
    alert("no hay datos de la ULTIMA muestra");} //lanzar alerta de que le user no existe
  }) 
       }


pedirexamen(valor){     
  var baseUrl ="http://localhost:3000"
  const url = baseUrl +"/Rtbltipoexamen_tipoexa/examen/"+valor
  //alert(url);
  axios.get(url)
  .then(res=>{
    if(res.data.sucess){
      const data = res.data.data[0] 
     // alert(JSON.stringify(data));
      this.setState({TXE1: data.EXAMEN} )  
      this.setState({COMPLEMENTO: data.COMPLEMENTO} )  
      console.log(this.state.COMPLEMENTO)

     var compl=this.state.COMPLEMENTO
      if(compl!=='NUll'){
        this.pedirComplemento(compl)        
      } 
      }
    else{
      console.log("Error web service")
        } 
      })
  .catch(error=>{
         // alert("Error server..."+error)
  })
}

pedirComplemento(valor){     
  var baseUrl ="http://localhost:3000"
  const url = baseUrl +"/Rtbltipoexamen_tipoexa/complemento/"+valor
  var arr1=["","","","","","","","","",""]
  var arr11=["","","","","","","","","",""]
  //console.log(url);
  axios.get(url)
  .then(res=>{
    if(res.data.sucess){
      const data = res.data    
    // console.log(data.data.length);
    // E2  EXAM2 
    if(data.data.length>1){
          for (var cuadro = 1; cuadro<data.data.length; cuadro++) {
               // ed2= 'E'+ (cuadro+1)
               // ed22= 'EXAM'+ (cuadro+1)
                arr1[cuadro]=data.data[cuadro].CLAEXA
                arr11[cuadro]=data.data[cuadro].EXAMEN
                
               // console.log("en el for") 
              //  $("#inProcedH").val(data.id);
              //  this.setState({ E2:ed2 })
               // this.setState({ EXAM2:ed22 })                                   
              }
              //console.log(arr1)
              //console.log(arr11)
             
                this.setState({ E2:arr1[1] });   this.setState({ EXAM2:arr11[1] })
                this.setState({ E3:arr1[2] });   this.setState({ EXAM3:arr11[2] })
                this.setState({ E4:arr1[3] });   this.setState({ EXAM4:arr11[3] })
                this.setState({ E5:arr1[4] });   this.setState({ EXAM5:arr11[4] })
                this.setState({ E6:arr1[5] });   this.setState({ EXAM6:arr11[5] })
                this.setState({ E7:arr1[6]});   this.setState({ EXAM7:arr11[6] })
                this.setState({ E8:arr1[7]});   this.setState({ EXAM8:arr11[7] })
                this.setState({ E9:arr1[8] });  this.setState({ EXAM9:arr11[8] })
                this.setState({ E10:arr1[9] }); this.setState({ EXAM10:arr11[9] })
                
    }
         
      }
    else{
        console.log("Error web service")
        } } )
  .catch(error=>{
         // alert("Error server..."+error)
  })
}

onChange(e) {
  this.setState({ [e.target.name]: e.target.value })
}

render(){
  return (
<div>
<div>
        <hr id="Line1" style={{position: 'absolute', left: '163px', top: '66px', width: '796px', zIndex: 0}} />
        <label   id="Label1" style={{position: 'absolute', left: '177px', top: '66px', width: '320px', height: '36px', lineHeight: '36px', zIndex: 1, align:'center'}}>Recepción de Muestras</label>
        <label   id="Label2" style={{position: 'absolute', left: '157px', top: '123px', width: '81px', height: '20px', lineHeight: '20px', zIndex: 2}}>Muestra No.</label>
       
        <strong><h6 className="text-danger especial" style={{position: 'absolute', left: '265px', top: '124px', width: '86px', height: '16px', zIndex: 3}}>{this.state.MUESTRA}</h6> </strong>
                                              
        
        <label   id="Label3" style={{position: 'absolute', left: '414px', top: '123px', width: '55px', height: '20px', lineHeight: '20px', zIndex: 4}}>Fecha</label>
        <input type="date" id="txfec_rec" 
                             style={{position: 'absolute', left: '473px', top: '124px', width: '180px', height: '16px', zIndex: 6}} 
        name="FEC_REC" value={this.state.FEC_REC} onChange={(value)=> this.setState({FEC_REC:value.target.value})} />
        <label   id="Label4" style={{position: 'absolute', left: '700px', top: '123px', width: '55px', height: '20px', lineHeight: '20px', zIndex: 5}}>Hora</label>
        <input type="time" id="txhor_rec" style={{position: 'absolute', left: '750px', top: '124px', width: '120px', height: '16px', zIndex: 75}} 
        name="HOR_REC" onChange={this.onChange} spellCheck="false" />


        <label   id="Label5" style={{position: 'absolute', left: '157px', top: '153px', width: '81px', height: '20px', lineHeight: '20px', zIndex: 7}}>Procedencia</label>    
      
        <input type="text" id="txclapro" style={{position: 'absolute', left: '271px', top: '154px', width: '86px', height: '16px', zIndex: 8}}
         name="CLAPRO"  />
        <input type="text" id="txclaprod" style={{position: 'absolute', left: '414px', top: '154px', width: '540px', height: '16px', zIndex: 9}}
         name="TXCLAPROD" value={this.props.TXCLAPROD} onChange={this.getResponse}/>

        <label   id="Label6" style={{position: 'absolute', left: '157px', top: '181px', width: '106px', height: '20px', lineHeight: '20px', zIndex: 10}}>Tipo de Muestra</label>
      
        <input type="text" id="Editbox5" style={{position: 'absolute', left: '271px', top: '182px', width: '86px', height: '16px', zIndex: 11}}
         name="CLAMUE"  />
        <input type="text" id="txclamuesd" style={{position: 'absolute', left: '414px', top: '182px', width: '540px', height: '16px', zIndex: 12}}
         name="TXCLAMUED" value={this.props.TXCLAMUED} onChange={this.getResponseTipo}/>
      
        <label   id="Label7" style={{position: 'absolute', left: '157px', top: '209px', width: '238px', height: '20px', lineHeight: '20px', zIndex: 13}}>Ampliar tipo de muestra (ambiental)</label>
        <input type="text" id="txampliar_tm" style={{position: 'absolute', left: '414px', top: '210px', width: '540px', height: '16px', zIndex: 14}} 
        name="AMPLIAR_TM" value={this.state.AMPLIAR_TM} onChange={(value)=> this.setState({AMPLIAR_TM:value.target.value})} />
        <label   id="Label8" style={{position: 'absolute', left: '157px', top: '238px', width: '250px', height: '20px', lineHeight: '20px', zIndex: 15}}>Confirmar (Cepa Microbiologia Medica)</label>
        <input type="text" id="txconfirmar" style={{position: 'absolute', left: '414px', top: '239px', width: '540px', height: '16px', zIndex: 16}}
         name="CONFIRMAR"  />
        <label   id="Label9" style={{position: 'absolute', left: '159px', top: '266px', width: '81px', height: '20px', lineHeight: '20px', zIndex: 17}}>Temperatura</label>
        <input type="text" id="txtem_rec" style={{position: 'absolute', left: '273px', top: '267px', width: '86px', height: '16px', zIndex: 18}} 
        name="TEM_REC" value={this.state.TEM_REC} onChange={(value)=> this.setState({TEM_REC:value.target.value})} />
        <label   id="Label10" style={{position: 'absolute', left: '159px', top: '295px', width: '97px', height: '20px', lineHeight: '20px', zIndex: 19}}>Observaciones</label>
        <input type="text" id="Editbox10" style={{position: 'absolute', left: '273px', top: '296px', width: '681px', height: '16px', zIndex: 20}} 
        name="OBSERVA"   value={this.state.OBSERVA} onChange={(value)=> this.setState({OBSERVA:value.target.value})}/>
  
        <label   id="Label11" style={{position: 'absolute', left: '296px', top: '326px', width: '626px', height: '22px', lineHeight: '22px', zIndex: 22}}>CONTROL - AMBIENTAL - ANALISIS SOLICITADO</label>
        <div id="wb_Checkbox1" style={{position: 'absolute', left: '167px', top: '355px', width: '31px', height: '19px', zIndex: 23}}>
          <input type="checkbox" id="Checkbox1" name="AM" checked={this.state.AM} onChange={(value)=> this.setState({AM:value.target.checked})} style={{position: 'absolute', left: 0, top: 0}} /><label  htmlFor="Checkbox1" /></div>
        <div id="wb_Checkbox2" style={{position: 'absolute', left: '367px', top: '355px', width: '31px', height: '19px', zIndex: 24}}>
          <input type="checkbox" id="Checkbox2" name="AF" checked={this.state.AF} onChange={(value)=> this.setState({AF:value.target.checked})} style={{position: 'absolute', left: 0, top: 0}} /><label  htmlFor="Checkbox2" /></div>
        <div id="wb_Checkbox3" style={{position: 'absolute', left: '540px', top: '355px', width: '30px', height: '19px', zIndex: 25}}>
          <input type="checkbox" id="Checkbox3" name="HT" checked={this.state.HT} onChange={(value)=> this.setState({HT:value.target.checked})} style={{position: 'absolute', left: 0, top: 0}} /><label  htmlFor="Checkbox3" /></div>
        <div id="wb_Checkbox4" style={{position: 'absolute', left: '749px', top: '355px', width: '31px', height: '19px', zIndex: 26}}>
          <input type="checkbox" id="Checkbox4" name="AMP" checked={this.state.AMP} onChange={(value)=> this.setState({AMP:value.target.checked})} style={{position: 'absolute', left: 0, top: 0}} /><label  htmlFor="Checkbox4" /></div>
        <label   id="Label12" style={{position: 'absolute', left: '194px', top: '352px', width: '131px', height: '16px', lineHeight: '16px', zIndex: 27}}>MICROBIOLOGICO</label>
        <label   id="Label13" style={{position: 'absolute', left: '391px', top: '352px', width: '131px', height: '16px', lineHeight: '16px', zIndex: 28}}>FISICO QUIMICO</label>
        <label   id="Label14" style={{position: 'absolute', left: '581px', top: '352px', width: '131px', height: '16px', lineHeight: '16px', zIndex: 29}}>TOXICOLOGICO</label>
        <label   id="Label15" style={{position: 'absolute', left: '788px', top: '352px', width: '144px', height: '16px', lineHeight: '16px', zIndex: 30}}>METALES PESADOS</label>
        <div id="wb_RadioButton1" style={{position: 'absolute', left: '217px', top: '381px', width: '14px', height: '24px', zIndex: 31}}>
          <input type="radio" id="RadioButton1" name="CONTROLAMBIENTAL" defaultValue="PROGRAMA"  onChange={(value)=> this.setState({MOTIVO:value.target.value})} style={{position: 'absolute', left: 0, top: 0}} /><label  htmlFor="RadioButton1" /></div>
        <label   id="Label16" style={{position: 'absolute', left: '157px', top: '381px', width: '50px', height: '16px', lineHeight: '16px', zIndex: 32}}>Motivo</label>
        <div id="wb_RadioButton2" style={{position: 'absolute', left: '365px', top: '381px', width: '14px', height: '24px', zIndex: 33}}>
          <input type="radio" id="RadioButton2" name="CONTROLAMBIENTAL" defaultValue="CMTRF"  onChange={(value)=> this.setState({MOTIVO:value.target.value})} style={{position: 'absolute', left: 0, top: 0}} /><label  htmlFor="RadioButton2" /></div>
        <div id="wb_RadioButton3" style={{position: 'absolute', left: '510px', top: '381px', width: '14px', height: '24px', zIndex: 34}}>
          <input type="radio" id="RadioButton3" name="CONTROLAMBIENTAL" defaultValue="QUEJA"  onChange={(value)=> this.setState({MOTIVO:value.target.value})} style={{position: 'absolute', left: 0, top: 0}} /><label  htmlFor="RadioButton3" /></div>
        <div id="wb_RadioButton4" style={{position: 'absolute', left: '682px', top: '381px', width: '14px', height: '24px', zIndex: 35}}>
          <input type="radio" id="RadioButton4" name="CONTROLAMBIENTAL" defaultValue="BROTE" onChange={(value)=> this.setState({MOTIVO:value.target.value})} style={{position: 'absolute', left: 0, top: 0}} /><label  htmlFor="RadioButton4" /></div>
        <div id="wb_RadioButton5" style={{position: 'absolute', left: '832px', top: '381px', width: '14px', height: '24px', zIndex: 36}}>
          <input type="radio" id="RadioButton5" name="CONTROLAMBIENTAL" defaultValue="INTOXICACION"   onChange={(value)=> this.setState({MOTIVO:value.target.value})} style={{position: 'absolute', left: 0, top: 0}} /><label  htmlFor="RadioButton5" /></div>
        <label   id="Label17" style={{position: 'absolute', left: '243px', top: '376px', width: '87px', height: '16px', lineHeight: '16px', zIndex: 37}}>PROGRAMA</label>
        <label   id="Label18" style={{position: 'absolute', left: '385px', top: '376px', width: '54px', height: '16px', lineHeight: '16px', zIndex: 38}}>CMTRF</label>
        <label   id="Label19" style={{position: 'absolute', left: '524px', top: '376px', width: '54px', height: '16px', lineHeight: '16px', zIndex: 39}}>QUEJA</label>
        <label   id="Label20" style={{position: 'absolute', left: '701px', top: '376px', width: '54px', height: '16px', lineHeight: '16px', zIndex: 40}}>BROTE</label>
        <label   id="Label21" style={{position: 'absolute', left: '848px', top: '376px', width: '123px', height: '16px', lineHeight: '16px', zIndex: 41}}>INTOXICACION</label>
        <div id="wb_RadioButton6" style={{position: 'absolute', left: '479px', top: '466px', width: '14px', height: '24px', zIndex: 42}}>
          <input type="radio" id="RadioButton6" name="trprioridad" defaultValue="NORMAL" onChange={(value)=> this.setState({PRIORIDAD:value.target.value})} style={{position: 'absolute', left: 0, top: 0}} /><label  htmlFor="RadioButton6" /></div>
        <label   id="Label22" style={{position: 'absolute', left: '497px', top: '462px', width: '87px', height: '16px', lineHeight: '16px', zIndex: 43}}>NORMAL</label>
        <div id="wb_RadioButton7" style={{position: 'absolute', left: '603px', top: '466px', width: '14px', height: '24px', zIndex: 44}}>
          <input type="radio" id="RadioButton7" name="trprioridad" defaultValue="URGENTE" onChange={(value)=> this.setState({PRIORIDAD:value.target.value})} style={{position: 'absolute', left: 0, top: 0}} /><label  htmlFor="RadioButton7" /></div>
        <label   id="Label23" style={{position: 'absolute', left: '621px', top: '462px', width: '87px', height: '16px', lineHeight: '16px', zIndex: 45}}>URGENTE</label>
        <label   id="Label24" style={{position: 'absolute', left: '353px', top: '462px', width: '65px', height: '16px', lineHeight: '16px', zIndex: 46}}>Prioridad</label>
        <label   id="Label25" style={{position: 'absolute', left: '123px', top: '496px', width: '37px', height: '16px', lineHeight: '16px', zIndex: 47}}>Clave</label>
        <label   id="Label26" style={{position: 'absolute', left: '208px', top: '496px', width: '65px', height: '16px', lineHeight: '16px', zIndex: 48}}>Examen</label>
             
         
        <input type="text" id="E1" style={{position: 'absolute', left: '123px', top: '520px', width: '56px', height: '16px', zIndex: 49} }
        name="E1" onChange={this.twoCalls}  spellCheck="false" />         
        <input type="text" id="EXAM1" style={{position: 'absolute', left: '208px', top: '520px', width: '328px', height: '16px', zIndex: 50}} 
        name="EXAM1" value={this.state.TXE1} onChange={(value)=> this.setState({TXE1:value.target.value})} disabled/>
        
        <input type="text" id="E2" disabled style={{position: 'absolute', left: '123px', top: '549px', width: '56px', height: '16px', zIndex: 51}} 
        name="E2"  value={this.state.E2} spellCheck="false" onChange={(value)=> this.setState({E2:value.target.value})} />
        <input type="text" id="EXAM2" disabled style={{position: 'absolute', left: '208px', top: '549px', width: '328px', height: '16px', zIndex: 52}} 
        name="EXAM2" value={this.state.EXAM2} spellCheck="false" onChange={(value)=> this.setState({EXAM2:value.target.value})}/>
        
        <input type="text" id="E3" disabled
        style={{position: 'absolute', left: '123px', top: '578px', width: '56px', height: '16px', zIndex: 53}} 
        name="E3" value={this.state.E3} spellCheck="false" onChange={(value)=> this.setState({E3:value.target.value})}/>
        <input type="text" id="EXAM3" disabled
         style={{position: 'absolute', left: '208px', top: '578px', width: '328px', height: '16px', zIndex: 54}} 
         name="EXAM3" value={this.state.EXAM3} spellCheck="false" onChange={(value)=> this.setState({EXAM3:value.target.value})} />

        <input type="text" id="E4" disabled
        style={{position: 'absolute', left: '123px', top: '607px', width: '56px', height: '16px', zIndex: 55}} 
        name="E4" onChange={this.onChange}  value={this.state.E4} spellCheck="false" />
        <input type="text" id="EXAM4" disabled
        style={{position: 'absolute', left: '208px', top: '607px', width: '328px', height: '16px', zIndex: 56}} 
        name="EXAM4" onChange={this.onChange} value={this.state.EXAM4} spellCheck="false" />
       
        <input type="text" id="E5" disabled
        style={{position: 'absolute', left: '123px', top: '636px', width: '56px', height: '16px', zIndex: 57}} 
        name="E5" onChange={this.onChange} value={this.state.E5} spellCheck="false" />
        <input type="text" id="EXAM5" disabled
        style={{position: 'absolute', left: '208px', top: '636px', width: '328px', height: '16px', zIndex: 58}} 
        name="EXAM5" onChange={this.onChange} value={this.state.EXAM5} spellCheck="false" />
        
        <input type="text" id="E6" disabled
        style={{position: 'absolute', left: '571px', top: '521px', width: '56px', height: '16px', zIndex: 59}}
         name="E6" onChange={this.onChange} value={this.state.E6} spellCheck="false" />
        <input type="text" id="EXAM6" disabled
        style={{position: 'absolute', left: '647px', top: '521px', width: '328px', height: '16px', zIndex: 60}}
         name="EXAM6" onChange={this.onChange} value={this.state.EXAM6} spellCheck="false" />
        
        <input type="text" id="E7" disabled
        style={{position: 'absolute', left: '571px', top: '550px', width: '56px', height: '16px', zIndex: 61}}
         name="E7" onChange={this.onChange} value={this.state.E7} spellCheck="false" />
        <input type="text" id="EXAM7" disabled
        style={{position: 'absolute', left: '647px', top: '550px', width: '328px', height: '16px', zIndex: 62}}
         name="EXAM7" onChange={this.onChange} value={this.state.EXAM7} spellCheck="false" />
        
        <input type="text" id="E8" disabled
        style={{position: 'absolute', left: '571px', top: '579px', width: '56px', height: '16px', zIndex: 63}}
         name="E8" onChange={this.onChange} value={this.state.E8} spellCheck="false" />
        <input type="text" id="EXAM8" disabled
        style={{position: 'absolute', left: '647px', top: '579px', width: '328px', height: '16px', zIndex: 64}} 
        name="EXAM8" onChange={this.onChange} value={this.state.EXAM8} spellCheck="false" />
        
        <input type="text" id="E9" disabled
        style={{position: 'absolute', left: '571px', top: '608px', width: '56px', height: '16px', zIndex: 65}} 
        name="E9" onChange={this.onChange} value={this.state.E9} spellCheck="false" />
        <input type="text" id="EXAM9" disabled
        style={{position: 'absolute', left: '647px', top: '608px', width: '328px', height: '16px', zIndex: 66}}
         name="EXAM9" onChange={this.onChange} value={this.state.EXAM9} spellCheck="false" />
        
        <input type="text" id="E10" disabled
        style={{position: 'absolute', left: '571px', top: '637px', width: '56px', height: '16px', zIndex: 67}}
         name="E10" onChange={this.onChange} value={this.state.E10} spellCheck="false" />
        <input type="text" id="EXAM10" disabled
        style={{position: 'absolute', left: '647px', top: '637px', width: '328px', height: '16px', zIndex: 68}}
         name="EXAM10" onChange={this.onChange} value={this.state.EXAM10} spellCheck="false" />
        
        <label   id="Label27" style={{position: 'absolute', left: '231px', top: '428px', width: '701px', height: '22px', lineHeight: '22px', zIndex: 69}}>BIOLOGIA MOLECULAR / CONTROL MICROBIOLOGICO ANALISIS SOLICITADO</label>
        <label   id="Label29" style={{position: 'absolute', left: '647px', top: '496px', width: '65px', height: '16px', lineHeight: '16px', zIndex: 70}}>Examen</label>
        <label   id="Label30" style={{position: 'absolute', left: '571px', top: '496px', width: '37px', height: '16px', lineHeight: '16px', zIndex: 71}}>Clave</label>
        <input type="submit" id="Button2"  defaultValue="Guardar" style={{position: 'absolute', left: '715px', top: '710px', width: '111px', height: '40px', zIndex: 72}} />
        <input type="submit" id="Button4"  defaultValue="Hojas de Trabajo" style={{position: 'absolute', left: '838px', top: '710px', width: '144px', height: '40px', zIndex: 73}} />
        <hr id="Line6" style={{position: 'absolute', left: '109px', top: '683px', width: '870px', zIndex: 74}} />
        
        <button className="btn btn-primary font-weight-bold" href="#modalprocedencia"
              data-toggle="modal" type="button" style={{position: 'absolute', left: '373px', top: '154px', width: '30px', height: '17px', zIndex: 76}} >
               </button>

        <button className="btn btn-primary font-weight-bold" href="#modaltipomuestra"
              data-toggle="modal" type="button"
               style={{position: 'absolute', left: '374px', top: '182px', width: '30px', height: '15px', zIndex: 77}} ></button>

        <hr id="Line2" style={{position: 'absolute', left: '120px', top: '410px', width: '870px', zIndex: 78}} />
        <hr id="Line4" style={{position: 'absolute', left: '120px', top: '320px', width: '870px', zIndex: 79}} />
      </div>
     

<div className="modal fade" id="modalprocedencia"     >
<div className="modal-dialog modal-lg" role="document">
               <div className="modal-content">
                 <div  className="modal-header">
                     <button id="btnn" tyle="button" className="close"
                     data-dismiss="modal"
                     aria-hidden="true">&times;</button>
                         <h5 className="modal-title">PROCEDENCIA</h5>
                 </div>
                     <div className="modal-body">
                         <h4 className="modal-title"></h4>
                       <TblProcedencia
                        //data={this.data}>
                        callback={this.getResponseH}>
                       </TblProcedencia>
                     </div>

                     <div className="modal-footer">
                     <button className="btn btn-secondary"
                     data-dismiss="modal">Cerrar</button>
                     </div>
               </div>
</div>
</div>

                                
<div className="modal fade" id="modaltipomuestra"   >
<div className="modal-dialog modal-lg" role="document">
               <div className="modal-content">
                 <div  className="modal-header">
                     <button  tyle="button" className="close"
                     data-dismiss="modal"
                     aria-hidden="true">&times;</button>
                         <h5 className="modal-title">TIPO MUESTRA</h5>
                     </div>
                     <div className="modal-body">
                         <h4 className="modal-title"></h4>
                       <Tbltipomuestra
                        //data={this.data}>
                        callback={this.getResponseTipoH}>
                       </Tbltipomuestra>
                     </div>

                     <div className="modal-footer">
                     <button className="btn btn-secondary"
                     data-dismiss="modal">Cerrar</button>
                     </div>
               </div>

</div>
</div>
</div>

);
}

sendSave(){
const baseUrl = "http://localhost:3000/Rtblmuestra_recep/create"
const datapost = {
MUESTRA: this.state.MUESTRA,
MUESTRA2: this.state.MUESTRA2,
FEC_REC: this.state.FEC_REC,
HOR_REC: this.state.HOR_REC,
CLAPRO: this.state.CLAPRO,
CLAMUE: this.state.CLAMUE,
AMPLIAR_TM: this.state.AMPLIAR_TM,
TEM_REC: this.state.TEM_REC,
CONFIRMAR: this.state.CONFIRMAR,
OBSERVA: this.state.OBSERVA,
AM: this.state.AM,
AF: this.state.AF,
AMP: this.state.AMP,
HT: this.state.HT,
VALIDADO: this.state.VALIDADO,
MOTIVO: this.state.MOTIVO,
PRIORIDAD: this.state.PRIORIDAD,
E1: this.state.E1,
EXAM1: this.state.EXAM1,
E2: this.state.E2,
EXAM2: this.state.EXAM2,
E3: this.state.E3,
EXAM3: this.state.EXAM3,
E4: this.state.E4,
EXAM4: this.state.EXAM4,
E5: this.state.E5,
EXAM5: this.state.EXAM5,
E6: this.state.E6,
EXAM6: this.state.EXAM6,
E7: this.state.E7,
EXAM7: this.state.EXAM7,
E8: this.state.E8,
EXAM8: this.state.EXAM8,
E9: this.state.E9,
EXAM9: this.state.EXAM9,
E10: this.state.E10,
EXAM10: this.state.EXAM10,
MODIFICADO: this.state.MODIFICADO,
FEC_LAB: this.state.FEC_LAB,
HOR_LAB: this.state.HOR_LAB,
CLAREC: this.state.CLAREC
}
axios.post(baseUrl,datapost)
      .then(response=>{
 if (response.data.success===true) {
  console.log(response.data.message)
}
else {
  console.log(response.data.message)
}
}).catch(error=>{
  console.log("Error 34 "+error)
 })
 }
}

export default EditComponent;
