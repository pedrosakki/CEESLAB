 const controllers = {}
var sequelize = require('../model/database');
var tblcausas_causas = require('../model/tblcausas_causas');

//METODO GET//

controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tblcausas_causas.findAll({
where: {idtblcausas_causas: id }  })
.then(function(data){
    return data;})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}


//METODO LIST//

controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tblcausas_causas.findAll();
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}



//METODO CREATE//
controllers.create = async (req, res)=>{
const  {CLACAU,CAUSA}=req.body;
const data = await tblcausas_causas.create({
CLACAU: CLACAU,
CAUSA: CAUSA
}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data
})
}


//METODO UPDATE//
controllers.update = async (req, res)=>{
  const { id } = req.params;
const  {CLACAU,CAUSA}=req.body;

 const data = await tblcausas_causas.update({
CLACAU: CLACAU,
CAUSA: CAUSA
   },{
          where: { idtblcausas_causas: id}
     })
  .then( function(data){
    return data;
      })
       .catch(error => {
        return error;
   }) 
   res.json({success:true, data:data, message:"Updated successful"});
 }



 module.exports = controllers;
