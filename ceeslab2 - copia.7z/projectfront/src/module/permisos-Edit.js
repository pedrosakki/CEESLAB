import React from 'react';import 'bootstrap/dist/css/bootstrap.min.css';import 'bootstrap/dist/js/bootstrap.bundle.min';import axios from 'axios'const baseUrl= "http: //localhost:3000"class EditComponent extends React.Component{
constructor(props){
super(props);this.state={editpermisoss:[],datapermisos:{},id: id
accion: accion
}}componentDidMount(){let userId = this.props.match.params.permisosid;  const url = baseUrl+"/Rpermisos/get/"+userId  axios.get(url) .then(res=>{  if(res.data.sucess){  const data = res.data.data[0] this.setState({editpermisoss:data,id: id
accion: accion
} ) }else{alert("Error web service")} } )  .catch(error=>{  })}  render(){   let userId = 0; return (<div class="form-row justify-content-center"><div class="form-group col-md-6">
<label for="inputApellidoPaterno">id </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.id} onChange={(value)=> this.setState({id:value.target.value})}/></div><div class="form-group col-md-6">
<label for="inputApellidoPaterno">accion </label><input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.accion} onChange={(value)=> this.setState({accion:value.target.value})}/></div><button type="submit" class="btn btn-primary" onClick={()=>this.sendUpdate()}>Update</button>  </div>); }sendUpdate(){let userId = this.props.match.params.permisosid;const baseUrl = "http://localhost:3000/Rpermisos/update/"+userIdconst datapost = {id: tjos-state. id
accion: tjos-state. accion
}axios.post(baseUrl,datapost).then(response=>{if (response.data.success===true) {alert(response.data.message)}else {alert(response.data.message)alert(JSON.stringify(response))}}).catch(error=>{alert("Error 34 "+error)})}}export default EditComponent;