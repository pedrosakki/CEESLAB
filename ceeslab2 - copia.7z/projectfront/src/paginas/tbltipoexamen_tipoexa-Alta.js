import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios';
class EditComponent extends React.Component{
constructor(props){
super(props);
this.state = {
CLAEXA:"",
EXAMEN:"",
UNIDAD:"",
METODO:"",
TECNICA:"",
REFERENCIA:"",
GRUPO:""
}
}
render(){
  return (
<div>
 <div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAEXA </label>
<input type="text" class="form-control" placeholder="CLAEXA" value={this.state.CLAEXA} onChange={(value)=> this.setState({CLAEXA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EXAMEN </label>
<input type="text" class="form-control" placeholder="EXAMEN" value={this.state.EXAMEN} onChange={(value)=> this.setState({EXAMEN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">UNIDAD </label>
<input type="text" class="form-control" placeholder="UNIDAD" value={this.state.UNIDAD} onChange={(value)=> this.setState({UNIDAD:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">METODO </label>
<input type="text" class="form-control" placeholder="METODO" value={this.state.METODO} onChange={(value)=> this.setState({METODO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TECNICA </label>
<input type="text" class="form-control" placeholder="TECNICA" value={this.state.TECNICA} onChange={(value)=> this.setState({TECNICA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">REFERENCIA </label>
<input type="text" class="form-control" placeholder="REFERENCIA" value={this.state.REFERENCIA} onChange={(value)=> this.setState({REFERENCIA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">GRUPO </label>
<input type="text" class="form-control" placeholder="GRUPO" value={this.state.GRUPO} onChange={(value)=> this.setState({GRUPO:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendSave()}>Save</button>
</div>
</div>
);
}
  sendSave(){
const baseUrl = "http://localhost:3000/Rtbltipoexamen_tipoexa/create"
const datapost = {
CLAEXA: this.state.CLAEXA,
EXAMEN: this.state.EXAMEN,
UNIDAD: this.state.UNIDAD,
METODO: this.state.METODO,
TECNICA: this.state.TECNICA,
REFERENCIA: this.state.REFERENCIA,
GRUPO: this.state.GRUPO
}
axios.post(baseUrl,datapost)
      .then(response=>{
 if (response.data.success===true) {
  alert(response.data.message)
}
else {
alert(response.data.message)
}
}).catch(error=>{
   alert("Error 34 "+error)
 })
 }
}
export default EditComponent;
