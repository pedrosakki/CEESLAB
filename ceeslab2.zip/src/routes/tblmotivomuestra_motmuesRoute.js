const express = require('express');
const router = express.Router();
const tblmotivomuestra_motmuesController = require('../Controllers/tblmotivomuestra_motmuesController')


router.post('/update/:id',tblmotivomuestra_motmuesController.update)
router.get('/get/:id', tblmotivomuestra_motmuesController.get)
router.get('/list', tblmotivomuestra_motmuesController.list);
router.post('/create', tblmotivomuestra_motmuesController.create);


module.exports = router;
