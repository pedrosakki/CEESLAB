const express = require('express');
const router = express.Router();
const tblcalidad8Controller = require('../Controllers/tblcalidad8Controller')


router.post('/update/:id',tblcalidad8Controller.update)
router.get('/get/:id', tblcalidad8Controller.get)
router.get('/list', tblcalidad8Controller.list);
router.post('/create', tblcalidad8Controller.create);


module.exports = router;
