import React, { Component } from 'react'

class TodasReg extends Component {
  constructor() {
    super()
    this.state = {
      id:'',
      nombre: '',
      subregion: '',
      estado:'',
      errors: {}
    }
  }

  componentDidMount() {

  }

  render() {
    return (
      <div className="container">

  <div className="row">

      <div className="panel panel-default">
        <div className="panel-heading"></div>
        <table className="table col-md-6 mx-auto">
          <tbody>
          <tr>
            <td>ID</td>
            <td>NOMBRE</td>
            <td>SUBREGION</td>
            <td>ESTADO</td>

          </tr>
            <tr>
              <td>{this.state.id}</td>
              <td>{this.state.nombre}</td>
              <td>{this.state.subregion}</td>
              <td>{this.state.estado}</td>

            </tr>
          </tbody>
        </table>
      </div>
      </div>
  </div>
    )
  }
}

export default TodasReg
