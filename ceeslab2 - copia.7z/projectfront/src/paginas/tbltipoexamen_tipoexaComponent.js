//import '../css/dataTables.bootstrap4.min.css'
import React, { Component } from 'react'
import { BrowserRouter as Router, Route } from 'react-router-dom'
import axios from 'axios'


class EXMENES extends Component{
export  valorexamene(examen){
 

  var baseeUrl ="http://localhost:3000"
  const url = baseeUrl+"/Rtbltipoexamen_tipoexa/examen/"+value
  axios.get(url)
  .then(res=>{
    if(res.data.sucess){
      const result = res.data.data[0]
      const valor = value
    
    alert(value)
alert(result.EXAMEN)
return (valor) }
else{
  
return result.EXAMEN
//alert("Error web service")
} } )
  .catch(error=>{
  })

  
}

}

export default EXMENES;