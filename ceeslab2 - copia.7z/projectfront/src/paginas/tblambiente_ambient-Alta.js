import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios';
class EditComponent extends React.Component{
constructor(props){
super(props);
this.state = {
MUESTRA:"",
CLAPRO:"",
CLAMUE:"",
AMPLIAR_TM:"",
DOCTO:"",
NUM_DOC:"",
MARCA:"",
PRESEN:"",
LOTE:"",
CADUCIDAD:"",
FEC_MUES:"",
HOR_MUES:"",
TEM_MOT:"",
MOT_MUES:"",
PUNT_MUES:"",
FEC_ENS1:"",
FEC_ENS2:"",
FEC_ENS3:"",
FEC_ENS4:"",
FEC_ENS5:"",
FEC_ENS6:"",
FEC_DES:"",
NOM_GIRO:"",
RFC:"",
DOMICILIO:"",
COLONIA:"",
LOCALIDAD:"",
CP:"",
CLAEDO:"",
CLAMUN:"",
OBSERV:"",
MA_UFCGM:"",
MA_UFC:"",
OCT_UFCGM:"",
OCT_UFC:"",
OCT_UFC100:"",
OCT_NMPGM:"",
OCT_NMP100:"",
OFC_NMPGM:"",
OCF_NMP100:"",
SALMO25GM:"",
SALMO30G:"",
SALMO100ML:"",
S_AREUS:"",
LEVADURAS:"",
HONGOS:"",
ECOLINMPGM:"",
ECOLI100ML:"",
INHIBIDORE:"",
VCO1:"",
VCONOO1:"",
VP_NMP:"",
ENTEROCOCO:"",
E_ESTAFILO:"",
SALMO1000:"",
SALMO_EN_C:"",
SALMO_EN_R:"",
HUMEDAD:"",
FOSFATSA:"",
NUTRITOS:"",
FECULA:"",
DERCLOCUAL:"",
OXIDANTES:"",
SALESCUATE:"",
FLUOR:"",
YODO:"",
YODATO_K:"",
M_EXTRANA:"",
PH:"",
OLOR:"",
UNI_COLOR:"",
SDT:"",
CLORUROS:"",
SULFATOS:"",
DUREZA_TOT:"",
FLUORUROS:"",
CRL_SEMICU:"",
CRL_CUANTI:"",
CLENBUTERO:"",
AC_FOLICO:"",
DET_MIC:"",
DET_FIS:"",
FN_MI:"",
FN_FI:"",
DE_FN_MI:"",
DEF_FN_FI:"",
FN1:"",
FN2:"",
FN3:"",
FN4:"",
FN5:"",
FN6:"",
FN7:"",
FN8:"",
FN9:"",
FN10:"",
FN11:"",
FN12:"",
FN13:"",
FN14:"",
FN15:"",
FN16:"",
FN17:"",
FN18:"",
FN19:"",
FN20:"",
FN21:"",
FN22:"",
FN23:"",
FN24:"",
FN25:"",
FN26:"",
FN27:"",
FN28:"",
FN29:"",
FN30:"",
FN31:"",
FN32:"",
FN33:"",
FN34:"",
FN35:"",
FN36:"",
FN37:"",
FN38:"",
FN39:"",
FN40:"",
FN41:"",
FN42:"",
FN43:"",
FN44:"",
FN45:"",
FN46:"",
FN47:"",
FN48:"",
FN49:"",
FN50:"",
FN51:"",
FN52:"",
FN53:"",
FN54:"",
FN55:"",
FN56:"",
FN57:"",
FN73:"",
FN74:"",
FN76:"",
FN77:"",
FN78:"",
FN79:"",
FN80:"",
FN81:"",
FN82:"",
AG:"",
AL:"",
AS:"",
B:"",
BA:"",
CD:"",
CR:"",
CU:"",
FE:"",
MN:"",
NA:"",
NI:"",
PB:"",
SE:"",
ZN:"",
VIDRIADO:"",
DECO_INT:"",
COLOR:"",
P_ANALIZAD:"",
VOLUMEN_ML:"",
SOL_US:"",
C_CD:"",
C_PB:"",
LIMITES:"",
FN58:"",
FN59:"",
FN60:"",
FN61:"",
FN62:"",
FN63:"",
FN64:"",
FN65:"",
FN66:"",
FN67:"",
FN68:"",
FN70:"",
FN71:"",
FN72:"",
FN75:"",
FEC_CAP:"",
FEC_IMP:"",
FEC_VAL:"",
AM:"",
AF:"",
AMP:"",
AT:"",
VALIDADO:"",
CLACAU:"",
SUPLEMENTO:"",
NOTAS:""
}
}
render(){
  return (
<div>
 <div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MUESTRA </label>
<input type="text" class="form-control" placeholder="MUESTRA" value={this.state.MUESTRA} onChange={(value)=> this.setState({MUESTRA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAPRO </label>
<input type="text" class="form-control" placeholder="CLAPRO" value={this.state.CLAPRO} onChange={(value)=> this.setState({CLAPRO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAMUE </label>
<input type="text" class="form-control" placeholder="CLAMUE" value={this.state.CLAMUE} onChange={(value)=> this.setState({CLAMUE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">AMPLIAR_TM </label>
<input type="text" class="form-control" placeholder="AMPLIAR_TM" value={this.state.AMPLIAR_TM} onChange={(value)=> this.setState({AMPLIAR_TM:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DOCTO </label>
<input type="text" class="form-control" placeholder="DOCTO" value={this.state.DOCTO} onChange={(value)=> this.setState({DOCTO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">NUM_DOC </label>
<input type="text" class="form-control" placeholder="NUM_DOC" value={this.state.NUM_DOC} onChange={(value)=> this.setState({NUM_DOC:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MARCA </label>
<input type="text" class="form-control" placeholder="MARCA" value={this.state.MARCA} onChange={(value)=> this.setState({MARCA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">PRESEN </label>
<input type="text" class="form-control" placeholder="PRESEN" value={this.state.PRESEN} onChange={(value)=> this.setState({PRESEN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">LOTE </label>
<input type="text" class="form-control" placeholder="LOTE" value={this.state.LOTE} onChange={(value)=> this.setState({LOTE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CADUCIDAD </label>
<input type="text" class="form-control" placeholder="CADUCIDAD" value={this.state.CADUCIDAD} onChange={(value)=> this.setState({CADUCIDAD:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_MUES </label>
<input type="text" class="form-control" placeholder="FEC_MUES" value={this.state.FEC_MUES} onChange={(value)=> this.setState({FEC_MUES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">HOR_MUES </label>
<input type="text" class="form-control" placeholder="HOR_MUES" value={this.state.HOR_MUES} onChange={(value)=> this.setState({HOR_MUES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TEM_MOT </label>
<input type="text" class="form-control" placeholder="TEM_MOT" value={this.state.TEM_MOT} onChange={(value)=> this.setState({TEM_MOT:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MOT_MUES </label>
<input type="text" class="form-control" placeholder="MOT_MUES" value={this.state.MOT_MUES} onChange={(value)=> this.setState({MOT_MUES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">PUNT_MUES </label>
<input type="text" class="form-control" placeholder="PUNT_MUES" value={this.state.PUNT_MUES} onChange={(value)=> this.setState({PUNT_MUES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_ENS1 </label>
<input type="text" class="form-control" placeholder="FEC_ENS1" value={this.state.FEC_ENS1} onChange={(value)=> this.setState({FEC_ENS1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_ENS2 </label>
<input type="text" class="form-control" placeholder="FEC_ENS2" value={this.state.FEC_ENS2} onChange={(value)=> this.setState({FEC_ENS2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_ENS3 </label>
<input type="text" class="form-control" placeholder="FEC_ENS3" value={this.state.FEC_ENS3} onChange={(value)=> this.setState({FEC_ENS3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_ENS4 </label>
<input type="text" class="form-control" placeholder="FEC_ENS4" value={this.state.FEC_ENS4} onChange={(value)=> this.setState({FEC_ENS4:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_ENS5 </label>
<input type="text" class="form-control" placeholder="FEC_ENS5" value={this.state.FEC_ENS5} onChange={(value)=> this.setState({FEC_ENS5:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_ENS6 </label>
<input type="text" class="form-control" placeholder="FEC_ENS6" value={this.state.FEC_ENS6} onChange={(value)=> this.setState({FEC_ENS6:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_DES </label>
<input type="text" class="form-control" placeholder="FEC_DES" value={this.state.FEC_DES} onChange={(value)=> this.setState({FEC_DES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">NOM_GIRO </label>
<input type="text" class="form-control" placeholder="NOM_GIRO" value={this.state.NOM_GIRO} onChange={(value)=> this.setState({NOM_GIRO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RFC </label>
<input type="text" class="form-control" placeholder="RFC" value={this.state.RFC} onChange={(value)=> this.setState({RFC:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DOMICILIO </label>
<input type="text" class="form-control" placeholder="DOMICILIO" value={this.state.DOMICILIO} onChange={(value)=> this.setState({DOMICILIO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">COLONIA </label>
<input type="text" class="form-control" placeholder="COLONIA" value={this.state.COLONIA} onChange={(value)=> this.setState({COLONIA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">LOCALIDAD </label>
<input type="text" class="form-control" placeholder="LOCALIDAD" value={this.state.LOCALIDAD} onChange={(value)=> this.setState({LOCALIDAD:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CP </label>
<input type="text" class="form-control" placeholder="CP" value={this.state.CP} onChange={(value)=> this.setState({CP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAEDO </label>
<input type="text" class="form-control" placeholder="CLAEDO" value={this.state.CLAEDO} onChange={(value)=> this.setState({CLAEDO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAMUN </label>
<input type="text" class="form-control" placeholder="CLAMUN" value={this.state.CLAMUN} onChange={(value)=> this.setState({CLAMUN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OBSERV </label>
<input type="text" class="form-control" placeholder="OBSERV" value={this.state.OBSERV} onChange={(value)=> this.setState({OBSERV:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MA_UFCGM </label>
<input type="text" class="form-control" placeholder="MA_UFCGM" value={this.state.MA_UFCGM} onChange={(value)=> this.setState({MA_UFCGM:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MA_UFC </label>
<input type="text" class="form-control" placeholder="MA_UFC" value={this.state.MA_UFC} onChange={(value)=> this.setState({MA_UFC:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OCT_UFCGM </label>
<input type="text" class="form-control" placeholder="OCT_UFCGM" value={this.state.OCT_UFCGM} onChange={(value)=> this.setState({OCT_UFCGM:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OCT_UFC </label>
<input type="text" class="form-control" placeholder="OCT_UFC" value={this.state.OCT_UFC} onChange={(value)=> this.setState({OCT_UFC:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OCT_UFC100 </label>
<input type="text" class="form-control" placeholder="OCT_UFC100" value={this.state.OCT_UFC100} onChange={(value)=> this.setState({OCT_UFC100:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OCT_NMPGM </label>
<input type="text" class="form-control" placeholder="OCT_NMPGM" value={this.state.OCT_NMPGM} onChange={(value)=> this.setState({OCT_NMPGM:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OCT_NMP100 </label>
<input type="text" class="form-control" placeholder="OCT_NMP100" value={this.state.OCT_NMP100} onChange={(value)=> this.setState({OCT_NMP100:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OFC_NMPGM </label>
<input type="text" class="form-control" placeholder="OFC_NMPGM" value={this.state.OFC_NMPGM} onChange={(value)=> this.setState({OFC_NMPGM:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OCF_NMP100 </label>
<input type="text" class="form-control" placeholder="OCF_NMP100" value={this.state.OCF_NMP100} onChange={(value)=> this.setState({OCF_NMP100:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SALMO25GM </label>
<input type="text" class="form-control" placeholder="SALMO25GM" value={this.state.SALMO25GM} onChange={(value)=> this.setState({SALMO25GM:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SALMO30G </label>
<input type="text" class="form-control" placeholder="SALMO30G" value={this.state.SALMO30G} onChange={(value)=> this.setState({SALMO30G:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SALMO100ML </label>
<input type="text" class="form-control" placeholder="SALMO100ML" value={this.state.SALMO100ML} onChange={(value)=> this.setState({SALMO100ML:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">S_AREUS </label>
<input type="text" class="form-control" placeholder="S_AREUS" value={this.state.S_AREUS} onChange={(value)=> this.setState({S_AREUS:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">LEVADURAS </label>
<input type="text" class="form-control" placeholder="LEVADURAS" value={this.state.LEVADURAS} onChange={(value)=> this.setState({LEVADURAS:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">HONGOS </label>
<input type="text" class="form-control" placeholder="HONGOS" value={this.state.HONGOS} onChange={(value)=> this.setState({HONGOS:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ECOLINMPGM </label>
<input type="text" class="form-control" placeholder="ECOLINMPGM" value={this.state.ECOLINMPGM} onChange={(value)=> this.setState({ECOLINMPGM:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ECOLI100ML </label>
<input type="text" class="form-control" placeholder="ECOLI100ML" value={this.state.ECOLI100ML} onChange={(value)=> this.setState({ECOLI100ML:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">INHIBIDORE </label>
<input type="text" class="form-control" placeholder="INHIBIDORE" value={this.state.INHIBIDORE} onChange={(value)=> this.setState({INHIBIDORE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">VCO1 </label>
<input type="text" class="form-control" placeholder="VCO1" value={this.state.VCO1} onChange={(value)=> this.setState({VCO1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">VCONOO1 </label>
<input type="text" class="form-control" placeholder="VCONOO1" value={this.state.VCONOO1} onChange={(value)=> this.setState({VCONOO1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">VP_NMP </label>
<input type="text" class="form-control" placeholder="VP_NMP" value={this.state.VP_NMP} onChange={(value)=> this.setState({VP_NMP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ENTEROCOCO </label>
<input type="text" class="form-control" placeholder="ENTEROCOCO" value={this.state.ENTEROCOCO} onChange={(value)=> this.setState({ENTEROCOCO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">E_ESTAFILO </label>
<input type="text" class="form-control" placeholder="E_ESTAFILO" value={this.state.E_ESTAFILO} onChange={(value)=> this.setState({E_ESTAFILO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SALMO1000 </label>
<input type="text" class="form-control" placeholder="SALMO1000" value={this.state.SALMO1000} onChange={(value)=> this.setState({SALMO1000:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SALMO_EN_C </label>
<input type="text" class="form-control" placeholder="SALMO_EN_C" value={this.state.SALMO_EN_C} onChange={(value)=> this.setState({SALMO_EN_C:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SALMO_EN_R </label>
<input type="text" class="form-control" placeholder="SALMO_EN_R" value={this.state.SALMO_EN_R} onChange={(value)=> this.setState({SALMO_EN_R:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">HUMEDAD </label>
<input type="text" class="form-control" placeholder="HUMEDAD" value={this.state.HUMEDAD} onChange={(value)=> this.setState({HUMEDAD:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FOSFATSA </label>
<input type="text" class="form-control" placeholder="FOSFATSA" value={this.state.FOSFATSA} onChange={(value)=> this.setState({FOSFATSA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">NUTRITOS </label>
<input type="text" class="form-control" placeholder="NUTRITOS" value={this.state.NUTRITOS} onChange={(value)=> this.setState({NUTRITOS:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FECULA </label>
<input type="text" class="form-control" placeholder="FECULA" value={this.state.FECULA} onChange={(value)=> this.setState({FECULA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DERCLOCUAL </label>
<input type="text" class="form-control" placeholder="DERCLOCUAL" value={this.state.DERCLOCUAL} onChange={(value)=> this.setState({DERCLOCUAL:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OXIDANTES </label>
<input type="text" class="form-control" placeholder="OXIDANTES" value={this.state.OXIDANTES} onChange={(value)=> this.setState({OXIDANTES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SALESCUATE </label>
<input type="text" class="form-control" placeholder="SALESCUATE" value={this.state.SALESCUATE} onChange={(value)=> this.setState({SALESCUATE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FLUOR </label>
<input type="text" class="form-control" placeholder="FLUOR" value={this.state.FLUOR} onChange={(value)=> this.setState({FLUOR:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">YODO </label>
<input type="text" class="form-control" placeholder="YODO" value={this.state.YODO} onChange={(value)=> this.setState({YODO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">YODATO_K </label>
<input type="text" class="form-control" placeholder="YODATO_K" value={this.state.YODATO_K} onChange={(value)=> this.setState({YODATO_K:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">M_EXTRANA </label>
<input type="text" class="form-control" placeholder="M_EXTRANA" value={this.state.M_EXTRANA} onChange={(value)=> this.setState({M_EXTRANA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">PH </label>
<input type="text" class="form-control" placeholder="PH" value={this.state.PH} onChange={(value)=> this.setState({PH:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OLOR </label>
<input type="text" class="form-control" placeholder="OLOR" value={this.state.OLOR} onChange={(value)=> this.setState({OLOR:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">UNI_COLOR </label>
<input type="text" class="form-control" placeholder="UNI_COLOR" value={this.state.UNI_COLOR} onChange={(value)=> this.setState({UNI_COLOR:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SDT </label>
<input type="text" class="form-control" placeholder="SDT" value={this.state.SDT} onChange={(value)=> this.setState({SDT:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLORUROS </label>
<input type="text" class="form-control" placeholder="CLORUROS" value={this.state.CLORUROS} onChange={(value)=> this.setState({CLORUROS:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SULFATOS </label>
<input type="text" class="form-control" placeholder="SULFATOS" value={this.state.SULFATOS} onChange={(value)=> this.setState({SULFATOS:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DUREZA_TOT </label>
<input type="text" class="form-control" placeholder="DUREZA_TOT" value={this.state.DUREZA_TOT} onChange={(value)=> this.setState({DUREZA_TOT:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FLUORUROS </label>
<input type="text" class="form-control" placeholder="FLUORUROS" value={this.state.FLUORUROS} onChange={(value)=> this.setState({FLUORUROS:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CRL_SEMICU </label>
<input type="text" class="form-control" placeholder="CRL_SEMICU" value={this.state.CRL_SEMICU} onChange={(value)=> this.setState({CRL_SEMICU:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CRL_CUANTI </label>
<input type="text" class="form-control" placeholder="CRL_CUANTI" value={this.state.CRL_CUANTI} onChange={(value)=> this.setState({CRL_CUANTI:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLENBUTERO </label>
<input type="text" class="form-control" placeholder="CLENBUTERO" value={this.state.CLENBUTERO} onChange={(value)=> this.setState({CLENBUTERO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">AC_FOLICO </label>
<input type="text" class="form-control" placeholder="AC_FOLICO" value={this.state.AC_FOLICO} onChange={(value)=> this.setState({AC_FOLICO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DET_MIC </label>
<input type="text" class="form-control" placeholder="DET_MIC" value={this.state.DET_MIC} onChange={(value)=> this.setState({DET_MIC:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DET_FIS </label>
<input type="text" class="form-control" placeholder="DET_FIS" value={this.state.DET_FIS} onChange={(value)=> this.setState({DET_FIS:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN_MI </label>
<input type="text" class="form-control" placeholder="FN_MI" value={this.state.FN_MI} onChange={(value)=> this.setState({FN_MI:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN_FI </label>
<input type="text" class="form-control" placeholder="FN_FI" value={this.state.FN_FI} onChange={(value)=> this.setState({FN_FI:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DE_FN_MI </label>
<input type="text" class="form-control" placeholder="DE_FN_MI" value={this.state.DE_FN_MI} onChange={(value)=> this.setState({DE_FN_MI:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DEF_FN_FI </label>
<input type="text" class="form-control" placeholder="DEF_FN_FI" value={this.state.DEF_FN_FI} onChange={(value)=> this.setState({DEF_FN_FI:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN1 </label>
<input type="text" class="form-control" placeholder="FN1" value={this.state.FN1} onChange={(value)=> this.setState({FN1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN2 </label>
<input type="text" class="form-control" placeholder="FN2" value={this.state.FN2} onChange={(value)=> this.setState({FN2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN3 </label>
<input type="text" class="form-control" placeholder="FN3" value={this.state.FN3} onChange={(value)=> this.setState({FN3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN4 </label>
<input type="text" class="form-control" placeholder="FN4" value={this.state.FN4} onChange={(value)=> this.setState({FN4:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN5 </label>
<input type="text" class="form-control" placeholder="FN5" value={this.state.FN5} onChange={(value)=> this.setState({FN5:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN6 </label>
<input type="text" class="form-control" placeholder="FN6" value={this.state.FN6} onChange={(value)=> this.setState({FN6:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN7 </label>
<input type="text" class="form-control" placeholder="FN7" value={this.state.FN7} onChange={(value)=> this.setState({FN7:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN8 </label>
<input type="text" class="form-control" placeholder="FN8" value={this.state.FN8} onChange={(value)=> this.setState({FN8:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN9 </label>
<input type="text" class="form-control" placeholder="FN9" value={this.state.FN9} onChange={(value)=> this.setState({FN9:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN10 </label>
<input type="text" class="form-control" placeholder="FN10" value={this.state.FN10} onChange={(value)=> this.setState({FN10:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN11 </label>
<input type="text" class="form-control" placeholder="FN11" value={this.state.FN11} onChange={(value)=> this.setState({FN11:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN12 </label>
<input type="text" class="form-control" placeholder="FN12" value={this.state.FN12} onChange={(value)=> this.setState({FN12:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN13 </label>
<input type="text" class="form-control" placeholder="FN13" value={this.state.FN13} onChange={(value)=> this.setState({FN13:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN14 </label>
<input type="text" class="form-control" placeholder="FN14" value={this.state.FN14} onChange={(value)=> this.setState({FN14:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN15 </label>
<input type="text" class="form-control" placeholder="FN15" value={this.state.FN15} onChange={(value)=> this.setState({FN15:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN16 </label>
<input type="text" class="form-control" placeholder="FN16" value={this.state.FN16} onChange={(value)=> this.setState({FN16:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN17 </label>
<input type="text" class="form-control" placeholder="FN17" value={this.state.FN17} onChange={(value)=> this.setState({FN17:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN18 </label>
<input type="text" class="form-control" placeholder="FN18" value={this.state.FN18} onChange={(value)=> this.setState({FN18:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN19 </label>
<input type="text" class="form-control" placeholder="FN19" value={this.state.FN19} onChange={(value)=> this.setState({FN19:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN20 </label>
<input type="text" class="form-control" placeholder="FN20" value={this.state.FN20} onChange={(value)=> this.setState({FN20:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN21 </label>
<input type="text" class="form-control" placeholder="FN21" value={this.state.FN21} onChange={(value)=> this.setState({FN21:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN22 </label>
<input type="text" class="form-control" placeholder="FN22" value={this.state.FN22} onChange={(value)=> this.setState({FN22:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN23 </label>
<input type="text" class="form-control" placeholder="FN23" value={this.state.FN23} onChange={(value)=> this.setState({FN23:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN24 </label>
<input type="text" class="form-control" placeholder="FN24" value={this.state.FN24} onChange={(value)=> this.setState({FN24:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN25 </label>
<input type="text" class="form-control" placeholder="FN25" value={this.state.FN25} onChange={(value)=> this.setState({FN25:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN26 </label>
<input type="text" class="form-control" placeholder="FN26" value={this.state.FN26} onChange={(value)=> this.setState({FN26:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN27 </label>
<input type="text" class="form-control" placeholder="FN27" value={this.state.FN27} onChange={(value)=> this.setState({FN27:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN28 </label>
<input type="text" class="form-control" placeholder="FN28" value={this.state.FN28} onChange={(value)=> this.setState({FN28:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN29 </label>
<input type="text" class="form-control" placeholder="FN29" value={this.state.FN29} onChange={(value)=> this.setState({FN29:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN30 </label>
<input type="text" class="form-control" placeholder="FN30" value={this.state.FN30} onChange={(value)=> this.setState({FN30:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN31 </label>
<input type="text" class="form-control" placeholder="FN31" value={this.state.FN31} onChange={(value)=> this.setState({FN31:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN32 </label>
<input type="text" class="form-control" placeholder="FN32" value={this.state.FN32} onChange={(value)=> this.setState({FN32:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN33 </label>
<input type="text" class="form-control" placeholder="FN33" value={this.state.FN33} onChange={(value)=> this.setState({FN33:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN34 </label>
<input type="text" class="form-control" placeholder="FN34" value={this.state.FN34} onChange={(value)=> this.setState({FN34:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN35 </label>
<input type="text" class="form-control" placeholder="FN35" value={this.state.FN35} onChange={(value)=> this.setState({FN35:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN36 </label>
<input type="text" class="form-control" placeholder="FN36" value={this.state.FN36} onChange={(value)=> this.setState({FN36:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN37 </label>
<input type="text" class="form-control" placeholder="FN37" value={this.state.FN37} onChange={(value)=> this.setState({FN37:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN38 </label>
<input type="text" class="form-control" placeholder="FN38" value={this.state.FN38} onChange={(value)=> this.setState({FN38:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN39 </label>
<input type="text" class="form-control" placeholder="FN39" value={this.state.FN39} onChange={(value)=> this.setState({FN39:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN40 </label>
<input type="text" class="form-control" placeholder="FN40" value={this.state.FN40} onChange={(value)=> this.setState({FN40:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN41 </label>
<input type="text" class="form-control" placeholder="FN41" value={this.state.FN41} onChange={(value)=> this.setState({FN41:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN42 </label>
<input type="text" class="form-control" placeholder="FN42" value={this.state.FN42} onChange={(value)=> this.setState({FN42:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN43 </label>
<input type="text" class="form-control" placeholder="FN43" value={this.state.FN43} onChange={(value)=> this.setState({FN43:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN44 </label>
<input type="text" class="form-control" placeholder="FN44" value={this.state.FN44} onChange={(value)=> this.setState({FN44:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN45 </label>
<input type="text" class="form-control" placeholder="FN45" value={this.state.FN45} onChange={(value)=> this.setState({FN45:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN46 </label>
<input type="text" class="form-control" placeholder="FN46" value={this.state.FN46} onChange={(value)=> this.setState({FN46:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN47 </label>
<input type="text" class="form-control" placeholder="FN47" value={this.state.FN47} onChange={(value)=> this.setState({FN47:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN48 </label>
<input type="text" class="form-control" placeholder="FN48" value={this.state.FN48} onChange={(value)=> this.setState({FN48:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN49 </label>
<input type="text" class="form-control" placeholder="FN49" value={this.state.FN49} onChange={(value)=> this.setState({FN49:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN50 </label>
<input type="text" class="form-control" placeholder="FN50" value={this.state.FN50} onChange={(value)=> this.setState({FN50:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN51 </label>
<input type="text" class="form-control" placeholder="FN51" value={this.state.FN51} onChange={(value)=> this.setState({FN51:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN52 </label>
<input type="text" class="form-control" placeholder="FN52" value={this.state.FN52} onChange={(value)=> this.setState({FN52:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN53 </label>
<input type="text" class="form-control" placeholder="FN53" value={this.state.FN53} onChange={(value)=> this.setState({FN53:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN54 </label>
<input type="text" class="form-control" placeholder="FN54" value={this.state.FN54} onChange={(value)=> this.setState({FN54:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN55 </label>
<input type="text" class="form-control" placeholder="FN55" value={this.state.FN55} onChange={(value)=> this.setState({FN55:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN56 </label>
<input type="text" class="form-control" placeholder="FN56" value={this.state.FN56} onChange={(value)=> this.setState({FN56:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN57 </label>
<input type="text" class="form-control" placeholder="FN57" value={this.state.FN57} onChange={(value)=> this.setState({FN57:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN73 </label>
<input type="text" class="form-control" placeholder="FN73" value={this.state.FN73} onChange={(value)=> this.setState({FN73:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN74 </label>
<input type="text" class="form-control" placeholder="FN74" value={this.state.FN74} onChange={(value)=> this.setState({FN74:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN76 </label>
<input type="text" class="form-control" placeholder="FN76" value={this.state.FN76} onChange={(value)=> this.setState({FN76:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN77 </label>
<input type="text" class="form-control" placeholder="FN77" value={this.state.FN77} onChange={(value)=> this.setState({FN77:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN78 </label>
<input type="text" class="form-control" placeholder="FN78" value={this.state.FN78} onChange={(value)=> this.setState({FN78:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN79 </label>
<input type="text" class="form-control" placeholder="FN79" value={this.state.FN79} onChange={(value)=> this.setState({FN79:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN80 </label>
<input type="text" class="form-control" placeholder="FN80" value={this.state.FN80} onChange={(value)=> this.setState({FN80:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN81 </label>
<input type="text" class="form-control" placeholder="FN81" value={this.state.FN81} onChange={(value)=> this.setState({FN81:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN82 </label>
<input type="text" class="form-control" placeholder="FN82" value={this.state.FN82} onChange={(value)=> this.setState({FN82:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">AG </label>
<input type="text" class="form-control" placeholder="AG" value={this.state.AG} onChange={(value)=> this.setState({AG:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">AL </label>
<input type="text" class="form-control" placeholder="AL" value={this.state.AL} onChange={(value)=> this.setState({AL:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">AS </label>
<input type="text" class="form-control" placeholder="AS" value={this.state.AS} onChange={(value)=> this.setState({AS:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">B </label>
<input type="text" class="form-control" placeholder="B" value={this.state.B} onChange={(value)=> this.setState({B:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">BA </label>
<input type="text" class="form-control" placeholder="BA" value={this.state.BA} onChange={(value)=> this.setState({BA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CD </label>
<input type="text" class="form-control" placeholder="CD" value={this.state.CD} onChange={(value)=> this.setState({CD:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CR </label>
<input type="text" class="form-control" placeholder="CR" value={this.state.CR} onChange={(value)=> this.setState({CR:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CU </label>
<input type="text" class="form-control" placeholder="CU" value={this.state.CU} onChange={(value)=> this.setState({CU:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FE </label>
<input type="text" class="form-control" placeholder="FE" value={this.state.FE} onChange={(value)=> this.setState({FE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MN </label>
<input type="text" class="form-control" placeholder="MN" value={this.state.MN} onChange={(value)=> this.setState({MN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">NA </label>
<input type="text" class="form-control" placeholder="NA" value={this.state.NA} onChange={(value)=> this.setState({NA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">NI </label>
<input type="text" class="form-control" placeholder="NI" value={this.state.NI} onChange={(value)=> this.setState({NI:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">PB </label>
<input type="text" class="form-control" placeholder="PB" value={this.state.PB} onChange={(value)=> this.setState({PB:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SE </label>
<input type="text" class="form-control" placeholder="SE" value={this.state.SE} onChange={(value)=> this.setState({SE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ZN </label>
<input type="text" class="form-control" placeholder="ZN" value={this.state.ZN} onChange={(value)=> this.setState({ZN:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">VIDRIADO </label>
<input type="text" class="form-control" placeholder="VIDRIADO" value={this.state.VIDRIADO} onChange={(value)=> this.setState({VIDRIADO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DECO_INT </label>
<input type="text" class="form-control" placeholder="DECO_INT" value={this.state.DECO_INT} onChange={(value)=> this.setState({DECO_INT:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">COLOR </label>
<input type="text" class="form-control" placeholder="COLOR" value={this.state.COLOR} onChange={(value)=> this.setState({COLOR:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">P_ANALIZAD </label>
<input type="text" class="form-control" placeholder="P_ANALIZAD" value={this.state.P_ANALIZAD} onChange={(value)=> this.setState({P_ANALIZAD:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">VOLUMEN_ML </label>
<input type="text" class="form-control" placeholder="VOLUMEN_ML" value={this.state.VOLUMEN_ML} onChange={(value)=> this.setState({VOLUMEN_ML:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SOL_US </label>
<input type="text" class="form-control" placeholder="SOL_US" value={this.state.SOL_US} onChange={(value)=> this.setState({SOL_US:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">C_CD </label>
<input type="text" class="form-control" placeholder="C_CD" value={this.state.C_CD} onChange={(value)=> this.setState({C_CD:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">C_PB </label>
<input type="text" class="form-control" placeholder="C_PB" value={this.state.C_PB} onChange={(value)=> this.setState({C_PB:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">LIMITES </label>
<input type="text" class="form-control" placeholder="LIMITES" value={this.state.LIMITES} onChange={(value)=> this.setState({LIMITES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN58 </label>
<input type="text" class="form-control" placeholder="FN58" value={this.state.FN58} onChange={(value)=> this.setState({FN58:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN59 </label>
<input type="text" class="form-control" placeholder="FN59" value={this.state.FN59} onChange={(value)=> this.setState({FN59:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN60 </label>
<input type="text" class="form-control" placeholder="FN60" value={this.state.FN60} onChange={(value)=> this.setState({FN60:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN61 </label>
<input type="text" class="form-control" placeholder="FN61" value={this.state.FN61} onChange={(value)=> this.setState({FN61:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN62 </label>
<input type="text" class="form-control" placeholder="FN62" value={this.state.FN62} onChange={(value)=> this.setState({FN62:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN63 </label>
<input type="text" class="form-control" placeholder="FN63" value={this.state.FN63} onChange={(value)=> this.setState({FN63:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN64 </label>
<input type="text" class="form-control" placeholder="FN64" value={this.state.FN64} onChange={(value)=> this.setState({FN64:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN65 </label>
<input type="text" class="form-control" placeholder="FN65" value={this.state.FN65} onChange={(value)=> this.setState({FN65:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN66 </label>
<input type="text" class="form-control" placeholder="FN66" value={this.state.FN66} onChange={(value)=> this.setState({FN66:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN67 </label>
<input type="text" class="form-control" placeholder="FN67" value={this.state.FN67} onChange={(value)=> this.setState({FN67:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN68 </label>
<input type="text" class="form-control" placeholder="FN68" value={this.state.FN68} onChange={(value)=> this.setState({FN68:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN70 </label>
<input type="text" class="form-control" placeholder="FN70" value={this.state.FN70} onChange={(value)=> this.setState({FN70:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN71 </label>
<input type="text" class="form-control" placeholder="FN71" value={this.state.FN71} onChange={(value)=> this.setState({FN71:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN72 </label>
<input type="text" class="form-control" placeholder="FN72" value={this.state.FN72} onChange={(value)=> this.setState({FN72:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FN75 </label>
<input type="text" class="form-control" placeholder="FN75" value={this.state.FN75} onChange={(value)=> this.setState({FN75:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_CAP </label>
<input type="text" class="form-control" placeholder="FEC_CAP" value={this.state.FEC_CAP} onChange={(value)=> this.setState({FEC_CAP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_IMP </label>
<input type="text" class="form-control" placeholder="FEC_IMP" value={this.state.FEC_IMP} onChange={(value)=> this.setState({FEC_IMP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_VAL </label>
<input type="text" class="form-control" placeholder="FEC_VAL" value={this.state.FEC_VAL} onChange={(value)=> this.setState({FEC_VAL:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">AM </label>
<input type="text" class="form-control" placeholder="AM" value={this.state.AM} onChange={(value)=> this.setState({AM:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">AF </label>
<input type="text" class="form-control" placeholder="AF" value={this.state.AF} onChange={(value)=> this.setState({AF:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">AMP </label>
<input type="text" class="form-control" placeholder="AMP" value={this.state.AMP} onChange={(value)=> this.setState({AMP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">AT </label>
<input type="text" class="form-control" placeholder="AT" value={this.state.AT} onChange={(value)=> this.setState({AT:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">VALIDADO </label>
<input type="text" class="form-control" placeholder="VALIDADO" value={this.state.VALIDADO} onChange={(value)=> this.setState({VALIDADO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLACAU </label>
<input type="text" class="form-control" placeholder="CLACAU" value={this.state.CLACAU} onChange={(value)=> this.setState({CLACAU:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SUPLEMENTO </label>
<input type="text" class="form-control" placeholder="SUPLEMENTO" value={this.state.SUPLEMENTO} onChange={(value)=> this.setState({SUPLEMENTO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">NOTAS </label>
<input type="text" class="form-control" placeholder="NOTAS" value={this.state.NOTAS} onChange={(value)=> this.setState({NOTAS:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendSave()}>Save</button>
</div>
</div>
);
}
  sendSave(){
const baseUrl = "http://localhost:3000/Rtblambiente_ambient/create"
const datapost = {
MUESTRA: this.state.MUESTRA,
CLAPRO: this.state.CLAPRO,
CLAMUE: this.state.CLAMUE,
AMPLIAR_TM: this.state.AMPLIAR_TM,
DOCTO: this.state.DOCTO,
NUM_DOC: this.state.NUM_DOC,
MARCA: this.state.MARCA,
PRESEN: this.state.PRESEN,
LOTE: this.state.LOTE,
CADUCIDAD: this.state.CADUCIDAD,
FEC_MUES: this.state.FEC_MUES,
HOR_MUES: this.state.HOR_MUES,
TEM_MOT: this.state.TEM_MOT,
MOT_MUES: this.state.MOT_MUES,
PUNT_MUES: this.state.PUNT_MUES,
FEC_ENS1: this.state.FEC_ENS1,
FEC_ENS2: this.state.FEC_ENS2,
FEC_ENS3: this.state.FEC_ENS3,
FEC_ENS4: this.state.FEC_ENS4,
FEC_ENS5: this.state.FEC_ENS5,
FEC_ENS6: this.state.FEC_ENS6,
FEC_DES: this.state.FEC_DES,
NOM_GIRO: this.state.NOM_GIRO,
RFC: this.state.RFC,
DOMICILIO: this.state.DOMICILIO,
COLONIA: this.state.COLONIA,
LOCALIDAD: this.state.LOCALIDAD,
CP: this.state.CP,
CLAEDO: this.state.CLAEDO,
CLAMUN: this.state.CLAMUN,
OBSERV: this.state.OBSERV,
MA_UFCGM: this.state.MA_UFCGM,
MA_UFC: this.state.MA_UFC,
OCT_UFCGM: this.state.OCT_UFCGM,
OCT_UFC: this.state.OCT_UFC,
OCT_UFC100: this.state.OCT_UFC100,
OCT_NMPGM: this.state.OCT_NMPGM,
OCT_NMP100: this.state.OCT_NMP100,
OFC_NMPGM: this.state.OFC_NMPGM,
OCF_NMP100: this.state.OCF_NMP100,
SALMO25GM: this.state.SALMO25GM,
SALMO30G: this.state.SALMO30G,
SALMO100ML: this.state.SALMO100ML,
S_AREUS: this.state.S_AREUS,
LEVADURAS: this.state.LEVADURAS,
HONGOS: this.state.HONGOS,
ECOLINMPGM: this.state.ECOLINMPGM,
ECOLI100ML: this.state.ECOLI100ML,
INHIBIDORE: this.state.INHIBIDORE,
VCO1: this.state.VCO1,
VCONOO1: this.state.VCONOO1,
VP_NMP: this.state.VP_NMP,
ENTEROCOCO: this.state.ENTEROCOCO,
E_ESTAFILO: this.state.E_ESTAFILO,
SALMO1000: this.state.SALMO1000,
SALMO_EN_C: this.state.SALMO_EN_C,
SALMO_EN_R: this.state.SALMO_EN_R,
HUMEDAD: this.state.HUMEDAD,
FOSFATSA: this.state.FOSFATSA,
NUTRITOS: this.state.NUTRITOS,
FECULA: this.state.FECULA,
DERCLOCUAL: this.state.DERCLOCUAL,
OXIDANTES: this.state.OXIDANTES,
SALESCUATE: this.state.SALESCUATE,
FLUOR: this.state.FLUOR,
YODO: this.state.YODO,
YODATO_K: this.state.YODATO_K,
M_EXTRANA: this.state.M_EXTRANA,
PH: this.state.PH,
OLOR: this.state.OLOR,
UNI_COLOR: this.state.UNI_COLOR,
SDT: this.state.SDT,
CLORUROS: this.state.CLORUROS,
SULFATOS: this.state.SULFATOS,
DUREZA_TOT: this.state.DUREZA_TOT,
FLUORUROS: this.state.FLUORUROS,
CRL_SEMICU: this.state.CRL_SEMICU,
CRL_CUANTI: this.state.CRL_CUANTI,
CLENBUTERO: this.state.CLENBUTERO,
AC_FOLICO: this.state.AC_FOLICO,
DET_MIC: this.state.DET_MIC,
DET_FIS: this.state.DET_FIS,
FN_MI: this.state.FN_MI,
FN_FI: this.state.FN_FI,
DE_FN_MI: this.state.DE_FN_MI,
DEF_FN_FI: this.state.DEF_FN_FI,
FN1: this.state.FN1,
FN2: this.state.FN2,
FN3: this.state.FN3,
FN4: this.state.FN4,
FN5: this.state.FN5,
FN6: this.state.FN6,
FN7: this.state.FN7,
FN8: this.state.FN8,
FN9: this.state.FN9,
FN10: this.state.FN10,
FN11: this.state.FN11,
FN12: this.state.FN12,
FN13: this.state.FN13,
FN14: this.state.FN14,
FN15: this.state.FN15,
FN16: this.state.FN16,
FN17: this.state.FN17,
FN18: this.state.FN18,
FN19: this.state.FN19,
FN20: this.state.FN20,
FN21: this.state.FN21,
FN22: this.state.FN22,
FN23: this.state.FN23,
FN24: this.state.FN24,
FN25: this.state.FN25,
FN26: this.state.FN26,
FN27: this.state.FN27,
FN28: this.state.FN28,
FN29: this.state.FN29,
FN30: this.state.FN30,
FN31: this.state.FN31,
FN32: this.state.FN32,
FN33: this.state.FN33,
FN34: this.state.FN34,
FN35: this.state.FN35,
FN36: this.state.FN36,
FN37: this.state.FN37,
FN38: this.state.FN38,
FN39: this.state.FN39,
FN40: this.state.FN40,
FN41: this.state.FN41,
FN42: this.state.FN42,
FN43: this.state.FN43,
FN44: this.state.FN44,
FN45: this.state.FN45,
FN46: this.state.FN46,
FN47: this.state.FN47,
FN48: this.state.FN48,
FN49: this.state.FN49,
FN50: this.state.FN50,
FN51: this.state.FN51,
FN52: this.state.FN52,
FN53: this.state.FN53,
FN54: this.state.FN54,
FN55: this.state.FN55,
FN56: this.state.FN56,
FN57: this.state.FN57,
FN73: this.state.FN73,
FN74: this.state.FN74,
FN76: this.state.FN76,
FN77: this.state.FN77,
FN78: this.state.FN78,
FN79: this.state.FN79,
FN80: this.state.FN80,
FN81: this.state.FN81,
FN82: this.state.FN82,
AG: this.state.AG,
AL: this.state.AL,
AS: this.state.AS,
B: this.state.B,
BA: this.state.BA,
CD: this.state.CD,
CR: this.state.CR,
CU: this.state.CU,
FE: this.state.FE,
MN: this.state.MN,
NA: this.state.NA,
NI: this.state.NI,
PB: this.state.PB,
SE: this.state.SE,
ZN: this.state.ZN,
VIDRIADO: this.state.VIDRIADO,
DECO_INT: this.state.DECO_INT,
COLOR: this.state.COLOR,
P_ANALIZAD: this.state.P_ANALIZAD,
VOLUMEN_ML: this.state.VOLUMEN_ML,
SOL_US: this.state.SOL_US,
C_CD: this.state.C_CD,
C_PB: this.state.C_PB,
LIMITES: this.state.LIMITES,
FN58: this.state.FN58,
FN59: this.state.FN59,
FN60: this.state.FN60,
FN61: this.state.FN61,
FN62: this.state.FN62,
FN63: this.state.FN63,
FN64: this.state.FN64,
FN65: this.state.FN65,
FN66: this.state.FN66,
FN67: this.state.FN67,
FN68: this.state.FN68,
FN70: this.state.FN70,
FN71: this.state.FN71,
FN72: this.state.FN72,
FN75: this.state.FN75,
FEC_CAP: this.state.FEC_CAP,
FEC_IMP: this.state.FEC_IMP,
FEC_VAL: this.state.FEC_VAL,
AM: this.state.AM,
AF: this.state.AF,
AMP: this.state.AMP,
AT: this.state.AT,
VALIDADO: this.state.VALIDADO,
CLACAU: this.state.CLACAU,
SUPLEMENTO: this.state.SUPLEMENTO,
NOTAS: this.state.NOTAS
}
axios.post(baseUrl,datapost)
      .then(response=>{
 if (response.data.success===true) {
  alert(response.data.message)
}
else {
alert(response.data.message)
}
}).catch(error=>{
   alert("Error 34 "+error)
 })
 }
}
export default EditComponent;
