const express = require('express');
const router = express.Router();
const tblcalidad2Controller = require('../Controllers/tblcalidad2Controller')


router.post('/update/:id',tblcalidad2Controller.update)
router.get('/get/:id', tblcalidad2Controller.get)
router.get('/list', tblcalidad2Controller.list);
router.post('/create', tblcalidad2Controller.create);


module.exports = router;
