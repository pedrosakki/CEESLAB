const express = require('express');
const router = express.Router();
const tbltipomuestra_tmuesController = require('../Controllers/tbltipomuestra_tmuesController')


router.post('/update/:id',tbltipomuestra_tmuesController.update)
router.get('/get/:id', tbltipomuestra_tmuesController.get)
router.get('/list', tbltipomuestra_tmuesController.list);
router.post('/create', tbltipomuestra_tmuesController.create);



module.exports = router;
