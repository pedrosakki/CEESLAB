const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tblpermisos')
var nametable = 'tblpermisos';
var tblpermisos = sequelize.define(nametable,{
idtblpermisos:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},

accion:  Sequelize.STRING,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tblpermisos;
