import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios';
class EditComponent extends React.Component{
constructor(props){
super(props);
this.state = {
CLARES:"",
RESULTADO:""
}
}
render(){
  return (
<div>
 <div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLARES </label>
<input type="text" class="form-control" placeholder="CLARES" value={this.state.CLARES} onChange={(value)=> this.setState({CLARES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RESULTADO </label>
<input type="text" class="form-control" placeholder="RESULTADO" value={this.state.RESULTADO} onChange={(value)=> this.setState({RESULTADO:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendSave()}>Save</button>
</div>
</div>
);
}
  sendSave(){
const baseUrl = "http://localhost:3000/Rtbltiporesultado_tipores/create"
const datapost = {
CLARES: this.state.CLARES,
RESULTADO: this.state.RESULTADO
}
axios.post(baseUrl,datapost)
      .then(response=>{
 if (response.data.success===true) {
  alert(response.data.message)
}
else {
alert(response.data.message)
}
}).catch(error=>{
   alert("Error 34 "+error)
 })
 }
}
export default EditComponent;
