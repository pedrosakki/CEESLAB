 const controllers = {}
var sequelize = require('../model/database');
var tbldireccion_direcc = require('../model/tbldireccion_direcc');

//METODO GET//

controllers.get = async(req,res)=>{
const {id}= req.params;
const data = await tbldireccion_direcc.findAll({
where: {idtbldireccion_direcc: id }  })
.then(function(data){
    return data;})
.catch(error =>{
return error;})
res.json({sucess:true,data})
}


//METODO LIST//

controllers.list = async (req, res)=>{
const response = await sequelize.sync().then(function(){
const data = tbldireccion_direcc.findAll();
return data;})
.catch(error => {
    return error;
})
res.json({sucess: true, data:response});
}



//METODO CREATE//
controllers.create = async (req, res)=>{
const  {CLAPRO,CLAEDO,CLAREG,CLADIR,DIRECCION}=req.body;
const data = await tbldireccion_direcc.create({
CLAPRO: CLAPRO,
CLAEDO: CLAEDO,
CLAREG: CLAREG,
CLADIR: CLADIR,
DIRECCION: DIRECCION
}).then(function(data){
return data;
}).catch(error=>{
console.log(error)
return error;
})
res.status(200).json({
success:true,
message:"Create Sucess",
data: data
})
}


//METODO UPDATE//
controllers.update = async (req, res)=>{
  const { id } = req.params;
const  {CLAPRO,CLAEDO,CLAREG,CLADIR,DIRECCION}=req.body;

 const data = await tbldireccion_direcc.update({
CLAPRO: CLAPRO,
CLAEDO: CLAEDO,
CLAREG: CLAREG,
CLADIR: CLADIR,
DIRECCION: DIRECCION
   },{
          where: { idtbldireccion_direcc: id}
     })
  .then( function(data){
    return data;
      })
       .catch(error => {
        return error;
   }) 
   res.json({success:true, data:data, message:"Updated successful"});
 }



 module.exports = controllers;
