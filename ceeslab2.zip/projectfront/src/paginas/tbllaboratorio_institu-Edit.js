import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios'
const baseUrl= "http: //localhost:3000"
class EditComponent extends React.Component{

constructor(props){

super(props);
this.state={
edittbllaboratorio_institus:[],
datatbllaboratorio_institu:{},
LOGO1: "",
LOGO2: "",
ENCAB1: "",
ENCAB2: "",
ENCAB3: "",
PIE1: "",
DIRECC: "",
DNOMBRE: "",
MCPUESTO: "",
MCNOMBRE1: "",
AMPUESTO: "",
AMNOMBRE: "",
CCPUESTO: "",
CCNOMBRE: ""
}
}


componentDidMount(){
let userId = this.props.match.params.tbllaboratorio_instituid;
  const url = baseUrl+"/Rtbllaboratorio_institu/get/"+userId

  axios.get(url)
 .then(res=>{
  if(res.data.sucess){
  const data = res.data.data[0] 
this.setState({
edittbllaboratorio_institus:data,
LOGO1: data.LOGO1,
LOGO2: data.LOGO2,
ENCAB1: data.ENCAB1,
ENCAB2: data.ENCAB2,
ENCAB3: data.ENCAB3,
PIE1: data.PIE1,
DIRECC: data.DIRECC,
DNOMBRE: data.DNOMBRE,
MCPUESTO: data.MCPUESTO,
MCNOMBRE1: data.MCNOMBRE1,
AMPUESTO: data.AMPUESTO,
AMNOMBRE: data.AMNOMBRE,
CCPUESTO: data.CCPUESTO,
CCNOMBRE: data.CCNOMBRE
} ) }
else{
alert("Error web service")
} } )
  .catch(error=>{
  })
}


  render(){
   let userId = 0;
 return (
<div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">LOGO1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.LOGO1} onChange={(value)=> this.setState({LOGO1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">LOGO2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.LOGO2} onChange={(value)=> this.setState({LOGO2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ENCAB1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ENCAB1} onChange={(value)=> this.setState({ENCAB1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ENCAB2 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ENCAB2} onChange={(value)=> this.setState({ENCAB2:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">ENCAB3 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.ENCAB3} onChange={(value)=> this.setState({ENCAB3:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">PIE1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.PIE1} onChange={(value)=> this.setState({PIE1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DIRECC </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DIRECC} onChange={(value)=> this.setState({DIRECC:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DNOMBRE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.DNOMBRE} onChange={(value)=> this.setState({DNOMBRE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MCPUESTO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.MCPUESTO} onChange={(value)=> this.setState({MCPUESTO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MCNOMBRE1 </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.MCNOMBRE1} onChange={(value)=> this.setState({MCNOMBRE1:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">AMPUESTO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.AMPUESTO} onChange={(value)=> this.setState({AMPUESTO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">AMNOMBRE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.AMNOMBRE} onChange={(value)=> this.setState({AMNOMBRE:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CCPUESTO </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CCPUESTO} onChange={(value)=> this.setState({CCPUESTO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CCNOMBRE </label>
<input type="text" class="form-control" placeholder="Apellido Paterno" value={this.state.CCNOMBRE} onChange={(value)=> this.setState({CCNOMBRE:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendUpdate()}>Update</button>  
</div>
); }
sendUpdate(){
let userId = this.props.match.params.tbllaboratorio_instituid;
const baseUrl = "http://localhost:3000/Rtbllaboratorio_institu/Update/"+ userId
const datapost = {
LOGO1: this.state.LOGO1,
LOGO2: this.state.LOGO2,
ENCAB1: this.state.ENCAB1,
ENCAB2: this.state.ENCAB2,
ENCAB3: this.state.ENCAB3,
PIE1: this.state.PIE1,
DIRECC: this.state.DIRECC,
DNOMBRE: this.state.DNOMBRE,
MCPUESTO: this.state.MCPUESTO,
MCNOMBRE1: this.state.MCNOMBRE1,
AMPUESTO: this.state.AMPUESTO,
AMNOMBRE: this.state.AMNOMBRE,
CCPUESTO: this.state.CCPUESTO,
CCNOMBRE: this.state.CCNOMBRE
}
axios.post(baseUrl,datapost)
.then(response=>{
if (response.data.success===true) {
alert(response.data.message)
}
else {
alert(response.data.message)
alert(JSON.stringify(response))
}
}).catch(error=>{
alert("Error 34 "+error)
})
}
}
export default EditComponent;
