import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { Link } from "react-router-dom";
import axios from 'axios';
const url= 'http://localhost:3000/Rtblmicrobiologia/list';
class listComponent extends React.Component  {
constructor(props){
super(props);
this.state ={
listtblmicrobiologia:[]
}
}
componentDidMount(){
axios.get(url)
.then(res=>{
if(res.data.sucess){
const data = res.data.data
this.setState({listtblmicrobiologia:data})
}
else{
alert("Error web service")
}
})
.catch(error=>{
alert("Error Server"+error)
})
}
render()
{
    return (
      <table class="table table-hover table-striped">

        <thead class="thead-dark">

<tr>
<th scope = "col" >#</th>
<th scope ="col" >MUESTRA</th>
<th scope ="col" >DOCTO</th>
<th scope ="col" >NUM_DOC</th>
<th scope ="col" >CLAPRO</th>
<th scope ="col" >CLAMUE</th>
<th scope ="col" >CONFIRMAR</th>
<th scope ="col" >AFILIACION</th>
<th scope ="col" >PIORIDAD</th>
<th scope ="col" >NOMBES</th>
<th scope ="col" >APELLIDO_P</th>
<th scope ="col" >APELLIDO_M</th>
<th scope ="col" >ANIOS</th>
<th scope ="col" >MESES</th>
<th scope ="col" >SEXO</th>
<th scope ="col" >DOMICILIO</th>
<th scope ="col" >COLONIA</th>
<th scope ="col" >LOCALIDAD</th>
<th scope ="col" >CLAEDO</th>
<th scope ="col" >CLAMUN</th>
<th scope ="col" >FEC_TOM</th>
<th scope ="col" >HOR_TOM</th>
<th scope ="col" >FEC_IEN</th>
<th scope ="col" >CONTACTODE</th>
<th scope ="col" >E1</th>
<th scope ="col" >EXAM1</th>
<th scope ="col" >RES1</th>
<th scope ="col" >RESUL1</th>
<th scope ="col" >FR1</th>
<th scope ="col" >INDRE1</th>
<th scope ="col" >E2</th>
<th scope ="col" >EXAM2</th>
<th scope ="col" >RES2</th>
<th scope ="col" >RESUL2</th>
<th scope ="col" >FR2</th>
<th scope ="col" >INDRE2</th>
<th scope ="col" >E3</th>
<th scope ="col" >EXAM3</th>
<th scope ="col" >RES3</th>
<th scope ="col" >RESUL3</th>
<th scope ="col" >FR3</th>
<th scope ="col" >INDRE3</th>
<th scope ="col" >E4</th>
<th scope ="col" >EXAM4</th>
<th scope ="col" >RES4</th>
<th scope ="col" >RESUL4</th>
<th scope ="col" >FR4</th>
<th scope ="col" >INDRE4</th>
<th scope ="col" >E5</th>
<th scope ="col" >EXAM5</th>
<th scope ="col" >RES5</th>
<th scope ="col" >RESUL5</th>
<th scope ="col" >FR5</th>
<th scope ="col" >INDRE5</th>
<th scope ="col" >E6</th>
<th scope ="col" >EXAM6</th>
<th scope ="col" >RES6</th>
<th scope ="col" >RESUL6</th>
<th scope ="col" >FR6</th>
<th scope ="col" >INDRE6</th>
<th scope ="col" >E7</th>
<th scope ="col" >EXAM7</th>
<th scope ="col" >RES7</th>
<th scope ="col" >RESUL7</th>
<th scope ="col" >FR7</th>
<th scope ="col" >INDRE7</th>
<th scope ="col" >E8</th>
<th scope ="col" >EXAM8</th>
<th scope ="col" >RES8</th>
<th scope ="col" >RESUL8</th>
<th scope ="col" >FR8</th>
<th scope ="col" >INDRE8</th>
<th scope ="col" >E9</th>
<th scope ="col" >EXAM9</th>
<th scope ="col" >RES9</th>
<th scope ="col" >RESUL9</th>
<th scope ="col" >FR9</th>
<th scope ="col" >INDRE9</th>
<th scope ="col" >E10</th>
<th scope ="col" >EXAM10</th>
<th scope ="col" >RES10</th>
<th scope ="col" >RESUL10</th>
<th scope ="col" >FR10</th>
<th scope ="col" >INDRE10</th>
<th scope ="col" >ANTI_1</th>
<th scope ="col" >ANTI_2</th>
<th scope ="col" >ANTI_3</th>
<th scope ="col" >ANTI_4</th>
<th scope ="col" >ANTI_5</th>
<th scope ="col" >ANTI_6</th>
<th scope ="col" >ANTI_7</th>
<th scope ="col" >ANTI_8</th>
<th scope ="col" >ANTI_9</th>
<th scope ="col" >ANTI_9D</th>
<th scope ="col" >BAAR</th>
<th scope ="col" >CULTIVO</th>
<th scope ="col" >SEAISLO</th>
<th scope ="col" >OBSERV</th>
<th scope ="col" >F_LIBRE</th>
<th scope ="col" >CONTROL</th>
<th scope ="col" >DIAG</th>
<th scope ="col" >M_PROCESAD</th>
<th scope ="col" >TIPIFICS</th>
<th scope ="col" >PCR_GX</th>
<th scope ="col" >FEC_CAP</th>
<th scope ="col" >FEC_IMP</th>
<th scope ="col" >FEC_EINDRE</th>
<th scope ="col" >FEC_RINDRE</th>
<th scope ="col" >FEC_VAL</th>
<th scope ="col" >VALIDADO</th>
<th scope ="col" >CLACAU</th>
<th scope ="col" >SUPLEMENTO</th>
<th scope ="col" >NOTAS</th>
<th colspan="2" >Acciones</th>
</tr>
        </thead>
<tbody>
        {this.loadFilData()}
        </tbody>
      </table>
    );
  }
loadFilData(){
return this.state.listtblmicrobiologia.map((data)=>{
return(
  <tr>
  <th>{data.idtblmicrobiologia}</th>

<td>{data.MUESTRA}</td>
<td>{data.DOCTO}</td>
<td>{data.NUM_DOC}</td>
<td>{data.CLAPRO}</td>
<td>{data.CLAMUE}</td>
<td>{data.CONFIRMAR}</td>
<td>{data.AFILIACION}</td>
<td>{data.PIORIDAD}</td>
<td>{data.NOMBES}</td>
<td>{data.APELLIDO_P}</td>
<td>{data.APELLIDO_M}</td>
<td>{data.ANIOS}</td>
<td>{data.MESES}</td>
<td>{data.SEXO}</td>
<td>{data.DOMICILIO}</td>
<td>{data.COLONIA}</td>
<td>{data.LOCALIDAD}</td>
<td>{data.CLAEDO}</td>
<td>{data.CLAMUN}</td>
<td>{data.FEC_TOM}</td>
<td>{data.HOR_TOM}</td>
<td>{data.FEC_IEN}</td>
<td>{data.CONTACTODE}</td>
<td>{data.E1}</td>
<td>{data.EXAM1}</td>
<td>{data.RES1}</td>
<td>{data.RESUL1}</td>
<td>{data.FR1}</td>
<td>{data.INDRE1}</td>
<td>{data.E2}</td>
<td>{data.EXAM2}</td>
<td>{data.RES2}</td>
<td>{data.RESUL2}</td>
<td>{data.FR2}</td>
<td>{data.INDRE2}</td>
<td>{data.E3}</td>
<td>{data.EXAM3}</td>
<td>{data.RES3}</td>
<td>{data.RESUL3}</td>
<td>{data.FR3}</td>
<td>{data.INDRE3}</td>
<td>{data.E4}</td>
<td>{data.EXAM4}</td>
<td>{data.RES4}</td>
<td>{data.RESUL4}</td>
<td>{data.FR4}</td>
<td>{data.INDRE4}</td>
<td>{data.E5}</td>
<td>{data.EXAM5}</td>
<td>{data.RES5}</td>
<td>{data.RESUL5}</td>
<td>{data.FR5}</td>
<td>{data.INDRE5}</td>
<td>{data.E6}</td>
<td>{data.EXAM6}</td>
<td>{data.RES6}</td>
<td>{data.RESUL6}</td>
<td>{data.FR6}</td>
<td>{data.INDRE6}</td>
<td>{data.E7}</td>
<td>{data.EXAM7}</td>
<td>{data.RES7}</td>
<td>{data.RESUL7}</td>
<td>{data.FR7}</td>
<td>{data.INDRE7}</td>
<td>{data.E8}</td>
<td>{data.EXAM8}</td>
<td>{data.RES8}</td>
<td>{data.RESUL8}</td>
<td>{data.FR8}</td>
<td>{data.INDRE8}</td>
<td>{data.E9}</td>
<td>{data.EXAM9}</td>
<td>{data.RES9}</td>
<td>{data.RESUL9}</td>
<td>{data.FR9}</td>
<td>{data.INDRE9}</td>
<td>{data.E10}</td>
<td>{data.EXAM10}</td>
<td>{data.RES10}</td>
<td>{data.RESUL10}</td>
<td>{data.FR10}</td>
<td>{data.INDRE10}</td>
<td>{data.ANTI_1}</td>
<td>{data.ANTI_2}</td>
<td>{data.ANTI_3}</td>
<td>{data.ANTI_4}</td>
<td>{data.ANTI_5}</td>
<td>{data.ANTI_6}</td>
<td>{data.ANTI_7}</td>
<td>{data.ANTI_8}</td>
<td>{data.ANTI_9}</td>
<td>{data.ANTI_9D}</td>
<td>{data.BAAR}</td>
<td>{data.CULTIVO}</td>
<td>{data.SEAISLO}</td>
<td>{data.OBSERV}</td>
<td>{data.F_LIBRE}</td>
<td>{data.CONTROL}</td>
<td>{data.DIAG}</td>
<td>{data.M_PROCESAD}</td>
<td>{data.TIPIFICS}</td>
<td>{data.PCR_GX}</td>
<td>{data.FEC_CAP}</td>
<td>{data.FEC_IMP}</td>
<td>{data.FEC_EINDRE}</td>
<td>{data.FEC_RINDRE}</td>
<td>{data.FEC_VAL}</td>
<td>{data.VALIDADO}</td>
<td>{data.CLACAU}</td>
<td>{data.SUPLEMENTO}</td>
<td>{data.NOTAS}</td>
<td>
<Link class="btn btn-outline-info "  to={"/tblmicrobiologiaEdit/"+data.idtblmicrobiologia} >Edit</Link>
</td>
<td>
  <button class="btn btn-outline-danger "> Delete </button>
</td>
</tr>
)
}
)
}
}
export default listComponent;
