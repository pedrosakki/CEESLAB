const Sequelize = require('sequelize');
var sequelize = require('./database');
var permisos = require('./tblusuario_usuarios')
var nametable = 'tblusuario_usuarios';
var tblusuario_usuarios = sequelize.define(nametable,{
IDTBLUSUARIO:{
type:Sequelize.INTEGER,
primaryKey: true,
autoIncrement: true},
USUARIO:  Sequelize.STRING,
PASSWORD:  Sequelize.STRING,
ACCESO:  Sequelize.STRING,
SECCION:  Sequelize.STRING,
TIPO:  Sequelize.STRING,
NIVEL:  Sequelize.STRING,
SESION:  Sequelize.STRING,
CODIGO:  Sequelize.STRING,
NOMBRE:  Sequelize.STRING,
idPermisos:Sequelize.STRING,
idArea:Sequelize.INTEGER,
activo:Sequelize.INTEGER,
},{
timestamps: false,
freezeTableName: true
});
module.exports = tblusuario_usuarios;
