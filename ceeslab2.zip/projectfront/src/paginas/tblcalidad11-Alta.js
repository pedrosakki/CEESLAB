import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from 'axios';
class EditComponent extends React.Component{
constructor(props){
super(props);
this.state = {
MUESTRA:"",
PAQUETEVPH:"",
FOLIO:"",
AFILIACION:"",
CLAPRO:"",
CLAEDO:"",
CLAREG:"",
CLADIR:"",
CLAUNI:"",
NOMBRES:"",
APELLIDO_P:"",
APELLIDO_M:"",
FEC_NAC:"",
EDAD:"",
FEC_TOM:"",
FEC_REP:"",
NUM_LAM:"",
FORMATO:"",
DX_CITO:"",
HALL_CITO:"",
DX_PATO:"",
HALL_PATO:"",
RFC_CITO:"",
RFC_PATO:"",
REV:"",
TUMORAL:"",
FEC_REP_MT:"",
RFC_PATO_M:"",
OBSERVA:"",
SUPLEMENTO:"",
RESULTADO:""
}
}
render(){
  return (
<div>
 <div class="form-row justify-content-center">
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">MUESTRA </label>
<input type="text" class="form-control" placeholder="MUESTRA" value={this.state.MUESTRA} onChange={(value)=> this.setState({MUESTRA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">PAQUETEVPH </label>
<input type="text" class="form-control" placeholder="PAQUETEVPH" value={this.state.PAQUETEVPH} onChange={(value)=> this.setState({PAQUETEVPH:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FOLIO </label>
<input type="text" class="form-control" placeholder="FOLIO" value={this.state.FOLIO} onChange={(value)=> this.setState({FOLIO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">AFILIACION </label>
<input type="text" class="form-control" placeholder="AFILIACION" value={this.state.AFILIACION} onChange={(value)=> this.setState({AFILIACION:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAPRO </label>
<input type="text" class="form-control" placeholder="CLAPRO" value={this.state.CLAPRO} onChange={(value)=> this.setState({CLAPRO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAEDO </label>
<input type="text" class="form-control" placeholder="CLAEDO" value={this.state.CLAEDO} onChange={(value)=> this.setState({CLAEDO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAREG </label>
<input type="text" class="form-control" placeholder="CLAREG" value={this.state.CLAREG} onChange={(value)=> this.setState({CLAREG:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLADIR </label>
<input type="text" class="form-control" placeholder="CLADIR" value={this.state.CLADIR} onChange={(value)=> this.setState({CLADIR:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">CLAUNI </label>
<input type="text" class="form-control" placeholder="CLAUNI" value={this.state.CLAUNI} onChange={(value)=> this.setState({CLAUNI:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">NOMBRES </label>
<input type="text" class="form-control" placeholder="NOMBRES" value={this.state.NOMBRES} onChange={(value)=> this.setState({NOMBRES:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">APELLIDO_P </label>
<input type="text" class="form-control" placeholder="APELLIDO_P" value={this.state.APELLIDO_P} onChange={(value)=> this.setState({APELLIDO_P:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">APELLIDO_M </label>
<input type="text" class="form-control" placeholder="APELLIDO_M" value={this.state.APELLIDO_M} onChange={(value)=> this.setState({APELLIDO_M:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_NAC </label>
<input type="text" class="form-control" placeholder="FEC_NAC" value={this.state.FEC_NAC} onChange={(value)=> this.setState({FEC_NAC:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">EDAD </label>
<input type="text" class="form-control" placeholder="EDAD" value={this.state.EDAD} onChange={(value)=> this.setState({EDAD:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_TOM </label>
<input type="text" class="form-control" placeholder="FEC_TOM" value={this.state.FEC_TOM} onChange={(value)=> this.setState({FEC_TOM:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_REP </label>
<input type="text" class="form-control" placeholder="FEC_REP" value={this.state.FEC_REP} onChange={(value)=> this.setState({FEC_REP:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">NUM_LAM </label>
<input type="text" class="form-control" placeholder="NUM_LAM" value={this.state.NUM_LAM} onChange={(value)=> this.setState({NUM_LAM:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FORMATO </label>
<input type="text" class="form-control" placeholder="FORMATO" value={this.state.FORMATO} onChange={(value)=> this.setState({FORMATO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DX_CITO </label>
<input type="text" class="form-control" placeholder="DX_CITO" value={this.state.DX_CITO} onChange={(value)=> this.setState({DX_CITO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">HALL_CITO </label>
<input type="text" class="form-control" placeholder="HALL_CITO" value={this.state.HALL_CITO} onChange={(value)=> this.setState({HALL_CITO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">DX_PATO </label>
<input type="text" class="form-control" placeholder="DX_PATO" value={this.state.DX_PATO} onChange={(value)=> this.setState({DX_PATO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">HALL_PATO </label>
<input type="text" class="form-control" placeholder="HALL_PATO" value={this.state.HALL_PATO} onChange={(value)=> this.setState({HALL_PATO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RFC_CITO </label>
<input type="text" class="form-control" placeholder="RFC_CITO" value={this.state.RFC_CITO} onChange={(value)=> this.setState({RFC_CITO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RFC_PATO </label>
<input type="text" class="form-control" placeholder="RFC_PATO" value={this.state.RFC_PATO} onChange={(value)=> this.setState({RFC_PATO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">REV </label>
<input type="text" class="form-control" placeholder="REV" value={this.state.REV} onChange={(value)=> this.setState({REV:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">TUMORAL </label>
<input type="text" class="form-control" placeholder="TUMORAL" value={this.state.TUMORAL} onChange={(value)=> this.setState({TUMORAL:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">FEC_REP_MT </label>
<input type="text" class="form-control" placeholder="FEC_REP_MT" value={this.state.FEC_REP_MT} onChange={(value)=> this.setState({FEC_REP_MT:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RFC_PATO_M </label>
<input type="text" class="form-control" placeholder="RFC_PATO_M" value={this.state.RFC_PATO_M} onChange={(value)=> this.setState({RFC_PATO_M:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">OBSERVA </label>
<input type="text" class="form-control" placeholder="OBSERVA" value={this.state.OBSERVA} onChange={(value)=> this.setState({OBSERVA:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">SUPLEMENTO </label>
<input type="text" class="form-control" placeholder="SUPLEMENTO" value={this.state.SUPLEMENTO} onChange={(value)=> this.setState({SUPLEMENTO:value.target.value})}/>
</div>
<div class="form-group col-md-6">
<label for="inputApellidoPaterno">RESULTADO </label>
<input type="text" class="form-control" placeholder="RESULTADO" value={this.state.RESULTADO} onChange={(value)=> this.setState({RESULTADO:value.target.value})}/>
</div>
<button type="submit" class="btn btn-primary" onClick={()=>this.sendSave()}>Save</button>
</div>
</div>
);
}
  sendSave(){
const baseUrl = "http://localhost:3000/Rtblcalidad11/create"
const datapost = {
MUESTRA: this.state.MUESTRA,
PAQUETEVPH: this.state.PAQUETEVPH,
FOLIO: this.state.FOLIO,
AFILIACION: this.state.AFILIACION,
CLAPRO: this.state.CLAPRO,
CLAEDO: this.state.CLAEDO,
CLAREG: this.state.CLAREG,
CLADIR: this.state.CLADIR,
CLAUNI: this.state.CLAUNI,
NOMBRES: this.state.NOMBRES,
APELLIDO_P: this.state.APELLIDO_P,
APELLIDO_M: this.state.APELLIDO_M,
FEC_NAC: this.state.FEC_NAC,
EDAD: this.state.EDAD,
FEC_TOM: this.state.FEC_TOM,
FEC_REP: this.state.FEC_REP,
NUM_LAM: this.state.NUM_LAM,
FORMATO: this.state.FORMATO,
DX_CITO: this.state.DX_CITO,
HALL_CITO: this.state.HALL_CITO,
DX_PATO: this.state.DX_PATO,
HALL_PATO: this.state.HALL_PATO,
RFC_CITO: this.state.RFC_CITO,
RFC_PATO: this.state.RFC_PATO,
REV: this.state.REV,
TUMORAL: this.state.TUMORAL,
FEC_REP_MT: this.state.FEC_REP_MT,
RFC_PATO_M: this.state.RFC_PATO_M,
OBSERVA: this.state.OBSERVA,
SUPLEMENTO: this.state.SUPLEMENTO,
RESULTADO: this.state.RESULTADO
}
axios.post(baseUrl,datapost)
      .then(response=>{
 if (response.data.success===true) {
  alert(response.data.message)
}
else {
alert(response.data.message)
}
}).catch(error=>{
   alert("Error 34 "+error)
 })
 }
}
export default EditComponent;
