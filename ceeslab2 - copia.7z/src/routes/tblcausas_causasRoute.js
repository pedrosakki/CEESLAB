const express = require('express');
const router = express.Router();
const tblcausas_causasController = require('../Controllers/tblcausas_causasController')


router.post('/update/:id',tblcausas_causasController.update)
router.get('/get/:id', tblcausas_causasController.get)
router.get('/list', tblcausas_causasController.list);
router.post('/create', tblcausas_causasController.create);


module.exports = router;
