import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import TblProcedencia from './tblprocedencia_proceden-tbl';
import axios from 'axios';
class EditComponent extends React.Component{
constructor(props){
super(props);
this.state = {
MUESTRA:"",
MUESTRA2:"",
FEC_REC:"",
HOR_REC:"",
CLAPRO:"",
CLAMUE:"",
AMPLIAR_TM:"",
TEM_REC:"",
CONFIRMAR:"",
OBSERVA:"",
AM:"",
AF:"",
AMP:"",
HT:"",
VALIDADO:"",
MOTIVO:"",
PRIORIDAD:"",
E1:"",
EXAM1:"",
E2:"",
EXAM2:"",
E3:"",
EXAM3:"",
E4:"",
EXAM4:"",
E5:"",
EXAM5:"",
E6:"",
EXAM6:"",
E7:"",
EXAM7:"",
E8:"",
EXAM8:"",
E9:"",
EXAM9:"",
E10:"",
EXAM10:"",
MODIFICADO:"",
FEC_LAB:"",
HOR_LAB:"",
CLAREC:""
}
}
render(){
  return (

<div>
<div>

        <hr id="Line1" style={{position: 'absolute', left: '164px', top: '70px', width: '796px', zIndex: 0}} />
        <label htmlFor id="Label1" style={{position: 'absolute', left: '400px', top: '70px', width: '320px', height: '36px', lineHeight: '36px', zIndex: 1}}>Recepción de Muestras</label>
        <label htmlFor id="Label2" style={{position: 'absolute', left: '153px', top: '167px', width: '81px', height: '20px', lineHeight: '20px', zIndex: 2}}>Muestra No.</label>
        <input type="text" id="Editbox1"  style={{position: 'absolute', left: '295px', top: '168px', width: '86px', height: '16px', zIndex: 3}} name="Editbox1"  spellCheck="false" />
        <label htmlFor id="Label3" style={{position: 'absolute', left: '410px', top: '167px', width: '55px', height: '20px', lineHeight: '20px', zIndex: 4}}>Fecha</label>
        
        <label htmlFor id="Label4" style={{position: 'absolute', left: '599px', top: '167px', width: '55px', height: '20px', lineHeight: '20px', zIndex: 5}}>Hora</label>

        <input type="date" id="Editbox2" style={{position: 'absolute', left: '469px', top: '168px', width: '130px', height: '16px', zIndex: 6}} name="Editbox1"  spellCheck="false" />
        
        <label htmlFor id="Label5" style={{position: 'absolute', left: '153px', top: '210px', width: '81px', height: '20px', lineHeight: '20px', zIndex: 7}}>Procedencia</label>
        <input type="text" id="Editbox3" onFocus="#modalprocedencia.show()" style={{position: 'absolute', left: '295px', top: '211px', width: '86px', height: '16px', zIndex: 8}} name="txidtblprocedencia_proceden"  spellCheck="false" />
        <input type="text" id="Editbox4" style={{position: 'absolute', left: '410px', top: '211px', width: '540px', height: '16px', zIndex: 9}} name="Editbox1"  spellCheck="false" />
        <label htmlFor id="Label6" style={{position: 'absolute', left: '153px', top: '248px', width: '106px', height: '20px', lineHeight: '20px', zIndex: 10}}>Tipo de Muestra</label>
        <input type="text" id="Editbox5" style={{position: 'absolute', left: '295px', top: '249px', width: '86px', height: '16px', zIndex: 11}} name="Editbox1"  spellCheck="false" />
        <input type="text" id="Editbox6" style={{position: 'absolute', left: '410px', top: '249px', width: '540px', height: '16px', zIndex: 12}} name="Editbox1"  spellCheck="false" />
        <label htmlFor id="Label7" style={{position: 'absolute', left: '153px', top: '293px', width: '238px', height: '20px', lineHeight: '20px', zIndex: 13}}>Ampliar tipo de muestra (ambiental)</label>
        <input type="text" id="Editbox7" style={{position: 'absolute', left: '410px', top: '294px', width: '540px', height: '16px', zIndex: 14}} name="Editbox1"  spellCheck="false" />
        <label htmlFor id="Label8" style={{position: 'absolute', left: '153px', top: '330px', width: '250px', height: '20px', lineHeight: '20px', zIndex: 15}}>Confirmar (Cepa Microbiologia Medica)</label>
        <input type="text" id="Editbox8" style={{position: 'absolute', left: '410px', top: '331px', width: '540px', height: '16px', zIndex: 16}} name="Editbox1"  spellCheck="false" />
        <label htmlFor id="Label9" style={{position: 'absolute', left: '155px', top: '363px', width: '81px', height: '20px', lineHeight: '20px', zIndex: 17}}>Temperatura</label>
        <input type="text" id="Editbox9" style={{position: 'absolute', left: '269px', top: '364px', width: '86px', height: '16px', zIndex: 18}} name="Editbox1"  spellCheck="false" />
        <label htmlFor id="Label10" style={{position: 'absolute', left: '155px', top: '405px', width: '97px', height: '20px', lineHeight: '20px', zIndex: 19}}>Observaciones</label>
        <input type="text" id="Editbox10" style={{position: 'absolute', left: '269px', top: '406px', width: '681px', height: '16px', zIndex: 20}} name="Editbox1"  spellCheck="false" />
        <div id="wb_Line2" style={{position: 'absolute', left: '143px', top: '446px', width: '821px', height: '2px', zIndex: 21}}>
          <img src="images/img0001.png" id="Line2" alt="" /></div>
       
        <div id="wb_Line4" style={{position: 'absolute', left: '143px', top: '564px', width: '821px', height: '2px', zIndex: 23}}>
          <img src="images/img0003.png" id="Line4" alt="" /></div>
        <label htmlFor id="Label11" style={{position: 'absolute', left: '366px', top: '450px', width: '572px', height: '22px', lineHeight: '22px', zIndex: 24}}>CONTROL - AMBIENTAL - ANALISIS SOLICITADO</label>
        <hr id="Line5" style={{position: 'absolute', left: '349px', top: '621px', width: '467px', zIndex: 25}} />
        <div id="wb_Checkbox1" style={{position: 'absolute', left: '163px', top: '496px', width: '31px', height: '19px', zIndex: 26}}>
          <input type="checkbox" id="Checkbox1" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox1" /></div>
        <div id="wb_Checkbox2" style={{position: 'absolute', left: '363px', top: '496px', width: '31px', height: '19px', zIndex: 27}}>
          <input type="checkbox" id="Checkbox2" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox2" /></div>
        <div id="wb_Checkbox3" style={{position: 'absolute', left: '536px', top: '496px', width: '30px', height: '19px', zIndex: 28}}>
          <input type="checkbox" id="Checkbox3" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox3" /></div>
        <div id="wb_Checkbox4" style={{position: 'absolute', left: '745px', top: '496px', width: '31px', height: '19px', zIndex: 29}}>
          <input type="checkbox" id="Checkbox4" name="Checkbox1" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="Checkbox4" /></div>
        <label htmlFor id="Label12" style={{position: 'absolute', left: '190px', top: '493px', width: '131px', height: '16px', lineHeight: '16px', zIndex: 30}}>MICROBIOLOGICO</label>
        <label htmlFor id="Label13" style={{position: 'absolute', left: '387px', top: '493px', width: '131px', height: '16px', lineHeight: '16px', zIndex: 31}}>FISICO QUIMICO</label>
        <label htmlFor id="Label14" style={{position: 'absolute', left: '577px', top: '493px', width: '131px', height: '16px', lineHeight: '16px', zIndex: 32}}>TOXICOLOGICO</label>
        <label htmlFor id="Label15" style={{position: 'absolute', left: '784px', top: '493px', width: '144px', height: '16px', lineHeight: '16px', zIndex: 33}}>METALES PESADOS</label>
        <div id="wb_RadioButton1" style={{position: 'absolute', left: '213px', top: '534px', width: '14px', height: '24px', zIndex: 34}}>
          <input type="radio" id="RadioButton1" name="trmotivo" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="RadioButton1" /></div>
        <label htmlFor id="Label16" style={{position: 'absolute', left: '153px', top: '534px', width: '50px', height: '16px', lineHeight: '16px', zIndex: 35}}>Motivo</label>
        <div id="wb_RadioButton2" style={{position: 'absolute', left: '361px', top: '534px', width: '14px', height: '24px', zIndex: 36}}>
          <input type="radio" id="RadioButton2" name="trmotivo" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="RadioButton2" /></div>
        <div id="wb_RadioButton3" style={{position: 'absolute', left: '506px', top: '534px', width: '14px', height: '24px', zIndex: 37}}>
          <input type="radio" id="RadioButton3" name="trmotivo" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="RadioButton3" /></div>
        <div id="wb_RadioButton4" style={{position: 'absolute', left: '678px', top: '534px', width: '14px', height: '24px', zIndex: 38}}>
          <input type="radio" id="RadioButton4" name="trmotivo" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="RadioButton4" /></div>
        <div id="wb_RadioButton5" style={{position: 'absolute', left: '828px', top: '534px', width: '14px', height: '24px', zIndex: 39}}>
          <input type="radio" id="RadioButton5" name="trmotivo" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="RadioButton5" /></div>
        <label htmlFor id="Label17" style={{position: 'absolute', left: '239px', top: '529px', width: '87px', height: '16px', lineHeight: '16px', zIndex: 40}}>PROGRAMA</label>
        <label htmlFor id="Label18" style={{position: 'absolute', left: '381px', top: '529px', width: '54px', height: '16px', lineHeight: '16px', zIndex: 41}}>FASSC</label>
        <label htmlFor id="Label19" style={{position: 'absolute', left: '520px', top: '529px', width: '54px', height: '16px', lineHeight: '16px', zIndex: 42}}>QUEJA</label>
        <label htmlFor id="Label20" style={{position: 'absolute', left: '697px', top: '529px', width: '54px', height: '16px', lineHeight: '16px', zIndex: 43}}>BROTE</label>
        <label htmlFor id="Label21" style={{position: 'absolute', left: '844px', top: '529px', width: '123px', height: '16px', lineHeight: '16px', zIndex: 44}}>INTOXICACION</label>
        <div id="wb_RadioButton6" style={{position: 'absolute', left: '475px', top: '636px', width: '14px', height: '24px', zIndex: 45}}>
          <input type="radio" id="RadioButton6" name="trprioridad" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="RadioButton6" /></div>
        <label htmlFor id="Label22" style={{position: 'absolute', left: '493px', top: '632px', width: '87px', height: '16px', lineHeight: '16px', zIndex: 46}}>NORMAL</label>
        <div id="wb_RadioButton7" style={{position: 'absolute', left: '599px', top: '636px', width: '14px', height: '24px', zIndex: 47}}>
          <input type="radio" id="RadioButton7" name="trprioridad" defaultValue="on" style={{position: 'absolute', left: 0, top: 0}} /><label htmlFor="RadioButton7" /></div>
        <label htmlFor id="Label23" style={{position: 'absolute', left: '617px', top: '632px', width: '87px', height: '16px', lineHeight: '16px', zIndex: 48}}>URGENTE</label>
        <label htmlFor id="Label24" style={{position: 'absolute', left: '349px', top: '632px', width: '65px', height: '16px', lineHeight: '16px', zIndex: 49}}>Prioridad</label>
        <label htmlFor id="Label25" style={{position: 'absolute', left: '130px', top: '660px', width: '37px', height: '16px', lineHeight: '16px', zIndex: 50}}>Clave</label>
        <label htmlFor id="Label26" style={{position: 'absolute', left: '222px', top: '660px', width: '65px', height: '16px', lineHeight: '16px', zIndex: 51}}>Examen</label>
        <input type="text" id="Editbox11" style={{position: 'absolute', left: '121px', top: '697px', width: '56px', height: '16px', zIndex: 52}} name="Editbox1"  spellCheck="false" />
        <input type="text" id="Editbox12" style={{position: 'absolute', left: '206px', top: '697px', width: '328px', height: '16px', zIndex: 53}} name="Editbox1"  spellCheck="false" />
        <input type="text" id="Editbox13" style={{position: 'absolute', left: '121px', top: '737px', width: '56px', height: '16px', zIndex: 54}} name="Editbox1"  spellCheck="false" />
        <input type="text" id="Editbox14" style={{position: 'absolute', left: '206px', top: '737px', width: '328px', height: '16px', zIndex: 55}} name="Editbox1"  spellCheck="false" />
        <input type="text" id="Editbox15" style={{position: 'absolute', left: '121px', top: '781px', width: '56px', height: '16px', zIndex: 56}} name="Editbox1"  spellCheck="false" />
        <input type="text" id="Editbox16" style={{position: 'absolute', left: '206px', top: '781px', width: '328px', height: '16px', zIndex: 57}} name="Editbox1"  spellCheck="false" />
        <input type="text" id="Editbox17" style={{position: 'absolute', left: '121px', top: '823px', width: '56px', height: '16px', zIndex: 58}} name="Editbox1"  spellCheck="false" />
        <input type="text" id="Editbox18" style={{position: 'absolute', left: '206px', top: '823px', width: '328px', height: '16px', zIndex: 59}} name="Editbox1"  spellCheck="false" />
        <input type="text" id="Editbox19" style={{position: 'absolute', left: '119px', top: '864px', width: '56px', height: '16px', zIndex: 60}} name="Editbox1"  spellCheck="false" />
        <input type="text" id="Editbox20" style={{position: 'absolute', left: '204px', top: '864px', width: '328px', height: '16px', zIndex: 61}} name="Editbox1"  spellCheck="false" />
        <input type="text" id="Editbox21" style={{position: 'absolute', left: '562px', top: '698px', width: '56px', height: '16px', zIndex: 62}} name="Editbox1"  spellCheck="false" />
        <input type="text" id="Editbox22" style={{position: 'absolute', left: '647px', top: '698px', width: '328px', height: '16px', zIndex: 63}} name="Editbox1"  spellCheck="false" />
        <input type="text" id="Editbox23" style={{position: 'absolute', left: '562px', top: '738px', width: '56px', height: '16px', zIndex: 64}} name="Editbox1"  spellCheck="false" />
        <input type="text" id="Editbox24" style={{position: 'absolute', left: '647px', top: '738px', width: '328px', height: '16px', zIndex: 65}} name="Editbox1"  spellCheck="false" />
        <input type="text" id="Editbox25" style={{position: 'absolute', left: '562px', top: '782px', width: '56px', height: '16px', zIndex: 66}} name="Editbox1"  spellCheck="false" />
        <input type="text" id="Editbox26" style={{position: 'absolute', left: '647px', top: '782px', width: '328px', height: '16px', zIndex: 67}} name="Editbox1"  spellCheck="false" />
        <input type="text" id="Editbox27" style={{position: 'absolute', left: '562px', top: '824px', width: '56px', height: '16px', zIndex: 68}} name="Editbox1"  spellCheck="false" />
        <input type="text" id="Editbox28" style={{position: 'absolute', left: '647px', top: '824px', width: '328px', height: '16px', zIndex: 69}} name="Editbox1"  spellCheck="false" />
        <input type="text" id="Editbox29" style={{position: 'absolute', left: '560px', top: '865px', width: '56px', height: '16px', zIndex: 70}} name="Editbox1"  spellCheck="false" />
        <input type="text" id="Editbox30" style={{position: 'absolute', left: '645px', top: '865px', width: '328px', height: '16px', zIndex: 71}} name="Editbox1"  spellCheck="false" />
        <label htmlFor id="Label27" style={{position: 'absolute', left: '270px', top: '568px', width: '620px', height: '22px', lineHeight: '22px', zIndex: 72}}>BIOLOGIA MOLECULAR / CONTROL MICROBIOLOGICO/ANALISIS SOLICITADO</label>
        
        <label htmlFor id="Label29" style={{position: 'absolute', left: '662px', top: '660px', width: '65px', height: '16px', lineHeight: '16px', zIndex: 74}}>Examen</label>
        <label htmlFor id="Label30" style={{position: 'absolute', left: '577px', top: '660px', width: '37px', height: '16px', lineHeight: '16px', zIndex: 75}}>Clave</label>
        <input type="submit" id="Button1" name value="Nuevo" style={{position: 'absolute', left: '175px', top: '910px', width: '72px', height: '18px', zIndex: 76}} />
        <input type="submit" onClick={()=>this.sendSave()} d="Button2" name value="Guardar" style={{position: 'absolute', left: '267px', top: '910px', width: '72px', height: '18px', zIndex: 77}} />
        <input type="submit" id="Button3" name value="Modificar" style={{position: 'absolute', left: '361px', top: '910px', width: '72px', height: '18px', zIndex: 78}} />
        <input type="submit" id="Button4" name value="Hojas de Trabajo" style={{position: 'absolute', left: '816px', top: '910px', width: '144px', height: '18px', zIndex: 79}} />
        <hr id="Line6" style={{position: 'absolute', left: '115px', top: '900px', width: '870px', zIndex: 80}} />
        <hr id="Line6" style={{position: 'absolute', left: '115px', top: '930px', width: '870px', zIndex: 81}} />
      </div>
     
      <button className="btn btn-outline-secondary font-weight-bold"
              type="button" id="button-addon1" href="#modalprocedencia"
              data-toggle="modal">Tipo de Muestra</button>
      <div className="modal fade" id="modalprocedencia"  style={{position: 'absolute', left: '90px', top: '90px'} }   >
<div className="modal-dialog modal-lg" role="document">
               <div className="modal-content">
                 <div  className="modal-header">
                     <button id="btnn" tyle="button" className="close"
                     data-dismiss="modal"
                     aria-hidden="true">&times;</button>
                         <h5 className="modal-title">PROCEDENCIA</h5>
                     </div>
                     <div className="modal-body">
                         <h4 className="modal-title"></h4>
                       <TblProcedencia
                        //data={this.data}>
                        callback={this.getResponseTipoH}>
                       </TblProcedencia>
                     </div>

                     <div className="modal-footer">
                     <button className="btn btn-secondary"
                     data-dismiss="modal">Cerrar</button>
                     </div>

               </div>

       </div>
</div>











      </div>

      







     
);
}
  sendSave(){
const baseUrl = "http://localhost:3000/Rtblmuestra_recep/create"
const datapost = {
MUESTRA: this.state.MUESTRA,
MUESTRA2: this.state.MUESTRA2,
FEC_REC: this.state.FEC_REC,
HOR_REC: this.state.HOR_REC,
CLAPRO: this.state.CLAPRO,
CLAMUE: this.state.CLAMUE,
AMPLIAR_TM: this.state.AMPLIAR_TM,
TEM_REC: this.state.TEM_REC,
CONFIRMAR: this.state.CONFIRMAR,
OBSERVA: this.state.OBSERVA,
AM: this.state.AM,
AF: this.state.AF,
AMP: this.state.AMP,
HT: this.state.HT,
VALIDADO: this.state.VALIDADO,
MOTIVO: this.state.MOTIVO,
PRIORIDAD: this.state.PRIORIDAD,
E1: this.state.E1,
EXAM1: this.state.EXAM1,
E2: this.state.E2,
EXAM2: this.state.EXAM2,
E3: this.state.E3,
EXAM3: this.state.EXAM3,
E4: this.state.E4,
EXAM4: this.state.EXAM4,
E5: this.state.E5,
EXAM5: this.state.EXAM5,
E6: this.state.E6,
EXAM6: this.state.EXAM6,
E7: this.state.E7,
EXAM7: this.state.EXAM7,
E8: this.state.E8,
EXAM8: this.state.EXAM8,
E9: this.state.E9,
EXAM9: this.state.EXAM9,
E10: this.state.E10,
EXAM10: this.state.EXAM10,
MODIFICADO: this.state.MODIFICADO,
FEC_LAB: this.state.FEC_LAB,
HOR_LAB: this.state.HOR_LAB,
CLAREC: this.state.CLAREC
}
axios.post(baseUrl,datapost)
      .then(response=>{
 if (response.data.success===true) {
  alert(response.data.message)
}
else {
alert(response.data.message)
}
}).catch(error=>{
   alert("Error 34 "+error)
 })
 }
}
export default EditComponent;
